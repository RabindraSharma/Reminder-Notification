/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crm.ui;

import bioas.master.db.Company;
import bioas.master.db.Office;
import bioas.util.GenConstants;
import bioas.util.beans.CmpMst;
import bioas.util.beans.Login;
import bioas.util.beans.OffMst;
import bioas.util.db.User;
import crm.beans.EMD;
import crm.beans.Tender;
import crm.dao.EMDDao;
import crm.dao.JSONConfig;
import crm.dao.TenderDao;
import crm.db.BusinessTargets;
import crm.db.Customer;
import crm.db.Deal;
import crm.db.DeliveryChallan;
import crm.db.Enquiry;
import crm.db.Industry;
import crm.db.LeadSource;
import crm.db.OfficeTypes;
import crm.db.PayTerms;
import crm.db.Product;
import crm.db.PurchaseOrder;
import crm.db.RMA;
import crm.db.Reminder;
import crm.db.ServiceCall;
import crm.db.ServiceContract;
import crm.db.StockTransfer;
import crm.db.Voucher;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import crm.db.RequestForQuotation;
import crm.db.TokenSecurity;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author Ramnath Created on 20.05.2019
 */
public class CrmRequestProcessor {

    private static final Logger logger = Logger.getLogger(CrmRequestProcessor.class);
    private String forwardUrl = GenConstants.ERROR_CRM;
//    private String forwardUrl = GenConstants.ACCESS_DENIED;
    private static final String MESSAGE_URL = "/jsp/utils/Message.jsp?Msg=";
//    private static final String REPORT_FORM = "/jsp/utils/Report.jsp?type=";
    //Commented above and modified as below on 29.10.2019
    private static final String REPORT_FORM = "/jsp/crm/reports/crmReports.jsp?type=";
    private static final String REQ_FOR_ORDER_ENTRY_FORM = "getOEF";
    private static final String REQ_FOR_PO_ENTRY_FORM = "getPOEF"; //Added on 20.07.2020
    private static final String REQ_FOR_ORDER_MODIFY_FORM = "getOMF"; //Added on 18.07.2020
    private static final String REQ_FOR_SERV_CONTRACT_ENTRY_FORM = "getSCEF"; //Added on 17.09.2020
    private static final String REQ_FOR_SERV_CONTRACT_MODIFY_FORM = "getSCMF"; //Added on 14.10.2020
    private static final String REQ_FOR_PEND_ORDERS = "getPendOrds"; //Added on 27.05.2019
    private static final String REQ_FOR_PEND_SERV_CONTRACTS = "getPendContr"; //Added on 18.09.2020
    private static final String REQ_FOR_ACT_SERV_CONTRACTS = "getActContr"; //Added on 25.09.2020
    private static final String REQ_FOR_NON_ACT_SERV_CONTRACTS = "getNonActContr"; //Added on 08.03.2021
    private static final String REQ_FOR_ORDERS = "getOrders"; //Added on 23.10.2019
    private static final String REQ_FOR_EMD_REPORTS = "getEmdReports"; // Added on 25.10.2023 by Rabindra Sharma
    private static final String REQ_FOR_POS = "getPOs"; //Added on 08.02.2021
    private static final String REQ_FOR_SHOW_ORDERS = "showOrders"; //Added on 29.10.2019
    private static final String REQ_FOR_SHOW_POS = "showPOs"; //Added on 08.02.2021
    private static final String ORDER_ENTRY_FORM_URL = "/jsp/crm/entries/order-entry.jsp";
    private static final String PO_ENTRY_FORM_URL = "/jsp/crm/entries/po-entry.jsp"; //Added on 20.07.2020
    private static final String ORDER_MODIFY_FORM_URL = "/jsp/crm/entries/order-modify.jsp"; //Added on 18.07.2020
    private static final String SERV_CONTRACT_ENTRY_FORM_URL = "/jsp/crm/entries/serv-contr-entry.jsp"; //Added on 17.09.2020
    private static final String SERV_CONTRACT_MODIFY_FORM_URL = "/jsp/crm/entries/serv-contr-modify.jsp"; //Added on 14.10.2020
    private static final String ORDER_REPORT_URL = "/jsp/crm/reports/orders.jsp";
    private static final String SERV_CONTRACTS_REPORT_URL = "/jsp/crm/reports/service-contracts.jsp"; //Added on 18.09.2020
    private static final String ACT_SERV_CONTRACTS_REPORT_URL = "/jsp/crm/reports/act-service-contracts.jsp"; //Added on 29.09.2020
    private static final String NON_ACT_SERV_CONTRACTS_REPORT_URL = "/jsp/crm/reports/non-act-service-contracts.jsp"; //Added on 08.03.2021
    private static final String ORDERS_LIST_URL = "/jsp/crm/reports/ordersList.jsp"; //30.10.2019
    private static final String POS_LIST_URL = "/jsp/crm/reports/posList.jsp"; //Added on 08.02.2021
    private static final String REQ_FOR_ORDER_INFO = "getOrdInfo";
     // Following line added on 09.02.2024
    private static final String COST_INFO_URL ="/jsp/crm/reports/costingReport.jsp";
    private static final String REQ_FOR_CMP_COST_REP = "showCostRep";
    private static final String ORDER_INFO_URL = "/jsp/crm/reports/orderDetails.jsp";
    private static final String REQ_FOR_PACKING_LIST = "getPackListFrm";
    private static final String PACKING_LIST_FORM_URL = "/jsp/crm/reports/orderPackingList.jsp";
    private static final String REQ_FOR_PACKING_STICKERS = "getPackStickersFrm";
    private static final String PACKING_STICKERS_FORM_URL = "/jsp/crm/reports/packingStickers.jsp";
    //Added below 3 lines on 21.06.2019
    private static final String REQ_FOR_DASH_BOARD = "dashBoard";
    private static final String REQ_FOR_PEND_PROCURES = "getPendProcures";
    private static final String PEND_PROCURES_REPORT_URL = "/jsp/crm/reports/procures.jsp";
    //Added below 2 lines on 28.06.2019
    private static final String REQ_FOR_PEND_DELV = "getPendDelv";
    private static final String PEND_DELV_REPORT_URL = "/jsp/crm/reports/deliveries.jsp";

    //Added below 2 lines on 18.10.2019
    private static final String REQ_FOR_DOCS_UPL_FORM = "getDocsUplFrm";
    private static final String DOCS_UPL_FORM_URL = "/jsp/crm/entries/docs-upload.jsp";
    private static final String PO_DOCS_UPL_FORM_URL = "/jsp/crm/entries/po-docs-upload.jsp"; //Added on 13.02.2021

    //Added below 2 lines on 01.11.2019
    private static final String REQ_FOR_PEND_SHIPM = "getPendShipm";
    private static final String PEND_SHIPM_REPORT_URL = "/jsp/crm/reports/shipments.jsp";

    //Added below 2 lines on 28.11.2019
    private static final String REQ_FOR_PEND_INST = "getPendInst";
    private static final String PEND_INST_REPORT_URL = "/jsp/crm/reports/installations.jsp";

    //Added below 2 lines on 30.11.2019
    private static final String REQ_FOR_PEND_PODS = "getPendPODs";
    private static final String PEND_PODS_REPORT_URL = "/jsp/crm/reports/pend-pods.jsp";

    //Added below 2 lines on 03.12.2019
    private static final String REQ_FOR_ACT_PROJECTS = "getActProj";
    private static final String ACT_PROJECTS_URL = "/jsp/crm/reports/projects.jsp";

    //Added below 2 lines on 16.12.2019
    private static final String REQ_FOR_PROD_ENTRY_FORM = "getPrEntryFrm";
    private static final String PROD_ENTRY_FORM_URL = "/jsp/crm/entries/product-entry.jsp";

    //Added below 2 lines on 21.12.2019
    private static final String REQ_FOR_PROD_LIST = "getPrList";
    private static final String PROD_LIST_URL = "/jsp/crm/reports/productsList.jsp";

    //Added below 2 lines on 30.09.2020
    private static final String REQ_FOR_STOCK_REP = "getStockRep";
    private static final String STOCK_REP_URL = "/jsp/crm/reports/stock-report.jsp";
    //Added below 2 lines on 08.06.2021
    private static final String REQ_FOR_STOCK_SUMMARY_REP = "getStockSummaryRep";
    private static final String STOCK_SUMMARY_REP_URL = "/jsp/crm/reports/stock-summary-report.jsp";

    //Added below 3 lines on 23.01.2020
    private static final String REQ_FOR_PROD_SNOS = "getProdSNOs";
    private static final String REQ_FOR_SHOW_PROD_SNOS = "showProdSNOs";
    private static final String PROD_SNOS_URL = "/jsp/crm/reports/prodSNOsList.jsp";

    //Added below lines on 14.02.2020
    private static final String REQ_FOR_ENQUIRY_ENTRY_FORM = "getEEF";
    private static final String ENQUIRY_ENTRY_FORM_URL = "/jsp/crm/entries/enquiry-entry.jsp";

    //Added below lines on 25.02.2020
    private static final String REQ_FOR_CUST_ENTRY_FORM = "getCustEntryFrm";
    private static final String CUST_ENTRY_FORM_URL = "/jsp/crm/entries/customer-entry.jsp";
    
    //Added below 2 lines on 30.06.2021
    private static final String REQ_FOR_CUST_DECL_FORM = "getCustDeclFrm";
    private static final String CUST_DECL_FORM_URL = "/jsp/crm/entries/CustomerDeclaration.jsp";

    //Added below 2 lines on 27.02.2020
    private static final String REQ_FOR_CUST_LIST = "getCustList";
    private static final String CUST_LIST_URL = "/jsp/crm/reports/customersList.jsp";

    //Added below 2 lines on 06.03.2020
    private static final String REQ_FOR_ACT_ENQ = "getActEnq";
    private static final String ACT_ENQ_URL = "/jsp/crm/reports/enquiries.jsp";

    private static final String REQ_FOR_INV_INFO = "getInvInfo"; //Added on 12.03.2020
    private static final String REQ_FOR_SERV_CONTR_INV_INFO = "getSCInvInfo"; //Added on 12.10.2020
    private static final String REQ_FOR_QUOTE = "getQuotation"; //Added on 08.04.2020

    //Added below 2 lines on 11.04.2020
    private static final String REQ_FOR_QUOTE_INFO = "getQuoteDetails";
    private static final String QUOTE_INFO_URL = "/jsp/crm/reports/quoteDetails.jsp";

    //Added below 2 lines on 01.05.2020
    private static final String REQ_FOR_UN_ASSIGN_ENQ = "getUnAssignedEnqs";
    private static final String UN_ASSIGN_ENQ_URL = "/jsp/crm/reports/unAssignedEnqs.jsp";

    //Added below 3 lines on 20.06.2020
    private static final String REQ_FOR_TODAYS_REP = "getTodaysRep";
    private static final String REQ_FOR_SHOW_TODAYS_REP = "showTodaysRep";
    private static final String TODAYS_REP_URL = "/jsp/crm/reports/todaysReport.jsp";

    //Added below 2 lines on 09.07.2020
    private static final String REQ_FOR_PEND_RECV = "getPendRecv";
    private static final String PEND_RECV_URL = "/jsp/crm/reports/pend-recv.jsp";

    //Added below 3 lines on 17.07.2020
    private static final String REQ_FOR_RECT_REP = "getRectRep";
    private static final String REQ_FOR_SHOW_RECT_REP = "showRectRep";
    private static final String RECT_REP_URL = "/jsp/crm/reports/receiptsReport.jsp";

    //Added below 2 lines on 24.07.2020
    private static final String REQ_FOR_PEND_POS = "getPendPOs";
    private static final String PEND_POS_URL = "/jsp/crm/reports/purchase-orders.jsp";

    private static final String REQ_FOR_OPO = "getOPO"; //Added on 30.07.2020

    //Added below 2 lines on 07.08.2020
    private static final String REQ_FOR_PO_INFO = "getPOInfo";
    private static final String PO_DTLS_URL = "/jsp/crm/reports/poDetails.jsp";

    //Added below 3 lines on 31.07.2020
    private static final String REQ_FOR_UPL_DOCS_REP = "getUplDocsRep";
    private static final String REQ_TO_SHOW_UPL_DOCS_REP = "showUplDocsRep";
    private static final String UPL_DOCS_REP_URL = "/jsp/crm/reports/uploaded-docs.jsp";

    //Added below 2 lines on 19.08.2020
    private static final String REQ_FOR_RMA_INW_ENTRY_FORM = "getRmInEF";
    private static final String REQ_FOR_RMA_INW_EF_URL = "/jsp/crm/entries/rma-inw-entry.jsp";

    //Added below 2 lines on 29.08.2020
    private static final String REQ_FOR_PEND_RMA_REC = "getActiveRMAs";
    private static final String PEND_RMA_REC_URL = "/jsp/crm/reports/pend-rma.jsp";

    //Added below 2 lines on 30.09.2020
    private static final String REQ_FOR_STOCK_ENTRY_FORM = "getStockEF";
  //   private static final String REQ_FOR_STOCK_ENTRY_FORM = "ExcelDataUpload";
   //  private static final String REQ_FOR_STOCK_EF_URL = "/jsp/utils/ExcelDataUpload.jsp";
    private static final String REQ_FOR_STOCK_EF_URL = "/jsp/crm/entries/stock-entry.jsp";

    //Added below 2 lines on 01.10.2020
    private static final String REQ_FOR_BG_ENTRY_FORM = "getBGEF";
    private static final String REQ_FOR_BG_EF_URL = "/jsp/crm/entries/bg-entry.jsp";

    //Added below 2 lines on 06.10.2020
    private static final String REQ_FOR_BGS_LIST = "getBGsList";
    private static final String BGS_LIST_URL = "/jsp/crm/reports/bgs-list.jsp";

    //Added below 2 lines on 10.10.2020
    private static final String REQ_FOR_SERV_CONTR_INFO = "getSCInfo";
    private static final String SERV_CONTR_INFO_URL = "/jsp/crm/reports/scDetails.jsp";

    //Added below 2 lines on 03.11.2020
    private static final String REQ_FOR_BILLABLE_REP = "getBillableRep";
    private static final String BILLABLE_REP_URL = "/jsp/crm/reports/billable-rep.jsp";
    
    //Added below 2 lines on 02.12.2020
    private static final String REQ_FOR_EXP_VCHR_FORM = "getExpVchrFrm";
    private static final String EXP_VCHR_FORM_URL = "/jsp/crm/entries/exp-voucher.jsp";

    //Added below 2 lines on 29.01.2021
    private static final String REQ_FOR_PEND_EXP_VCHRS = "getPendEXPV";
    private static final String PEND_EXP_VCHRS_URL = "/jsp/crm/reports/pend-exp-vchrs.jsp";
        
    //Added below 4 lines on 11.02.2021
    private static final String REQ_FOR_EXP_VCHRS_PAY = "getExpVForPay";
    private static final String REQ_FOR_EXP_VCHRS_LIST = "getExpVchrsList";
    private static final String REQ_FOR_SHOW_EXP_VCHRS_LIST = "showExpVchrsList";
    private static final String EXP_VCHRS_PAY_URL = "/jsp/crm/reports/exp-vchrs-pay.jsp";
    private static final String EXP_VCHRS_LIST_URL = "/jsp/crm/reports/exp-vchrs-list.jsp";

    //Added below 2 lines on 18.02.2021
    private static final String REQ_FOR_SERV_TICKET_ENTRY_FORM = "getTicketEF";
    private static final String SERV_TICKET_ENTRY_FORM = "/jsp/crm/entries/create-ticket.jsp";
    //Added below 2 lines on 01.10.2021
    private static final String REQ_FOR_PEND_SERV_TICKETS = "getPendTickets";
    private static final String PEND_SERV_TICKETS_URL = "/jsp/crm/reports/pend-serv-tickets.jsp";
    //Added below 2 lines on 04.10.2021
    private static final String REQ_FOR_SERV_TICKETS = "getTicketsList";
    private static final String REQ_FOR_SHOW_SERV_TICKETS_LIST = "showTicketsList";
    private static final String SERV_TICKETS_URL = "/jsp/crm/reports/serv-tickets-list.jsp";
    
    //Added below 2 lines on 11.06.2021
    private static final String REQ_FOR_SERV_CALL_ENTRY_FORM = "getServCallEF";
    private static final String SERV_CALL_ENTRY_FORM = "/jsp/crm/entries/service-call-entry.jsp";

    //Added below 2 lines on 20.02.2021
    private static final String REQ_FOR_EXP_DOCS_UPL_FORM = "getExpDocsUplFrm";
    private static final String EXP_DOCS_UPL_FORM_URL = "/jsp/crm/entries/exp-docs-upload.jsp";

    //Added below 2 lines on 19.02.2021
    private static final String REQ_FOR_WARR_LAPSES_LIST = "getWarrLapsesList";
    private static final String WARR_LAPSES_LIST_URL = "/jsp/crm/reports/warr-lapses-list.jsp";
    
    //Added below 2 lines on 22.03.2021
    private static final String REQ_FOR_SET_TARGETS_FORM = "setTargets";
    private static final String SET_TARGETS_FORM_URL = "/jsp/crm/entries/targets-entry.jsp";
    
    //Added below 3 lines on 06.04.2021
    private static final String REQ_FOR_RMA_STOCK_REP = "getRMAStock";
    private static final String REQ_FOR_SHOW_RMA_STOCK_REP = "showRMAStock";
    private static final String RMA_STOCK_REP_URL = "/jsp/crm/reports/rma-stock-rep.jsp";

    //Added below on 19.04.2021
    private static final String REQ_FOR_ACC_MNGR_PERF = "getAccMngrPerf";
    private static final String SHOW_ACC_MNGR_PERF = "showAccMngrPerf";
    private static final String SHOW_ACC_MNGR_PERF_REP = "/jsp/crm/reports/acm-perf-rep.jsp";
    
    //Added below 2 lines on 23.06.2021
    private static final String REQ_FOR_PEND_RETURNABLE = "getPendReturnable";
    private static final String PEND_RETURNABLE_URL = "/jsp/crm/reports/pend-returnable.jsp";
    
    //Added below 2 lines on 05.01.2022
    private static final String REQ_FOR_CO_DOCS = "getCompDocs";
    private static final String CO_DOCS_REP_URL = "/jsp/crm/reports/comp-docs.jsp";
    
    private static final String REQ_FOR_ADD_MACNO="getExcelDataUpload";
     //   private static final String REQ_FOR_STOCK_ENTRY_FORM = "ExcelDataUpload";
    // private static final String REQ_FOR_ADD_MACNO_URL = "/jsp/ExcelDataUpload.jsp";
    private static final String REQ_FOR_ADD_MACNO_URL = "/jsp/utils/ExcelDataUpload.jsp";
    
    //Added below 5 lines on 28.01.2022
    private static final String REQ_FOR_TENDER_ENRTY_FORM="getTEF";
    private static final String REQ_FOR_TENDER_MODIFY_FORM="getTMF";
    private static final String REQ_FOR_TENDER_DOCS_UPLOAD_FORM="getTndDocsUplFrm";
    private static final String SHOW_TENDERS_REPORT="getTenders";
    private static final String SHOW_TENDER_DETAIL="viewTender";
    private static final String REQ_FOR_TENDER_EMD_ENTRY="getEMDEF";
    private static final String SHOW_TENDERS_EMD_REPORT="getEMDList";
    private static final String REQ_FOR_TENDER_EMD_MODIFY="getEMDMF";
    private static final String SHOW_TENDER_EXTEND_REPORT="getTndExtReport";
    private static final String SHOW_TENDERS_BY_APPROVAL="getTendersByApproval";
    
   //Added below few lines by Rabindra Sharma on 07.04.2023SHOW
    
    private static final String REQ_FOR_COURIER_CONF_JSON = "confCourierListJson";
    private static final String REQ_FOR_PRODUCT_CATEGORY_CONF_JSON = "confPCJson";
    private static final String REQ_FOR_INDIAN_STATES_CONF_JSON = "confIndianStatesJson";
    
    private static final String COURIER_CONF_JSON_URL = "/jsp/crm/settings/courier-list-conf.jsp";
    private static final String PRODUCT_CATEGORY_JSON_URL = "/jsp/crm/settings/products-category-conf.jsp";
    private static final String INDIAN_STATES_CONF_JSON_URL = "/jsp/crm/settings/indian-states-conf.jsp"; 
    
    /*following Lines added on 31st May 2023 for Additional Delivery Challan Module*/ 
    private static final String NEW_DC = "NewDCForm";
    private static final String DC_FORM_URL = "/jsp/crm/entries/DCEntry.jsp";
    private static final String DC_PEND_FORM ="/jsp/crm/reports/DCPendForm.jsp";
    private static final String PEND_DC = "PendDC";
    // Added  below lines on 26-10-2023 by Rabindra Sharma
    private static final String REQ_FOR_STOCK_TR_FORM = "getStockTF";
    private static final String GET_STOCK_TF_URL = "/jsp/crm/entries/stock-transfer-entry.jsp";
    
    // Added below 3 line on 28.10.2023 by Rabindra Sharma
    private static final String REQ_FOR_STOCK_TR_PENDING = "getStPending";
    private static final String GET_STOCK_TFP_URL = "/jsp/crm/reports/stockTFPend.jsp";
    private static final String REQ_FOR_STOCK_TR_MODIFY = "stModify";
    private static final String GET_STOCK_TR_MODIFY_URL = "/jsp/crm/entries/stock-transfer-modify.jsp";
    
    //Added below 1 line on 03.11.2023 by Rabindra Sharma
    private static final String REQ_FOR_STOCK_TR_PACKING_STICKERS = "getPackStStickersFrm";
    private static final String PACKING_ST_STICKERS_FORM_URL = "/jsp/crm/reports/packingStStickers.jsp";
    
    //Added below 1 line on 05.03.2024 by Rabindra Sharma
    private static final String REQ_FOR_RFQ_ENTR = "getRFQEntr";
    private static final String RFQ_ENTR_FORM_URL = "/jsp/crm/entries/RFQForm.jsp";
    
    //Added below 1 line on 06.03.2024 by Rabindra Sharma
    private static final String REQ_FOR_RFQ_LIST = "getRFQList";
    private static final String REQ_FOR_RFQ_LIST_URL = "/jsp/crm/reports/rfqList.jsp";
    // FOLOWING lines of code added on 14-03-24    
    private static final String REQ_FOR_QUOTE_RFQ = "getQuotationRFQ";
    private static final String REQ_FOR_QUOTE_VEND_FORM = "getQuote";
    private static final String REQ_FOR_QUOTE_VEND_URL = "/jsp/crm/reports/quoteForm.jsp";
    
    // Added below 1 line on 26-03-2024 by Rabindra Sharma for quotation vendor response
    private static final String REQ_FOR_QUOTE_VEND_DTLS_RESPONSE = "vendorRespDtls";    
    private static final String  GET_FOR_QUOTE_VEND_RESP_URL = "/jsp/crm/reports/rfqVendorResponse-list.jsp";
    
    // Added below 3 line on 21-03-2025 by Rabindra Sharma    
     private static final String GRN_REPORT = "getGRNReport";
     private static final String SHOW_GRN_REP = "showGRNReport";
     private static final String GRN_REPORT_URL = "/jsp/crm/reports/grnReport.jsp";
     
    // Added below 2 line on 25.01.2025 for Reminder notification 
    // Added by Rabindra Sharma
    public static final String REQ_FOR_REMINDER_ENTRY = "reminderEntry";
    public static final String GET_REMINDER_ENTRY_URL = "/jsp/crm/entries/reminder-entry.jsp";
    
    // Added below 2 endpoints for remainder reports on 27.01.2025 by Rabindra Sharma
    public static final String REQ_FOR_REMINDER_REPORT = "remReports";
    public static final String GET_REMAINDER_REPORT_URL = "/jsp/crm/reports/reminder-reports.jsp";
    
    
    
    private HttpSession session;
    private Login usrDetails;
    private CmpMst cmpMst;
    private OffMst offMst;

    //Added below lines on 15.05.2020
    public ServletContext context;

    public ServletContext getContext() {
        return context;
    }

    public void setContext(ServletContext context) {
        this.context = context;
    }
    //Added above lines on 15.05.2020

    public CrmRequestProcessor() {
    }

    public RequestDispatcher requestProcessor(HttpServletRequest request, HttpServletResponse response) {

        String operation = request.getParameter(GenConstants.OPR);
        session = request.getSession(false);
        try {
            usrDetails = (Login) session.getAttribute(GenConstants.SESSION_ATTRIBUTE_NAME);
            cmpMst = usrDetails.getCmpMst();
            offMst = usrDetails.getOffMst();
        } catch (NullPointerException e) {
            logger.error(e.toString());
            //Added below lines on 06.07.2021
            switch (operation) {
                case REQ_FOR_CUST_DECL_FORM: //Added on 30.06.2021
                    String cmpCd = request.getParameter("mainCd");
                    String custId = request.getParameter("custId");
                    String[] custInfo = Customer.getCustName(cmpCd, custId);                    
                    request.setAttribute("cCmpCD", cmpCd);
                    request.setAttribute("cmpName", Company.getCmpName(cmpCd));
                    request.setAttribute("custId", custId);
                    request.setAttribute("custName", custInfo[0]);
                    request.setAttribute("custType", custInfo[1]);
                    forwardUrl = CUST_DECL_FORM_URL;
                    break;
                
                    
                default:
                    forwardUrl = GenConstants.SESSION_TIME_OUT+"?isOpxl=Y";                    
            }
            //Added above lines on 06.07.2021            
            return request.getRequestDispatcher(response.encodeURL(forwardUrl));
        }
        
        String strOffTyp = offMst.getOffTypes().getId().getOffType();
        String strOffCd = offMst.getId().getOffCd();
        ArrayList OfficeHeirarchy = null;
        ArrayList alData;
        String strMsg = null;
        ArrayList workOffHeirarchy = null;
        ArrayList arrayList_formFields = null;
        String dealId; //Added on 18.10.2019
        String invNo;
        String fromDt;
        String toDt;

        //Added below 5 lines on 15.05.2020
        JSONParser parser = new JSONParser();
        Object obj;
        String String_contextPath;
        String String_realPath;
        String String_rootPath;

        ArrayList alCrmUsers; //Added on 18.07.2020
        logger.info(operation);
        switch (operation) {
            case REQ_FOR_ORDER_ENTRY_FORM:
                /*
                 OfficeHeirarchy = Office.getOfficeHeirarchy(usrDetails.getCmpMst().getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), usrDetails.getOffMst().getOffTypes().getId().getOffType());
                 request.setAttribute(GenConstants.OFFICE_HEIRARCHY, OfficeHeirarchy);
                 ArrayList WorkOffce = Office.getWorkingOffice(cmpMst.getCmpCd(), offMst.getId().getOffCd());
                 request.setAttribute(GenConstants.WORKOFF_HEIRARCHY, WorkOffce);
                 */
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("PayTerms", PayTerms.getFields()); //Added on 18.03.2020
                //Added below 2 lines on 01.07.2020
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());

                forwardUrl = ORDER_ENTRY_FORM_URL;
                break;

            case REQ_FOR_SET_TARGETS_FORM: //Added on 22.03.2021
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                forwardUrl = SET_TARGETS_FORM_URL;
                break;
                
            case REQ_FOR_SERV_CONTRACT_ENTRY_FORM: //Added on 17.09.2020
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("PayTerms", PayTerms.getFields());
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());

                forwardUrl = SERV_CONTRACT_ENTRY_FORM_URL;
                break;

            case REQ_FOR_SERV_CONTRACT_MODIFY_FORM: //Added on 14.10.2020
                dealId = request.getParameter("contrId");
                alData = ServiceContract.getDetailsForEdit(cmpMst.getCmpCd(), dealId);
                if (!alData.isEmpty()) {
                    alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                    request.setAttribute("CrmUsers", alCrmUsers);
                    request.setAttribute("PayTerms", PayTerms.getFields());
                    request.setAttribute("Industries", Industry.getFields());
                    request.setAttribute("OffTypes", OfficeTypes.getFields());
                    request.setAttribute("ContrInfo", alData);
                }
                forwardUrl = SERV_CONTRACT_MODIFY_FORM_URL;
                break;

            case REQ_FOR_EXP_VCHR_FORM: //Added on 02.12.2020
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);

                forwardUrl = EXP_VCHR_FORM_URL;
                break;
                
            case REQ_FOR_ORDER_MODIFY_FORM: //Added on 18.07.2020
                dealId = request.getParameter("dealId");
                alData = Deal.getDealForEdit(cmpMst.getCmpCd(), dealId);
                if (!alData.isEmpty()) {
                    alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                    request.setAttribute("CrmUsers", alCrmUsers);
                    request.setAttribute("PayTerms", PayTerms.getFields());
                    request.setAttribute("Industries", Industry.getFields());
                    request.setAttribute("OffTypes", OfficeTypes.getFields());
                    request.setAttribute("OrdInfo", alData);
                }

                forwardUrl = ORDER_MODIFY_FORM_URL;
                break;

            case REQ_FOR_PO_ENTRY_FORM: //Added on 20.07.2020
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("PayTerms", PayTerms.getFields());
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());
                //Added below lines on 29.07.2020
                dealId = request.getParameter("dealId");
                logger.info(dealId);
                if (dealId != null) { //Added check on 06.08.2020
                    alData = Deal.getPendingProcures(cmpMst.getCmpCd(), usrDetails, dealId);
                } else {
                    alData = new ArrayList();
                }
                request.setAttribute("DealInfo", alData);

                forwardUrl = PO_ENTRY_FORM_URL;
                break;

            case REQ_FOR_RMA_INW_ENTRY_FORM: //Added on 19.08.2020
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("PayTerms", PayTerms.getFields());
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());
                //Added below 2 lines on 14.09.2020
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData); //Added on 14.09.2020

                forwardUrl = REQ_FOR_RMA_INW_EF_URL;
                break;

            case REQ_FOR_SERV_TICKET_ENTRY_FORM: //Added on 18.02.2021
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("PayTerms", PayTerms.getFields());
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());

                forwardUrl = SERV_TICKET_ENTRY_FORM;
                break;

            case REQ_FOR_SERV_CALL_ENTRY_FORM: //Added on 11.06.2021
                alData = ServiceCall.getFields(ServiceCall.SC_SOURCE);
                request.setAttribute("SCSource", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SW_ISSUE);
                request.setAttribute("SWIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_HW_ISSUE);
                request.setAttribute("HWIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_UIDAI_ISSUE);
                request.setAttribute("UidiaIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SUPP_MODE);
                request.setAttribute("SuppModes", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_STATUS);
                request.setAttribute("SCStatus", alData);
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData);

                forwardUrl = SERV_CALL_ENTRY_FORM;
                break;

            case REQ_FOR_STOCK_ENTRY_FORM: //Added on 30.09.2020
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData);

                forwardUrl = REQ_FOR_STOCK_EF_URL;
                break;
           
                
            case REQ_FOR_ADD_MACNO:
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData);
                
                 forwardUrl = REQ_FOR_ADD_MACNO_URL;
                 break;
           
                
                
                
            case REQ_FOR_BG_ENTRY_FORM: //Added on 01.10.2020

                forwardUrl = REQ_FOR_BG_EF_URL;
                break;

            case REQ_FOR_PROD_ENTRY_FORM: //Added on 16.12.2019
                String rootPath = request.getServletPath();
                ArrayList alProd = Product.getProducts(cmpMst.getCmpCd(), "T", "K", null, false);
                request.setAttribute("KitProd", alProd);
                org.json.simple.JSONArray obj1 = JSONConfig.getProdCateList(context, rootPath, cmpMst.getCmpCd());
                request.setAttribute("prodCategory", (JSONArray)obj1);
                forwardUrl = PROD_ENTRY_FORM_URL;
                break;

            case REQ_FOR_PEND_ORDERS: //Added on 27.05.2019
                ArrayList alOrders = Deal.getPendingDeals(cmpMst.getCmpCd(), usrDetails); //Added usrDetails on 11.10.2019
                request.setAttribute("Orders", alOrders);
                forwardUrl = ORDER_REPORT_URL;
                break;

            case REQ_FOR_PEND_SERV_CONTRACTS: //Added on 18.09.2020
                alData = ServiceContract.getPendingContracts(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Contracts", alData);
                forwardUrl = SERV_CONTRACTS_REPORT_URL;
                break;

            case REQ_FOR_ACT_SERV_CONTRACTS: //Added on 25.09.2020
                alData = ServiceContract.getActiveContracts(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Contracts", alData);
                forwardUrl = ACT_SERV_CONTRACTS_REPORT_URL;
                break;

            case REQ_FOR_NON_ACT_SERV_CONTRACTS: //Added on 08.03.2021
                alData = ServiceContract.getNonActiveContracts(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Contracts", alData);
                forwardUrl = NON_ACT_SERV_CONTRACTS_REPORT_URL;
                break;
                
            case REQ_FOR_BILLABLE_REP: //Added on 03.11.2020
                alData = ServiceContract.getBillingPredictions(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Contracts", alData);
                forwardUrl = BILLABLE_REP_URL;
                break;

            case REQ_FOR_PEND_POS: //Added on 24.07.2020
                alData = PurchaseOrder.getPendingPOs(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("POs", alData);
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData); //Added on 14.09.2020
                forwardUrl = PEND_POS_URL;
                break;

            case REQ_FOR_PEND_RECV: //Added on 10.07.2020
                alData = Deal.getPendingRecv(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Recv", alData);
                //Added below 2 lines on 06.11.2020
                alData = ServiceContract.getPendingRecv(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("ServRecv", alData);
                forwardUrl = PEND_RECV_URL;
                break;

            case REQ_FOR_PEND_RETURNABLE: //Added on 23.06.2021
                alData = Deal.getPendReturnable(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Data", alData);
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData);
                forwardUrl = PEND_RETURNABLE_URL;
                break;

            case REQ_FOR_ACT_PROJECTS: //Added on 03.12.2019
                ArrayList alProjects = Deal.getPendingDeals(cmpMst.getCmpCd(), usrDetails, "Y");
                request.setAttribute("Orders", alProjects);
                forwardUrl = ACT_PROJECTS_URL;
                break;

            case REQ_FOR_PEND_PROCURES: //Added on 21.06.2019
                ArrayList alProcures = Deal.getPendingProcures(cmpMst.getCmpCd(), usrDetails); //Added usrDetails on 11.10.2019);
                request.setAttribute("Procures", alProcures);
                forwardUrl = PEND_PROCURES_REPORT_URL;

                break;

            case REQ_FOR_PEND_DELV: //Added on 28.06.2019
                ArrayList alDelv = Deal.getPendingDelv(cmpMst.getCmpCd(), usrDetails, null); //Added usrDetails on 11.10.2019);
                //added null as 3rd param on 29.11.2019
                request.setAttribute("Delv", alDelv);
                forwardUrl = PEND_DELV_REPORT_URL;

                break;

            case REQ_FOR_PEND_SHIPM: //Added on 01.11.2019
                ArrayList alShipm = Deal.getPendingShipments(cmpMst.getCmpCd(), strOffCd, usrDetails);
                request.setAttribute("Shipm", alShipm);
                forwardUrl = PEND_SHIPM_REPORT_URL;

                break;

            case REQ_FOR_ORDER_INFO: //Added on 31.05.2019
                logger.info(cmpMst.getCmpCd());
                String strDealName = request.getParameter("dealName");
                logger.info(strDealName);
                ArrayList alOrderInfo = Deal.getDealInfo(cmpMst.getCmpCd(), strDealName);
                request.setAttribute("Order", alOrderInfo);
                logger.info("alOrderInfo :"+alOrderInfo);
                forwardUrl = ORDER_INFO_URL;

                break;
                
               case REQ_FOR_CMP_COST_REP: //Added on 07.01.24
                logger.info(cmpMst.getCmpCd());
                String strDealId = request.getParameter("dealId");
                logger.info("strDealId: "+strDealId);
                ArrayList alOrderInfo1 = Deal.getCompletedDealInfo(cmpMst.getCmpCd(), strDealId);                
                logger.info("alOrderInfo1:"+alOrderInfo1);
                request.setAttribute("Order", alOrderInfo1);
                forwardUrl = COST_INFO_URL;    
                

                break;    

            case REQ_FOR_SERV_CONTR_INFO: //Added on 10.10.2020
                dealId = request.getParameter("contrId");
                logger.info(dealId);
                alData = ServiceContract.getDetails(cmpMst.getCmpCd(), dealId);
                request.setAttribute("SCInfo", alData);
                forwardUrl = SERV_CONTR_INFO_URL;
                break;

            case REQ_FOR_QUOTE_INFO: //Added on 11.04.2020
                String quoteId = request.getParameter("quoteId");
                ArrayList alQuoteInfo = Enquiry.getQuoteInfo(cmpMst.getCmpCd(), quoteId);
                request.setAttribute("Quote", alQuoteInfo);
                request.setAttribute("PayTerms", PayTerms.getFields());
                forwardUrl = QUOTE_INFO_URL;
                break;
                
            case REQ_FOR_PO_INFO: //Added on 07.08.2020
                logger.info(cmpMst.getCmpCd());
                String poNo = request.getParameter("poNo");
                logger.info(poNo);
                alData = PurchaseOrder.getPOInfo(cmpMst.getCmpCd(), poNo);
                request.setAttribute("POInfo", alData);
                forwardUrl = PO_DTLS_URL;
                break;

            case REQ_FOR_INV_INFO: //Added on 12.03.2020
            case REQ_FOR_SERV_CONTR_INV_INFO: //Added on 12.10.2020
                dealId = request.getParameter("dealId");
                invNo = request.getParameter("invNo");
                //Added below lines on 16.05.2020
                if (Deal.getINDIAN_STATES() == null) {
                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                    try {
                        obj = parser.parse(new FileReader(String_rootPath + "\\docs\\IndiaStates.json"));
                        Deal.setINDIAN_STATES((JSONArray) obj);
                    } catch (ParseException ex) {
                        logger.error(ex);
                    } catch (FileNotFoundException ex) {
                        logger.error(ex);
                    } catch (IOException ex) {
                        logger.error(ex);
                    }
                }
                //Added above lines on 16.05.2020
                //ArrayList alInvInfo = Deal.getInvInfo(cmpMst.getCmpCd(), dealId, invNo);
                //Commented above and modified as below on 12.10.2020
                if (operation.equals(REQ_FOR_INV_INFO)) {
                    //ArrayList alInvInfo = Deal.getInvInfo(cmpMst.getCmpCd(), dealId, invNo);
                    //Commented above and modified as below on 22.03.2021
                    logger.info(invNo);
                    ArrayList alInvInfo;
                    if (invNo.isEmpty()) {
                        alInvInfo = Deal.getProformaInvInfo(cmpMst.getCmpCd(), dealId, request.getParameter("billTo"), request.getParameter("shipTo"));
                    } else {
                        alInvInfo = Deal.getInvInfo(cmpMst.getCmpCd(), dealId, invNo);
                    }
                    request.setAttribute("Order", alInvInfo);
                    forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "Invoice.jsp";
                } else {
                    ArrayList alInvInfo = ServiceContract.getInvInfo(cmpMst.getCmpCd(), dealId, invNo);
                    request.setAttribute("Order", alInvInfo);
                    forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "ServInvoice.jsp";
                }

                break;

            case REQ_FOR_QUOTE: //Added on 08.04.2020
                dealId = request.getParameter("quoteId");
                String qType = request.getParameter("qType");
                ArrayList alQuote = Enquiry.getQuoteInfo(cmpMst.getCmpCd(), dealId);
                request.setAttribute("QuoteInfo", alQuote);
                if (qType.isEmpty()) {
                    forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "Quotation.jsp";
                } else if (qType.equalsIgnoreCase("HQ")) {
                    forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "HealthQuote.jsp";
                } else if (qType.equalsIgnoreCase("PD")) { //Added on 26.06.2020
                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                    try {
                        obj = parser.parse(new FileReader(String_rootPath + "\\docs\\" + cmpMst.getCmpCd() + "PreDefQuotes.json"));
                        //JSONArray arPdQuotes = (JSONArray) obj;
                        //Commented above and modified as below on 29.06.2020
                        JSONObject arPdQuotes = (JSONObject) obj;
                        request.setAttribute("PdQuotes", arPdQuotes);
                    } catch (ParseException ex) {
                        logger.error(ex);
                    } catch (FileNotFoundException ex) {
                        logger.error(ex);
                    } catch (IOException ex) {
                        logger.error(ex);
                    }

                    forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "PreDefQuote.jsp";
                }
                else if(qType.equalsIgnoreCase("RFQ")){                    
                    String quote_id = request.getParameter("quoteNo");
                    String vend_id = request.getParameter("vendId");
                    String ship_addr = request.getParameter("shipAddr");
                    String pay_terms = request.getParameter("payTerms");
                    String delv_terms = request.getParameter("delvTerms");
                    logger.info("quote_id"+quote_id);
                    HashMap prodData = RequestForQuotation.getProductDtls(cmpMst.getCmpCd(),quote_id,vend_id);
                    logger.info("alData: "+prodData);
                    request.setAttribute("prodDtls", prodData);                    
                    forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "QuotationRFQ.jsp";
                }
                break;

            case REQ_FOR_OPO: //Added on 30.07.2020
                dealId = request.getParameter("po_no");
                alData = PurchaseOrder.getPOInfo(cmpMst.getCmpCd(), dealId);
                request.setAttribute("POInfo", alData);
                forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "PurchaseOrder.jsp";
                break;

                
            case REQ_FOR_PACKING_LIST: //Added on 10.06.2019
                forwardUrl = PACKING_LIST_FORM_URL;
                break;

            case REQ_FOR_PACKING_STICKERS: //Added on 11.06.2019
                //Added below lines on 15.10.2019
                dealId = request.getParameter("dealId");
                if (dealId != null) {
                    alData = Deal.getDealInvWithPL(cmpMst.getCmpCd(), dealId);
                    request.setAttribute("DealInvs", alData);
                }
                //Added above lines on 15.10.2019
                forwardUrl = PACKING_STICKERS_FORM_URL;
                break;
                //Added below 1 case for stock transfer packing stikers on 03.10.2023 by Rabindra Sharma
            case REQ_FOR_STOCK_TR_PACKING_STICKERS:
                dealId = request.getParameter("dealId");
                logger.info("Deal Id :"+dealId);
                if (dealId != null) {
                    alData = StockTransfer.getDealStWithPL(cmpMst.getCmpCd(), dealId);
                    request.setAttribute("StDealInvs", alData);
                }
                //Added above lines on 15.10.2019
                forwardUrl = PACKING_ST_STICKERS_FORM_URL;
                break;
            case REQ_FOR_DASH_BOARD: //Added on 21.06.2019
                //alData = User.getCrmUsers(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "ALL", "F");
                //Commented above and modified as below on 31.05.2021
//                if(!usrDetails.getCrmUserType().equalsIgnoreCase("N")){
                alData = User.getCrmUsers(cmpMst.getCmpCd(), null, "ALL", "F");
                request.setAttribute("CrmUsers", alData);
                //Added above 2 lines on 24.05.2021
                forwardUrl = "/jsp/workspace/WorkspaceCRM.jsp";
//                }else{
//                    forwardUrl = MESSAGE_URL + "You are not athorized user";
//                }
                break;

            case REQ_FOR_DOCS_UPL_FORM: //Added on 18.10.2019
                dealId = request.getParameter("dealId");
                invNo = request.getParameter("invNo"); //Added on 02.11.2019
                //Added below 2 lines on 12.10.2020
                String servC = request.getParameter("servC");
                servC = servC == null ? "N" : servC;
                //Added below 2 lines on 09.02.2021
                String PODocs = request.getParameter("PODocs");
                PODocs = PODocs == null ? "N" : PODocs;
                if (dealId != null) {
                    if (servC.equals("N")) { //Added check on 12.10.2020
                        //alData = Deal.getDealDocs(cmpMst.getCmpCd(), dealId, invNo); //Added invNo on 02.11.2019
                        //Commented above and modified as below on 09.02.2021
                        if (PODocs.equals("N")) {
                            alData = Deal.getDealDocs(cmpMst.getCmpCd(), dealId, invNo); //Added invNo on 02.11.2019
                        } else {
                            alData = PurchaseOrder.getPODocs(cmpMst.getCmpCd(), dealId, invNo);
                        }
                    } else {
                        alData = ServiceContract.getDealDocs(cmpMst.getCmpCd(), dealId, invNo);
                    }
                    request.setAttribute("DealDocs", alData);
                    if (servC.equals("N")) { //Added check on 12.10.2020
                        //Added below 2 lines on 25.10.2019
                        //alData = Deal.getDealInvs(cmpMst.getCmpCd(), dealId, invNo); //Added invNo on 02.11.2019
                        //Commented above and modified as below on 09.02.2021
                        if (PODocs.equals("N")) {
                            alData = Deal.getDealInvs(cmpMst.getCmpCd(), dealId, invNo); //Added invNo on 02.11.2019
                        } else {
                            alData = PurchaseOrder.getPOInvs(cmpMst.getCmpCd(), dealId, invNo);
                        }
                    } else {
                        alData = ServiceContract.getContrInvs(cmpMst.getCmpCd(), dealId, invNo); //Added invNo on 02.11.2019
                    }
                    request.setAttribute("DealInvs", alData);
                    request.setAttribute("ServC", servC);
                    //forwardUrl = DOCS_UPL_FORM_URL;
                    //Commented above and modified as below on 13.02.2021
                    if (PODocs.equalsIgnoreCase("Y")) {
                        forwardUrl = PO_DOCS_UPL_FORM_URL;
                    } else {
                        forwardUrl = DOCS_UPL_FORM_URL;
                    }
                } else { //Added else part on 11.06.2020
                    forwardUrl = "/jsp/crm/entries/docs-upload-wd.jsp";
                }
                break;

            case REQ_FOR_EXP_DOCS_UPL_FORM: //Added on 20.02.2021
                dealId = request.getParameter("vchrNo");
                alData = Voucher.getVoucherDocs(cmpMst.getCmpCd(), dealId);
                request.setAttribute("VchrDocs", alData);
                
                forwardUrl = EXP_DOCS_UPL_FORM_URL;
                break;

            case REQ_FOR_ACC_MNGR_PERF: //Added on 19.04.2021
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);

                forwardUrl = REPORT_FORM + REQ_FOR_ACC_MNGR_PERF;
                break;

            case SHOW_ACC_MNGR_PERF: //Added on 19.04.2021
                String accMngr = request.getParameter("accMgr");
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                alData = BusinessTargets.getAccManagerRep(cmpMst.getCmpCd(), usrDetails, accMngr, fromDt, toDt);
                request.setAttribute("Data", alData);
                
                forwardUrl = SHOW_ACC_MNGR_PERF_REP;
                break;

            case REQ_FOR_ORDERS: //Added on 23.10.2019
                forwardUrl = REPORT_FORM + REQ_FOR_ORDERS;
                break;
            case REQ_FOR_EMD_REPORTS: //Added on 25.10.2023 by Rabindra Sharma
                forwardUrl = REPORT_FORM + REQ_FOR_EMD_REPORTS;
                break;

            case REQ_FOR_POS: //Added on 08.02.2021
                forwardUrl = REPORT_FORM + REQ_FOR_POS;
                break;
                
            case REQ_FOR_TODAYS_REP: //Added on 20.06.2020
                forwardUrl = REPORT_FORM + REQ_FOR_TODAYS_REP;
                break;

            case REQ_FOR_SHOW_TODAYS_REP: //Added on 20.06.2020
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                String todRepFor = request.getParameter("todRepFor");
                logger.info(" FromDt:" + fromDt + " ToDt:" + toDt);
                ArrayList alRepData = Deal.getTodaysRep(cmpMst.getCmpCd(), usrDetails, fromDt, toDt, todRepFor);
                request.setAttribute("Data", alRepData);

                forwardUrl = TODAYS_REP_URL;
                break;

            case REQ_FOR_RMA_STOCK_REP: //Added on 06.04.2021
                /*
                forwardUrl = REPORT_FORM + REQ_FOR_RMA_STOCK_REP;
                break;
                */
                //Commented above and modified as below on 26.10.2021
                alData = RMA.getRMAStockRep(cmpMst.getCmpCd(), usrDetails, null, null, "ALL");
                request.setAttribute("Data", alData);

                forwardUrl = RMA_STOCK_REP_URL;
                break;

            case REQ_FOR_SHOW_RMA_STOCK_REP: //Added on 06.04.2021
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                String rmaRepFor = request.getParameter("rmaRepFor");
                logger.info(" FromDt:" + fromDt + " ToDt:" + toDt);
                alData = RMA.getRMAStockRep(cmpMst.getCmpCd(), usrDetails, fromDt, toDt, rmaRepFor);
                request.setAttribute("Data", alData);

                forwardUrl = RMA_STOCK_REP_URL;
                break;
                
            case REQ_FOR_RECT_REP: //Added on 17.07.2020
                forwardUrl = REPORT_FORM + REQ_FOR_RECT_REP;
                break;

            case REQ_FOR_SHOW_RECT_REP: //Added on 17.07.2020
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                logger.info(" FromDt:" + fromDt + " ToDt:" + toDt);
                alData = Deal.getRectRep(cmpMst.getCmpCd(), usrDetails, fromDt, toDt);
                request.setAttribute("Data", alData);

                forwardUrl = RECT_REP_URL;
                break;

            case REQ_FOR_SHOW_ORDERS: //Added on 30.10.2019
                String ordStatus = request.getParameter("ordStatus");
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                //Added below 2 lines on 05.03.2021
                String filtBy = request.getParameter("filterBy");
                String filtTxt = request.getParameter("filt_txt");
                logger.info("OrdStat:" + ordStatus + " FromDt:" + fromDt + " ToDt:" + toDt + " FilterBy:" + filtBy + " FilterText:" + filtTxt);
                //alData = Deal.getDeals(cmpMst.getCmpCd(), usrDetails, fromDt, toDt, ordStatus);
                //Commented above and modified as below on 05.03.2021
                alData = Deal.getDeals(cmpMst.getCmpCd(), usrDetails, fromDt, toDt, ordStatus, filtBy, filtTxt);
                request.setAttribute("Data", alData);

                forwardUrl = ORDERS_LIST_URL;
                break;

            case REQ_FOR_SHOW_POS: //Added on 08.02.2021
                String poStatus = request.getParameter("ordStatus");
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                logger.info("OrdStat:" + poStatus + " FromDt:" + fromDt + " ToDt:" + toDt);
                alData = PurchaseOrder.getPOsList(cmpMst.getCmpCd(), usrDetails, fromDt, toDt, poStatus);
                request.setAttribute("Data", alData);

                forwardUrl = POS_LIST_URL;
                break;

            case REQ_FOR_BGS_LIST: //Added on 06.10.2020
                alData = Deal.getBGsList(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Data", alData);

                forwardUrl = BGS_LIST_URL;
                break;

            case REQ_FOR_PEND_EXP_VCHRS: //Added on 29.01.2021
                alData = Voucher.getPendExpVchrs(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Data", alData);

                forwardUrl = PEND_EXP_VCHRS_URL;
                break;

            case REQ_FOR_EXP_VCHRS_PAY: //Added on 11.02.2021
                alData = Voucher.getExpVchrsForPay(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Data", alData);

                forwardUrl = EXP_VCHRS_PAY_URL;
                break;

            case REQ_FOR_WARR_LAPSES_LIST: //Added on 19.03.2021
                alData = Product.getWarrLapsesList(cmpMst.getCmpCd(), usrDetails);
                request.setAttribute("Data", alData);

                forwardUrl = WARR_LAPSES_LIST_URL;
                break;

            case REQ_FOR_EXP_VCHRS_LIST: //Added on 11.02.2021
                forwardUrl = REPORT_FORM + REQ_FOR_EXP_VCHRS_LIST;
                break;

            case REQ_FOR_SHOW_EXP_VCHRS_LIST: //Added on 11.02.2021
                String vchrStatus = request.getParameter("ordStatus");
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                logger.info("VchrStat:" + vchrStatus + " FromDt:" + fromDt + " ToDt:" + toDt);
                alData = Voucher.getExpVchrs(cmpMst.getCmpCd(), usrDetails, fromDt, toDt, vchrStatus);
                request.setAttribute("Data", alData);

                forwardUrl = EXP_VCHRS_LIST_URL;
                break;
                
            case REQ_FOR_PROD_SNOS: //Added on 23.01.2020
                forwardUrl = REPORT_FORM + REQ_FOR_PROD_SNOS;
                break;

            case REQ_FOR_SHOW_PROD_SNOS: //Added on 23.01.2020
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                String repFormat = request.getParameter("repFormat");
                alData = Product.getProdSNOsForCRM(cmpMst.getCmpCd(), strOffCd, fromDt, toDt);
                request.setAttribute("Data", alData);
                forwardUrl = PROD_SNOS_URL;
                break;

            case REQ_FOR_UPL_DOCS_REP: //Added on 31.07.2020
                forwardUrl = REPORT_FORM + REQ_FOR_UPL_DOCS_REP;
                break;

            case REQ_TO_SHOW_UPL_DOCS_REP: //Added on 31.07.2020
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
                logger.info("FromDt:" + fromDt + " ToDt:" + toDt);
                alData = Deal.getUplDocsInfo(cmpMst.getCmpCd(), usrDetails, fromDt, toDt);
                request.setAttribute("Data", alData);

                forwardUrl = UPL_DOCS_REP_URL;
                break;

            case REQ_FOR_CO_DOCS: //Added on 05.01.2022
                alData = Deal.getCompanyDocs(cmpMst.getCmpCd());
                request.setAttribute("Data", alData);

                forwardUrl = CO_DOCS_REP_URL;
                break;

            case REQ_FOR_PEND_INST: //Added on 28.11.2019
                //ArrayList alInst = Deal.getPendInst(cmpMst.getCmpCd(), strOffCd, usrDetails);
                //Commented above and modified as below on 05.09.2020
                String pendStat = request.getParameter("stat");
                ArrayList alInst = Deal.getPendInst(cmpMst.getCmpCd(), strOffCd, usrDetails, pendStat);
                request.setAttribute("InstData", alInst);
                forwardUrl = PEND_INST_REPORT_URL;

                break;

            case REQ_FOR_PEND_PODS: //Added on 30.11.2019 //Pending for Proof of Delivery
                alData = Deal.getPendPODs(cmpMst.getCmpCd(), strOffCd, usrDetails);
                request.setAttribute("PODData", alData);
                forwardUrl = PEND_PODS_REPORT_URL;

                break;

            case REQ_FOR_PROD_LIST: //Added on 21.12.2019
                alData = Product.getProducts(cmpMst.getCmpCd(), "T", "ALL", null, false);
                request.setAttribute("Products", alData);
                forwardUrl = PROD_LIST_URL;
                break;

            case REQ_FOR_STOCK_REP: //Added on 30.09.2020
                alData = Product.getStockRep(cmpMst.getCmpCd(), usrDetails, null);
                request.setAttribute("Stock", alData);
                forwardUrl = STOCK_REP_URL;
                break;

            case REQ_FOR_STOCK_SUMMARY_REP: //Added on 08.06.2021
                alData = Product.getStockSummaryRep(cmpMst.getCmpCd(), usrDetails, null);
                request.setAttribute("Stock", alData);
                forwardUrl = STOCK_SUMMARY_REP_URL;
                break;

            case REQ_FOR_ENQUIRY_ENTRY_FORM: //Added on 14.02.2020
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("LeadSource", LeadSource.getFields()); //Added on 04.03.2020
                //Added below 2 lines on 28.04.2020
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());
                forwardUrl = ENQUIRY_ENTRY_FORM_URL;
                break;

            case REQ_FOR_CUST_ENTRY_FORM: //Added on 25.02.2020
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());
                forwardUrl = CUST_ENTRY_FORM_URL;
                break;

            case REQ_FOR_CUST_DECL_FORM: //Added on 30.06.2021
                request.setAttribute("cCmpCD", cmpMst.getCmpCd());
                forwardUrl = CUST_DECL_FORM_URL;
                break;

            case REQ_FOR_CUST_LIST: //Added on 27.02.2020
                alData = Customer.getCustomers(cmpMst.getCmpCd(), usrDetails, "ALL", null, "C"); //Added usrDetails on 02.08.2021
                request.setAttribute("Customers", alData);
                forwardUrl = CUST_LIST_URL;
                break;

            case REQ_FOR_ACT_ENQ: //Added on 06.03.2020
                alData = Enquiry.getEnquiries(cmpMst.getCmpCd(), usrDetails, "A");
                request.setAttribute("Enquiries", alData);
                request.setAttribute("PayTerms", PayTerms.getFields()); //Added on 31.03.2020
                //Added below on 15.05.2020
                String_contextPath = request.getServletPath();
                String_realPath = context.getRealPath(String_contextPath);
                String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                try {
                    obj = parser.parse(new FileReader(String_rootPath + "\\docs\\" + cmpMst.getCmpCd() + "PreDefQuotes.json"));
                    //ArrayList alPDQs = (ArrayList) obj;
                    //Commented above and modified as below on 29.06.2020
                    JSONObject alPDQs = (JSONObject) obj;
                    request.setAttribute("PDQs", alPDQs);
                } catch (ParseException ex) {
                    logger.error(ex);
                } catch (FileNotFoundException ex) {
                    logger.error(ex);
                } catch (IOException ex) {
                    logger.error(ex);
                }

                //Added above on 15.05.2020
                forwardUrl = ACT_ENQ_URL;
                break;

            case REQ_FOR_UN_ASSIGN_ENQ: //Added on 01.05.2020
                alData = Enquiry.getEnquiries(cmpMst.getCmpCd(), usrDetails, "UA");
                request.setAttribute("Enquiries", alData);
                request.setAttribute("PayTerms", PayTerms.getFields());
                alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                request.setAttribute("CrmUsers", alCrmUsers);
                request.setAttribute("LeadSource", LeadSource.getFields());
                request.setAttribute("Industries", Industry.getFields());
                request.setAttribute("OffTypes", OfficeTypes.getFields());
                forwardUrl = UN_ASSIGN_ENQ_URL;
                break;

            case REQ_FOR_PEND_RMA_REC: //Added on 29.08.2020
                //alData = RMA.getActiveRecords(cmpMst.getCmpCd(), usrDetails, "A");
                //Commented above and modified as below on 01.10.2021
                dealId = request.getParameter("rmaId");
                alData = RMA.getActiveRecords(cmpMst.getCmpCd(), usrDetails, "A", dealId);
                request.setAttribute("RMARecs", alData);
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData); //Added on 21.11.2020

                forwardUrl = PEND_RMA_REC_URL;
                break;

            case REQ_FOR_PEND_SERV_TICKETS: //Added on 01.10.2021
                //alData = ServiceCall.getServCallDtls(cmpMst.getCmpCd(), null, "P", null, null);
                //Commented above and modified as below on 24.11.2021
                alData = ServiceCall.getServCallDtls(usrDetails, null, "P", null, null);
                request.setAttribute("Data", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SOURCE);
                request.setAttribute("SCSource", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SW_ISSUE);
                request.setAttribute("SWIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_HW_ISSUE);
                request.setAttribute("HWIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_UIDAI_ISSUE);
                request.setAttribute("UidiaIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SUPP_MODE);
                request.setAttribute("SuppModes", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_STATUS);
                request.setAttribute("SCStatus", alData);
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData);

                forwardUrl = PEND_SERV_TICKETS_URL;
                break;
                
            case REQ_FOR_SERV_TICKETS: //Added on 04.10.2021
                forwardUrl = REPORT_FORM + REQ_FOR_SERV_TICKETS;
                break;

            case REQ_FOR_SHOW_SERV_TICKETS_LIST: //Added on 04.10.2021
                String tktStatus = request.getParameter("ordStatus");
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
//                logger.info("TktStat:" + tktStatus + " FromDt:" + fromDt + " ToDt:" + toDt);
                alData = ServiceCall.getServCallDtls(usrDetails, null, tktStatus, fromDt, toDt);
                request.setAttribute("Data", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SOURCE);
                request.setAttribute("SCSource", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SW_ISSUE);
                request.setAttribute("SWIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_HW_ISSUE);
                request.setAttribute("HWIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_UIDAI_ISSUE);
                request.setAttribute("UidiaIssues", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_SUPP_MODE);
                request.setAttribute("SuppModes", alData);
                alData = ServiceCall.getFields(ServiceCall.SC_STATUS);
                request.setAttribute("SCStatus", alData);
                alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                request.setAttribute("GDs", alData);

                forwardUrl = SERV_TICKETS_URL;
                break;

            case REQ_FOR_TENDER_ENRTY_FORM:
                request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                this.forwardUrl = "/jsp/crm/entries/tender-entry.jsp";
               break;

            case REQ_FOR_TENDER_MODIFY_FORM:
                String id=request.getParameter("id");
                Tender tender=TenderDao.getTenderById(this.cmpMst.getCmpCd(), id);
                request.setAttribute("Tender", tender);
                request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));               
                this.forwardUrl = "/jsp/crm/entries/tender-modify.jsp";
               break;

            case SHOW_TENDERS_REPORT:
                String status=request.getParameter("status");
                status=status==null?"active":status;
                List<Tender> tenderList;
                if(status.equalsIgnoreCase("Archieved")){
                    tenderList=TenderDao.getArchievedTenders(this.cmpMst.getCmpCd(), this.offMst.getId().getOffCd());
                }
                else{
                    tenderList=TenderDao.getTendersByStatus(this.cmpMst.getCmpCd(), this.offMst.getId().getOffCd(), status);
                }
                request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                request.setAttribute("TenderList", tenderList);
                this.forwardUrl = "/jsp/crm/reports/tenders.jsp";
               break;

            case SHOW_TENDER_DETAIL:
                request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                String tid=request.getParameter("id");
                tender=TenderDao.getTenderById(this.cmpMst.getCmpCd(),tid);
                request.setAttribute("Tender", tender);
                this.forwardUrl = "/jsp/crm/reports/tender-view.jsp";
               break;

            case REQ_FOR_TENDER_DOCS_UPLOAD_FORM:
                request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                String tenderId=request.getParameter("tenderId");
                tender=TenderDao.getTenderById(this.cmpMst.getCmpCd(),tenderId);
                request.setAttribute("Tender", tender);
                this.forwardUrl = "/jsp/crm/entries/tender-docs-upload.jsp";
               break;

            case REQ_FOR_TENDER_EMD_ENTRY:
                request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                this.forwardUrl = "/jsp/crm/entries/tender-emd-entry.jsp";
               break;

            case SHOW_TENDERS_EMD_REPORT:
//                String query=request.getParameter("query");
                String repStatus = request.getParameter("emdRepStatus");
                fromDt = request.getParameter("from_date");
                toDt = request.getParameter("to_date");
//                request.setAttribute("TenderEmdList", EMDDao.getEMDList(cmpMst.getCmpCd(),offMst.getId().getOffCd(),repStatus));
                request.setAttribute("TenderEmdList", EMDDao.getEMDList(cmpMst.getCmpCd(),offMst.getId().getOffCd(),fromDt,toDt,repStatus));
                
                this.forwardUrl = "/jsp/crm/reports/tenders-emd-report.jsp";
               break;

            case REQ_FOR_TENDER_EMD_MODIFY:
                {   
                    EMD emd=EMDDao.getEMD(cmpMst.getCmpCd(),request.getParameter("id"));
                    request.setAttribute("EMD", emd);
                    request.setAttribute("Tender", TenderDao.getTenderById(cmpMst.getCmpCd(),emd.getTenderId()));
                }
                this.forwardUrl = "/jsp/crm/entries/tender-emd-modify.jsp";
               break;
            
            case SHOW_TENDER_EXTEND_REPORT:
                {   
                    ArrayList alExtendReport=TenderDao.getExtendReport(cmpMst.getCmpCd(),request.getParameter("id"));                    
                    request.setAttribute("ExtendReport", alExtendReport);
                    request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                }
                this.forwardUrl = "/jsp/crm/reports/tender-extend-report.jsp";
               break;

            case SHOW_TENDERS_BY_APPROVAL:
                {   
                    status=request.getParameter("status");
                    status=(status==null||status.isEmpty())? "P":status;
                    tenderList=TenderDao.getTendersByApproval(cmpMst.getCmpCd(), offMst.getId().getOffCd(), status);                    
                    request.setAttribute("CrmUsers", User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F"));
                    request.setAttribute("TenderList", tenderList);
                }
                this.forwardUrl = "/jsp/crm/reports/tenders-for-approval.jsp";
               break;
              
                /*following lines added on 31stMay 2023 for Additional component : DC Challan*/    
                case NEW_DC:
                    forwardUrl = DC_FORM_URL;
                    break;
                    
                case PEND_DC:
                logger.info("reached Pending DC report");
                ArrayList pendDcData = DeliveryChallan.getPendDc(cmpMst.getCmpCd());
                logger.info("pendDcData: "+pendDcData.toString());
                request.setAttribute("pendDcData",pendDcData);
                   forwardUrl = DC_PEND_FORM;
                   break;
                case REQ_FOR_STOCK_TR_PENDING:
                    ArrayList stPendData = StockTransfer.getPendSt(cmpMst.getCmpCd());
                    request.setAttribute("pendStData", stPendData);
                    forwardUrl = GET_STOCK_TFP_URL;
                    break;
                case REQ_FOR_STOCK_TR_FORM: // Added on 26.10.2023 
                    alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                    request.setAttribute("GDs", alData);
                    forwardUrl = GET_STOCK_TF_URL;
                    break;
                case REQ_FOR_STOCK_TR_MODIFY:
                    logger.info("we reached to stock transfer modify");
                    alData = Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(), "GD");
                    request.setAttribute("GDs", alData);
                    HashMap stMap = new HashMap();
                    stMap.put("stNo", (String) request.getParameter("stNo"));
                    stMap.put("stId", (String) request.getParameter("stId"));
                    ArrayList editDtls = StockTransfer.getStModifyDtls(cmpMst.getCmpCd(), stMap);
                    logger.info("Modify Stock TR : "+editDtls);
                    request.setAttribute("editDtls", editDtls);                    
                    forwardUrl = GET_STOCK_TR_MODIFY_URL;
                    break;             
                    
                // Added below lines of code on 07.04.2023    
                case REQ_FOR_COURIER_CONF_JSON:                
                    forwardUrl = COURIER_CONF_JSON_URL;
                    break;
                case REQ_FOR_PRODUCT_CATEGORY_CONF_JSON:                
                    forwardUrl = PRODUCT_CATEGORY_JSON_URL;
                    break;
                case REQ_FOR_INDIAN_STATES_CONF_JSON:                
                    forwardUrl = INDIAN_STATES_CONF_JSON_URL;
                    break;                
                //Added below lines of code on 05.03.2024
                case REQ_FOR_RFQ_ENTR:
                    alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                    request.setAttribute("CrmUsers", alCrmUsers);
                    request.setAttribute("PayTerms", PayTerms.getFields());
                    request.setAttribute("Industries", Industry.getFields());
                    request.setAttribute("OffTypes", OfficeTypes.getFields()); 
                    forwardUrl = RFQ_ENTR_FORM_URL;
                    break;    
                //Added below lines of code on 06.03.2024
                case REQ_FOR_RFQ_LIST:
                    alCrmUsers = User.getCrmUsers(cmpMst.getCmpCd(), strOffCd, "ALL", "F");
                    request.setAttribute("CrmUsers", alCrmUsers);
                    request.setAttribute("PayTerms", PayTerms.getFields());
                    request.setAttribute("Industries", Industry.getFields());
                    request.setAttribute("OffTypes", OfficeTypes.getFields());                  
                    ArrayList quoteList = RequestForQuotation.getQuoteDtls(strOffCd, usrDetails.getId().getUsrId());                                       
                    request.setAttribute("RfqData",quoteList);                    
                    forwardUrl = REQ_FOR_RFQ_LIST_URL;
                    break;
                    
                 // Following Lines of code added on 14-03-24
                   case REQ_FOR_QUOTE_RFQ: //Added on 08.04.2020
                        dealId = request.getParameter("quoteId");
                        String qType1 = request.getParameter("qType");
                        ArrayList alQuote1 = Enquiry.getQuoteInfo(cmpMst.getCmpCd(), dealId);
                        request.setAttribute("QuoteInfo", alQuote1);
                        if (qType1.isEmpty()) {
                            forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "Quotation.jsp";
                        } else if (qType1.equalsIgnoreCase("HQ")) {
                            forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "HealthQuote.jsp";
                        } else if (qType1.equalsIgnoreCase("PD")) { //Added on 26.06.2020
                            String_contextPath = request.getServletPath();
                            String_realPath = context.getRealPath(String_contextPath);
                            String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                            try {
                                obj = parser.parse(new FileReader(String_rootPath + "\\docs\\" + cmpMst.getCmpCd() + "PreDefQuotes.json"));
                                //JSONArray arPdQuotes = (JSONArray) obj;
                                //Commented above and modified as below on 29.06.2020
                                JSONObject arPdQuotes = (JSONObject) obj;
                                request.setAttribute("PdQuotes", arPdQuotes);
                            } catch (ParseException ex) {
                                logger.error(ex);
                            } catch (FileNotFoundException ex) {
                                logger.error(ex);
                            } catch (IOException ex) {
                                logger.error(ex);
                            }

                            forwardUrl = "/jsp/crm/reports/" + cmpMst.getCmpCd() + "PreDefQuote.jsp";
                        }
                    break;  
                    case REQ_FOR_QUOTE_VEND_FORM:
                        logger.info("we reached to quotation response form");
                        String tokenString = request.getParameter("tokenKey");
                        logger.info("toekn :"+tokenString.trim());
                        SecretKey key = new SecretKeySpec(CrmProperties.SECRET.getBytes(),"AES");
                        TokenSecurity encrypter = new TokenSecurity(key);
                        String decryptToken = encrypter.decrypt(tokenString.trim());  
                        logger.info("Decrypted : "+decryptToken);  
                        String[] tknSplit = decryptToken.replace(":", ",").split(",");
                        String qtId = tknSplit[2];
                        String vendId = tknSplit[1]; 
                        String cmpCd = tknSplit[0];
                        request.setAttribute("vendId", vendId);
                        request.setAttribute("cmpCd", cmpCd);
//                        request.setAttribute("usrId", tknSplit[0]);
//                        request.setAttribute("usrPwd", tknSplit[1]);
                        request.setAttribute("vendProdDtls", RequestForQuotation.getProductDtls(cmpCd, qtId, vendId));
                        request.setAttribute("quoteStatus", RequestForQuotation.getQuoteStatus(cmpCd,qtId));
                        request.setAttribute("PayTerms", PayTerms.getFields());
                        forwardUrl = REQ_FOR_QUOTE_VEND_URL;                    
                        break;
                    case REQ_FOR_QUOTE_VEND_DTLS_RESPONSE:
                        request.setAttribute("rfqVendRespDtls", "");                        
                        forwardUrl = GET_FOR_QUOTE_VEND_RESP_URL;
                        break;
                        
                    case SHOW_GRN_REP:
                        fromDt = (String)request.getParameter("from_date");
                        toDt = (String)request.getParameter("to_date");
                        String product_id = (String)request.getParameter("product_id");
                        String entType = (String)request.getParameter("entryType");
                        String godown = (String) request.getParameter("s_godown");                        
                        alData = PurchaseOrder.getGRNInfo(cmpMst.getCmpCd(),usrDetails.getOffMst().getId().getOffCd(),fromDt,toDt,product_id,godown,entType);
                        request.setAttribute("Data", alData);
                        forwardUrl = GRN_REPORT_URL;
                    break;
                    
                    case GRN_REPORT:
                    ArrayList ProdList= Product.getProducts(cmpMst.getCmpCd(), "T", "ALL", null, false);
                    ArrayList godown_types=Office.getAllOfficeHeirarchy(cmpMst.getCmpCd(), usrDetails.getOffMst().getId().getOffCd(),"GD");
                    request.setAttribute("ProdList", ProdList);
                    request.setAttribute("godown_types",godown_types);
                    forwardUrl = REPORT_FORM + "getGRNReport";
                    break;
                    
                    // Added below 1 case for Reminder notification on 25.01.2025 by Rabindra Sharma
                    // As per discussion with Mr. Ramnath sir
                    case REQ_FOR_REMINDER_ENTRY:               
                        logger.info("we reached to creating reminder notification page");                        
                        forwardUrl = GET_REMINDER_ENTRY_URL;
                    break;
                    case REQ_FOR_REMINDER_REPORT:
                        request.setAttribute("remReports", Reminder.getReminderDtls(cmpMst.getCmpCd(), usrDetails.getUloginId(), strOffCd));
                        logger.info("we reached to reminder reports page");                                               
                        forwardUrl = GET_REMAINDER_REPORT_URL;
                        break;
        }
        return request.getRequestDispatcher(response.encodeURL(forwardUrl));
    }

}
