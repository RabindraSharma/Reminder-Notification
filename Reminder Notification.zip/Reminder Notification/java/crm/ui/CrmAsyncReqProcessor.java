package crm.ui;
import bioas.master.db.Office;
import bioas.util.GenConstants;
import bioas.util.SendMailUsingAuthentication;
import bioas.util.Utilities;
import bioas.util.beans.CmpMst;
import bioas.util.beans.Login;
import crm.beans.EMD;
import crm.beans.Tender;
import crm.dao.DocumentDao;
import crm.dao.EMDDao;
import crm.dao.JSONConfig;
import crm.dao.TenderDao;
import crm.db.BusinessTargets;
import crm.db.CrmAsyncDbManager;
import crm.db.Customer;
import crm.db.Deal;
import crm.db.DeliveryChallan;
import crm.db.Enquiry;
import crm.db.LeadSource;
import crm.db.Product;
import crm.db.PurchaseOrder;
import crm.db.Query;
import crm.db.RMA;
import crm.db.Reminder;
import crm.db.ServiceCall;
import crm.db.ServiceContract;
import crm.db.StockTransfer;
import crm.db.Voucher;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import javax.mail.MessagingException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import crm.db.RequestForQuotation;
import crm.db.TokenSecurity;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class CrmAsyncReqProcessor {

    private static final Logger logger = Logger.getLogger(CrmAsyncReqProcessor.class);
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy"); //Added on 29.04.2020
    private static final SimpleDateFormat sdf_Time = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss"); //Added on 04.06.2021
    private static final SimpleDateFormat sdf_YYYMMDD_HHmmss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //Added on 18.10.2021

    private static final String FILE_DIR_PATH = "/MySavedFiles"; //Added on 25.10.2019
    private static final String CHECK_DEAL_NAME_EXISTS = "chkDealExists";
    private static final String CHECK_DEAL_ID_EXISTS = "chkDealIdExists"; //Added on 22.09.2020
    private static final String CHECK_PRODUCT_EXISTS = "isProdExists"; //Added on 16.12.2019
    private static final String CHECK_CUST_EXISTS = "chkCustExists"; //Added on 26.02.2020
    private static final String CHECK_ENQ_EXISTS = "chkEnqExists"; //Added on 04.03.2020
    private static final String INSERT_DEAL = "insDeal";
    private static final String INSERT_SERV_CONTRACT = "insServContr"; //Added on 18.09.2020
    private static final String UPDATE_SERV_CONTRACT = "updServContr"; //Added on 14.10.2020
    private static final String UPDATE_DEAL = "updDeal"; //Added on 20.07.2020
    private static final String UPDATE_DEAL_STAT = "updDealStat"; //Added on 11.12.2020
    private static final String APPROVE_E_VOUCHER = "apprEVchr"; //Added on 30.01.2021
    private static final String UPD_E_VCH_PAY_DTLS = "updEVchrPD"; //Added on 11.02.2021
    private static final String INSERT_QUOTE = "insQuote"; //Added on 04.04.2020
    private static final String INSERT_PRODUCT = "insProd"; //Added on 17.12.2019
    private static final String UPDATE_PRODUCT = "updProd"; //Added on 10.06.2021
    private static final String INSERT_CUSTOMER = "insCust"; //Added on 26.02.2020
    private static final String INSERT_ENQUIRY = "insEnq"; //Added on 04.03.2020
    private static final String UPDATE_UN_ASSIGN_ENQUIRY = "updUnAssignEnq"; //Added on 01.05.2020
    private static final String UPDATE_ENQUIRY = "updEnq"; //Added on 28.03.2020
    private static final String PENDING_DEALS_COUNT = "pendDealsCount";
    private static final String PENDING_SERV_CONTR_COUNT = "pendSCCount"; //Added on 01.02.2021
    private static final String DEALS_COUNT = "dealsCount"; //Added on 23.10.2019
    private static final String ENQ_COUNTS = "enqCounts"; //Added on 03.07.2020
    private static final String PENDING_PROCURE_COUNT = "pendProcureCount"; //Added on 21.06.2019
    private static final String PENDING_SHIPMENT_COUNT = "pendShipmCount"; //Added on 01.11.2019
    private static final String PENDING_INST_COUNT = "pendInstCount"; //Added on 28.11.2019
    private static final String INSERT_DEAL_DETAILS = "insDealDetails";
    private static final String UPDATE_DEAL_ADDR = "updDealAddr"; //Added on 13.10.2020
    private static final String INSERT_SERV_CONTR_DETAILS = "insSCDetails"; //Added on 19.09.2020
    private static final String INSERT_PO = "insPO"; //Added on 21.07.2020
    private static final String INSERT_PO_DETAILS = "insPODetails";
    private static final String UPD_DEAL_INV_DETAILS = "updDealInvDtls";
    private static final String UPD_SERV_CONTR_INV_DETAILS = "updSContrInvDtls"; //Added on 21.09.2020
    private static final String GET_DEAL_DETAILS = "getDealDetails";
    private static final String GET_DEAL_PRIMARY_INFO = "getDealPRI"; //Added on 06.10.2020
    private static final String GET_SERV_CONTR_DETAILS = "getSCDetails"; //Added on 19.09.2020
    private static final String GET_DEAL_INVOICES = "getDealInv";
    private static final String GET_DEAL_ALL_INVOICES = "getDealAllInv"; //Added on 24.09.2020
    private static final String GET_SERV_CONTR_INVOICES = "getContrInv"; //Added on 22.09.2020
    private static final String GET_SERV_CONTR_ALL_INVOICES = "getContrAllInv"; //Added on 11.03.2021
    private static final String GET_DEAL_INV_DTLS = "getDealInvDtls";
    private static final String GET_SERV_CONTR_INV_DTLS = "getContrInvDtls"; //Added on 22.09.2020
    private static final String GET_PEND_PO_ITEMS = "getPendPOItems"; //Added on 07.09.2020
    private static final String GET_DEAL_INV_DTLS_PACK = "getDealInvDtlsPack"; //Added on 25.07.2019
    private static final String INS_DEAL_INV_SNOS = "insDealInvSNOs";
    private static final String INS_SERV_CONTR_INV_SNOS = "insContrInvSNOs"; //Added on 22.09.2020
    private static final String INS_INW_STOCK = "insInwStk"; //Added on 08.09.2020
    private static final String INS_STOCK = "insStock"; //Added on 30.09.2020
    private static final String UPD_RETURN_DTLS = "updReturnDtls"; //Added on 24.06.2021
    private static final String GET_DEAL_INV_PACK = "getDealInvPack";
    private static final String GET_PEND_DEAL_INV_INST = "getDealInvForInst"; //Added on 20.06.2020
    private static final String INS_DEAL_PACK_LIST = "insDealPackList";
    private static final String GET_INV_PACK_LIST = "getInvPackList";
    private static final String GET_DEAL_STK_DTLS = "getDealStkDtls";
    private static final String UPD_DEAL_STK_STAT = "updDealStkStat";
    private static final String GET_INV_STICKER_INFO = "getStickerInfo";
    private static final String GET_INV_FOR_SHIPM = "getInvForShip";
    private static final String INS_INV_SHIPM_DTLS = "insInvShipDtls";
    private static final String UPD_INV_SHIPM_DTLS = "updInvShipDtls"; //Added on 02.12.2020
    private static final String INS_RMA_SHIPM_DTLS = "insRmaShipDtls"; //Added on 12.11.2020
    private static final String INS_RMA_TSSC_DTLS = "insTSSCDtls"; //Added on 20.11.2020
    private static final String SEND_QUOTE = "sendQuote"; //Added on 10.04.2020
    private static final String SEND_PRO = "sendPRO"; //Added on 07.08.2020
    private static final String SEND_SERV_INV = "sendServInv"; //Added on 12.10.2020
    private static final String SEND_MAIL = "sendMail"; //Added on 10.04.2020
    private static final String GET_PEND_CNS_FOR_DELV = "getPendCNsForDelv";
    private static final String GET_PEND_CNS_FOR_PAY = "getPendCNsForPay"; //Added on 30.03.2021
    private static final String GET_PAID_CNS = "getPaidCNs"; //Added on 02.04.2021
    private static final String GET_PEND_CN_DTLS = "getPendCNDtls";
    private static final String GET_CN_DELV_DTLS = "getCNDelvDtls"; //Added on 16.03.2021
    private static final String UPD_CN_DELV_DATE = "updCNDelvDate";
    private static final String GET_PEND_DELV_COUNT = "getPendDelvCount";
    private static final String UPD_PR_PO_DTLS = "updPrPoDtls";
    private static final String UPD_MAT_RECD_ON = "updMatRecdOn";
    private static final String UPD_RECT_DTLS = "updRectDtls"; //Added on 11.07.2020
    private static final String GET_COURIERS_LIST = "getCouriers"; //Added on 26.07.2019
    private static final String ACTIVE_PROJECTS_COUNT = "actProjCount"; //Added on 03.12.2019
    private static final String TODAYS_COUNT = "todaysCount"; //Added on 19.06.2020
    private static final String RMA_COUNT = "rmaCount"; //Added on 07.10.2020
    private static final String OTH_COUNT = "othCount"; //Added on 29.01.2021
    private static final String GET_DEAL_CONTACTS = "getDealContacts"; //Added on 04.12.2019
    private static final String GET_STATES = "getStates"; //Added on 13.12.2019
    private static final String GET_MATCHING_PRODUCTS = "getMatchingProd"; //Added on 18.12.2019
    private static final String GET_PROD_INFO = "getProdInfo"; //Added on 18.12.2019
    private static final String GET_MATCHING_CUST = "getMatchingCust"; //Added on 29.02.2020
    private static final String GET_CUST_ADDR = "getCustAddr"; //Added on 03.08.2021
    private static final String ACTIVE_ENQUIRIES_COUNT = "actEnqCount"; //Added on 05.03.2020
    private static final String UN_ASSIGN_ENQUIRIES_COUNT = "unAssignEnqCount"; //Added on 01.05.2020
    private static final String GET_EWB_JSON = "getEWBJson"; //Added on 05.03.2020
    private static final String GET_PR_INFO_FOR_SNO = "getInfoForSNo"; //Added on 19.08.2020
    private static final String INS_RMA_INW_REQ = "insRMAReq"; //Added on 25.08.2020
    private static final String INS_SERV_CALL = "insServCall"; //Added on 11.08.2021
    private static final String GET_SERV_CALL_INFO = "getSCInfo"; //Added on 30.09.2021
    private static final String CHK_RMA_REFNO = "chkRMARefNo"; //Added on 26.08.2020
    private static final String CHK_DEAL_INVNO = "chkDealInvNo"; //Added on 28.01.2021
    private static final String CHK_SERV_CONTR_INVNO = "chkSCInvNo"; //Added on 10.02.2021
    private static final String CHK_PONO = "chkPONo"; //Added on 10.02.2021
    private static final String APPR_RMA_REQ = "apprRmaReq"; //Added on 17.09.2020
    private static final String UPD_RMA = "updRMA"; //Added on 02.02.2021
    private static final String UPD_RMA_REMARKS = "updRmaRem"; //Added on 23.11.2021
    private static final String UPD_RMA_TCHK_STATUS = "updRmaTchkStat"; //Added on 18.03.2021
    private static final String UPD_RMA_TSSC_STATUS = "updRmaTsscStat"; //Added on 26.06.2021
    private static final String INS_BUSINESS_TARGETS = "insBusTargets"; //Added on 24.03.2021
    private static final String GET_BUSINESS_TARGETS = "getBusTargets"; //Added on 24.03.2021
    private static final String GET_TARG_ACHV_DATA = "getTargVsAchvData"; //Added on 26.03.2021

    private static final String SEND_MSG = "sendMsg"; //Added on 10.04.2021
    private static final String RAISE_QUERY = "raiseQuery"; //Added on 29.05.2021
    private static final String GET_QUERIES = "getQueries"; //Added on 02.06.2021

    private static final String GET_IMAGES_LIST = "getImages"; //Added on 19.06.2021

    private static final String CRM_NOTIFY_INFO = "crmNotifInfo"; //Added on 18.05.2020
    
    //Added below 11 lines on 28.01.2022
    private static final String INSERT_TENDER="insTender";
    private static final String UPDATE_TENDER="updTender";
    private static final String CHECK_UNIQUE_TENDER_NO="chkTenderNo";
    private static final String DELETE_DOCUMENT="delDocs";
    private static final String TENDER_COUNT="getTndCount";
    private static final String TENDER_MOVE_TO_ARCHIVE="mv2Archive";
    private static final String TENDER_REMOVE_FROM_ARCHIVE="rmv2Archive";
    private static final String TENDER_APPROVE="approveTender";
    private static final String TENDER_UPDATE_STATUS="updTndStatus";
    private static final String TENDER_ADD_NEW_STATUS="addTndStatus";
    private static final String TENDER_EXTEND_DATES="extTndDates";
    private static final String TENDER_DETAILS_FOR_EMD="getTndForEMD";
    private static final String INSERT_TENDER_EMD="insTndEMD";
    private static final String UPDATE_TENDER_EMD="updTndEMD";
    private static final String UPDATE_TENDER_EMD_STATUS="updateEmdStatus";
    
    // Added below some lines on 07.04.2023 by Rabindra Sharma
    
    private static final String GET_COURIER_JSON_DATA = "getCurJsonData";
    private static final String CREATE_UPDATE_COURIER_JSON = "cupCourierJson";
    private static final String DELETE_REQUEST_COURIER_ITEM = "deleteCurItem";
    
    // Added below few lines on 25-04-2023 by Rabindra Sharma
    
    private static final String GET_PRODUCT_CATEGORY = "getProdCatList";
    private static final String ADD_UPDATE_PRODUCT_CATEGORY_JSON = "addUpdateProductCategory";
    private static final String DELETE_PRODUCT_ITEMS_BY_IDS = "deleteProdItemByIds";
    
    private static final String REQ_FOR_GET_INDIAN_STATES = "getIndianStates";
    private static  final String ADD_UPDATE_INDIAN_STATE_JSON = "addUpdateIndianStates";
    private static final String DELETE_INDIAN_STATE_BY_IDS = "deleteIndianStateByIds";
    
    // Added below lines for invoice operation on 06-05-2023 By Rabindra Sharma
     private static final String UPDATE_INVOICE = "updateInv"; 
     private static final String REMOVE_INVOICE = "removeInv";
     
     private static final String CHK_MATERIAL_ALLOC_EXISTS = "checkMatExists";
     private static final String IS_EXISTS_MATPACK_AND_MATSHIP = "isExistsMatPackAndMatShip";
     private static final String DE_ALLOCATE_MATERIAL = "deAllocateMat";
     
     private static final String UN_PACK_WITH_INVNO = "unPackwithInvno";
     private static final String UN_PACK_WITH_PLNO = "unPackWithPlno";
     private static final String UN_PACK_WITH_PROD_GRP_ID = "unPackWithProdGrpId";
     
     private static final String CHK_SHP_DELV_DATE  = "checkShpDelvDate";
     private static final String REVERSE_SHP_DTLS = "reverseShpmDtls";
     
     private static final String CHK_INST_DATE_ISCOMPLT = "checkInstDisComplt";
     private static final String REVERSE_DELV_DATE = "reverseDelvDate";
     private static final String REVERSE_INST_REPORTS = "reverseInstReports";
     
     private static final String IS_PROD_IN_STOCK = "isProdInStock"; // 28-05-2023 by Rabindra Sharma
     private static final String REVERSE_STOCK_STATUS = "reverseStockStatus"; // 28-05-2023 by Rabindra Sharma
     private static final String CHK_STOCK_STATUS = "chkStockStatus"; // 03-06-2023 by Rabindra Sharma
     //Added below on 6 June 2023 by Rabindra Sharma
     private static final String MODIFY_PSWD = "changePswd";
     
     /*bELOW TWO LINES ADDED ON 02 JUNE 2023*/
     private static final String GET_DEAL_LOCATIONS = "getDealLoc"; 
     private static final String DC_ENTRY = "DCEntry";
     private static final String GET_DC_DTLS ="getDcDetails";
     private static final String ALLOCATE_DC_PRODS = "allDcProds";
     private static final String GET_DC_DTLS_FOR_PKG = "getDcDtlsForPkg";
     
     // below 2 line added on 26-10-2023 by Rabindra Sharma
     private static final String INS_STOCK_TRANSFER = "insStockTransfer";
     private static final String ALLOCATE_ST_PRODS = "allStProds";
     private static final String GET_STOCK_TR_DTLS = "getStockTDetails";
     // below 1 line added on 01.11.2023 by Rabindra Sharma
     private static final String GET_STOCK_TR_DTLS_PKG = "getStPckgDtls";
     
     // below 1 line added on 02.11.2023 by Rabindra Sharma
     private static final String INS_STOCK_TR_PACK_LIST = "insStPackList";
     // below 2 line added on 03.11.2023 by Rabindra Sharma
     private static final String GET_STOCK_TR_PACK_LIST = "getSTPackList";
     private static final String GET_STOCK_TR_STICKER_INFO = "getStStickerInfo";
     //below 4 line added on 04.11.2023 by Rabindra Sharma
     private static final String GET_STOCK_TR_SHIPM_DTLS  = "getStDtlsForShipm";
     private static final String GET_STOCK_TR_WEB_JSON = "getStWEBJson";
     private static final String INS_STOCK_TR_SHIPM_DTLS = "insStForShipmDtls";
     private static final String UPD_STOCK_TR_SHIPM_DTLS = "updStForShipmDtls";
     // bekow 3 line added on 08.11.2023 by Rabindra Sharma
     private static final String GET_STOCK_TR_FOR_DELV = "getStForPenDelv";
     private static final String GET_STOCK_TR_CN_DTLS = "getStForPenCnDtls";
     private static final String UPD_STOCK_TR_CN_DELV_DATE = "updStCNDelvDate";
     
     // below 1 line added on 08.11.2023 by Rabindra Sharma
     private static final String GET_OFF_ADDRESS = "getOffAddr"; 
     // below 1 line added on 14.11.2023 by Rabindra Sharma
     private static final String GET_STOCK_STATUS_DTLS = "getStockStDtls";
     private static final String GET_STOCK_TR_STATUS_DTLS = "getStSDetails";
     // below 1 line added on 15.11.2023 by Rabindra Sharma
     private static final String INS_AND_UPD_STOCK_STATUS = "insAndUpdStStatus";
     // below 1 line added on 05.03.2024 by Rabindra Sharma
     private static final String INS_RFQ = "insRFQ";
     private static final String SEND_QUOTE_RFQ = "sendQuoteRFQ";
     private static final String FETCH_VEND_RESPONSE_DTLS = "getVendRespDtls";
     private static final String GENERATE_PO_RFQ = "autoGenPo";
     
     // Added below 1 line for reverse GRN no with invoice on 21.01.2025 by Rabindra Sharma and suggested by Akanksha.     
     private static final String REQ_FOR_REVERSE_GRN = "reverseGRN";
     
     private static final String INS_REMINDER = "insRemainder"; // Added on 25.01.2025 by Rabindra Sharma


     
     
     
     
     
     
    private CmpMst cmpMst;
    private String oprx = null;
    PrintWriter pw = null;
    public ServletContext context;
    
    //Added by Rabindra sharma on 01-04-2024
     CrmProperties prop;

    //Added below 4 lines on 24.10.2019
    String emAuthUser;
    String emAuthUserPW;
    String smtpHost;
    String smtpPort;

    //Added below 2 lines on 29.04.2020
    String efToMailIDs;
    String efMainUser;

    //Added below 2 lines on 05.07.2021
    boolean isDeveloper;
    String strEnv;

    public ServletContext getContext() {
        return context;
    }

    public void setContext(ServletContext context) {
        this.context = context;        
    }

    public void requestProcessor(HttpServletRequest request, HttpServletResponse response) throws ParseException, FileUploadException {
        String strCmpCd;
        String strLoginId = null;
        String strOffTyp = null;
        String strOffCd = null;
        String strFinYrBegin = null;
        String strFinYrEnd = null;
        String UserType = null;
        
        
        
        
          
        //Added below 4 lines on 24.10.2019
        emAuthUser = request.getServletContext().getInitParameter("authuser");
        emAuthUserPW = request.getServletContext().getInitParameter("authpass");
        smtpHost = request.getServletContext().getInitParameter("smtphost");
        smtpPort = request.getServletContext().getInitParameter("port");

        //Added below 2 lines on 29.04.2020
        efToMailIDs = request.getServletContext().getInitParameter("enqf_to_emids");
        efMainUser = request.getServletContext().getInitParameter("enqf_mu");

        //Added below 3 lines on 05.07.2021
        strEnv = request.getServletContext().getInitParameter("Environment");
        strEnv = strEnv == null ? "PRODUCTION" : strEnv;
        isDeveloper = strEnv.equalsIgnoreCase("DEVELOPER");
        
        

        HttpSession session = request.getSession();
        Login login_dtls = (Login) session.getAttribute(GenConstants.SESSION_ATTRIBUTE_NAME);

        if (login_dtls == null) {                      
            strCmpCd = request.getParameter("mainCd"); 
//            logger.info("CmpCd : "+strCmpCd);            
//            JSONObject json = new JSONObject();
//            try{
//                pw = response.getWriter();
//                json.put("Result", "Session Expired");
//                pw.println(json);    
//                logger.info("Response Sent :");   
//                return;
//            }catch(IOException ex){                
//                logger.info(ex);
//            }
        } else {
            strCmpCd = login_dtls.getId().getCmpCd();
            strLoginId = login_dtls.getId().getUsrId();
            strOffTyp = login_dtls.getOffMst().getOffTypes().getId().getOffType();
            strOffCd = login_dtls.getOffMst().getId().getOffCd();
            strFinYrBegin = login_dtls.getCmpMst().getFinancialYr().getFin_yr_begin();
            strFinYrEnd = login_dtls.getCmpMst().getFinancialYr().getFin_yr_end();
            //UserType = login_dtls.getUserType();
            //Commented above and modified as below on 11.10.2019
            UserType = login_dtls.getCrmUserType();
            if (login_dtls.getCmpMst().geteMailESCL() != null) { //Added on 13.01.2020
                emAuthUser = login_dtls.getCmpMst().geteMailESCL();
                emAuthUserPW = login_dtls.getCmpMst().geteMailEsclPw();
                smtpHost = login_dtls.getCmpMst().getSmtpServer();
                smtpPort = String.valueOf(login_dtls.getCmpMst().getSmtpPort());
            }
        }

        oprx = request.getParameter(GenConstants.OPERATION_AJAX);
        response.setContentType("text/xml");
        logger.info(oprx);
        
        
        try {
            pw = response.getWriter();
            JSONObject json = new JSONObject();
            String dealId;
            String rmaId; //Added on 19.11.2020
            String dealRowId;
            String strResp;
            ArrayList alData;
            int items;
             int Po_id;
            String invNo;
            int iCount;
            String cnNo;
            boolean bStat; //Added on 26.02.2020
            JSONParser parser = new JSONParser();
            Object obj;
            //Added below 3 lines on 07.11.2019
            String String_contextPath;
            String String_realPath;
            String String_rootPath;
            HashMap hmData; //Added on 28.03.2020
            String custId; //Added on 01.05.2020
            String custAddrId; //Added on 21.09.2020
            String custName; //Added on 01.05.2020
            String custType; //Added on 20.07.2020
            //Added below 2 lines on 11.08.2020
            String payTerms;
            String othTOP;
            String prName; //Added on 19.08.2020
            StringBuilder sb; //Added on 15.09.2020
            String[] emIDs; //Added on 12.10.2020
            JSONObject jsoCont; //Added on 14.10.2020
            JSONArray jsaCont; //Added on 20.03.2021
         // following 1 line added on 15 June 2023
            String dcNo = "";
         // following 1 line added on 30.10.2023
            String stNo = "";
            if(strCmpCd==null){
                response.setStatus(408);
            }else{
            switch (oprx) {
                case GET_COURIERS_LIST: //Added on 26.07.2019
                    //JSONParser parser = new JSONParser();
                    //Object obj;
                    String String_contP = request.getServletPath();
                    String String_realP = context.getRealPath(String_contP);
                    String String_rootP = String_realP.substring(0, String_realP.lastIndexOf("\\"));
                    try {
                        obj = parser.parse(new FileReader(String_rootP + "\\docs\\" + strCmpCd + "Couriers.json"));
                        json.put("CourierDtls", (JSONArray) obj);
                    } catch (ParseException ex) {
                        logger.error(ex);
                    }
//                    logger.info(json.toString());
                    pw.println(json);
                    break;

                case GET_IMAGES_LIST: //Added on 19.06.2021
                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));

                    alData = new ArrayList();

                    String id = request.getParameter("id");
                    String imagesFor = request.getParameter("imagesFor");

                    Path dir = Paths.get(String_rootPath + "\\MySavedFiles");
                    String fName = strCmpCd + "_" + id + "_";
                    if (imagesFor.equalsIgnoreCase("PRODUCT")) {
                        fName = fName.concat("PR_IMG_*.*");
                    } else {
                        fName = fName.concat("RMA_IMG_*.*");
                    }
                    logger.info(fName);
                    try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, fName)) {
                        for (Path entry : stream) {
                            logger.info(entry.getFileName());
                            alData.add("\\MySavedFiles\\" + entry.getFileName());
                        }
                    } catch (IOException x) {
                        // IOException can never be thrown by the iteration.
                        // In this snippet, it can // only be thrown by newDirectoryStream.
                        logger.error(x);
                    }
                    json.put("Files", alData);
                    pw.println(json);
                    break;

                case SEND_MSG: //Added on 10.04.2021
                    logger.info("At SEND_MSG");
                    String msg = request.getParameter("msg");
                    String msgFor = request.getParameter("msgFor");
                    logger.info("Message: " + msg + " For: " + msgFor);
                    //Added below lines on 01.06.2021
//                    String refType = "NM";
                    String refType = request.getParameter("refType");
                    String msgId = request.getParameter("msgId");
                    String msgView = request.getParameter("msgView");
                    hmData = new HashMap();
                    hmData.put("RefType", refType);
                    hmData.put("RefId", "");
                    hmData.put("ForUser", msgFor);
                    hmData.put("FromUser", strLoginId);
                    hmData.put("Query", msg);
                    hmData.put("MsgId", msgId);
                    hmData.put("MsgView", msgView);
                    logger.info(hmData);
                    msgId = msgId == null ? "" : msgId;
                    if (msgId.isEmpty()) {
                        strResp = Query.insQuery(strCmpCd, strLoginId, hmData);
                        if (strResp.contains("Inserted")) {
                            String respArr[] = strResp.split(" ");
                            msg = sdf_Time.format(new Date()).concat("| ").concat(msg).concat("| NM: ").concat(respArr[2]).concat("?");
                            SSEServlet.addMessage(strCmpCd, strLoginId, msgFor, msg);
                            json.put("Response", "Ok");
                        } else {
                            json.put("Response", "Failed");
                        }
                    } else {
                        strResp = Query.updQuery(strCmpCd, strLoginId, hmData);
                        if (strResp.equalsIgnoreCase("Updated")) {
                            /*
                             msg = sdf_Time.format(new Date()).concat("| ").concat(msg).concat("| NM: ").concat(msgId).concat("?");
                             logger.info("Message: " + msg + " For: " + msgFor + " MsgId: " + msgId);
                             SSEServlet.addMessage(strCmpCd, strLoginId, msgFor, msg);
                             json.put("Response", "Ok");
                             */
                            //Commented above and modified as below on 05.06.2021
                            if (msgView.equalsIgnoreCase("YES") && !msg.equalsIgnoreCase("Viewed")) {
                                strResp = Query.insQuery(strCmpCd, strLoginId, hmData);
                                if (strResp.contains("Inserted")) {
                                    String respArr[] = strResp.split(" ");
                                    msg = sdf_Time.format(new Date()).concat("| ").concat(msg).concat("| NM: ").concat(respArr[2]).concat("?");
                                    SSEServlet.addMessage(strCmpCd, strLoginId, msgFor, msg);
                                    json.put("Response", "Ok");
                                } else {
                                    json.put("Response", "Failed");
                                }
                            } else {
                                msg = sdf_Time.format(new Date()).concat("| Re: ").concat(msg).concat("| NM: ").concat(msgId).concat("?");
                                logger.info("Message: " + msg + " For: " + msgFor + " MsgId: " + msgId);
                                SSEServlet.addMessage(strCmpCd, strLoginId, msgFor, msg);
                                json.put("Response", "Ok");
                            }
                        } else {
                            if (msgView.equalsIgnoreCase("YES") && !msg.equalsIgnoreCase("Viewed")) {
                                strResp = Query.insQuery(strCmpCd, strLoginId, hmData);
                                if (strResp.contains("Inserted")) {
                                    String respArr[] = strResp.split(" ");
                                    msg = sdf_Time.format(new Date()).concat("| ").concat(msg).concat("| NM: ").concat(respArr[2]).concat("?");
                                    SSEServlet.addMessage(strCmpCd, strLoginId, msgFor, msg);
                                    json.put("Response", "Ok");
                                } else {
                                    json.put("Response", "Failed");
                                }
                            }
                        }

                    }
                    //Added above lines on 01.06.2021
                    pw.println(json);
                    break;

                case RAISE_QUERY: //Added on 29.05.2021
                    logger.info("At RAISE_QUERY");
                    String msg2 = request.getParameter("msg");
                    String msgFor2 = request.getParameter("msgFor");
                    dealId = request.getParameter("dealId");
                    //Added below lines on 01.06.2021
                    //String refType2 = "SA";                    
                    String refType2 = request.getParameter("refType");
                    String msgId2 = request.getParameter("msgId");
                    String msgView2 = request.getParameter("msgView");
                    hmData = new HashMap();
                    hmData.put("RefType", refType2);
                    hmData.put("RefId", dealId);
                    hmData.put("ForUser", msgFor2);
                    hmData.put("FromUser", strLoginId);
                    hmData.put("Query", msg2);
                    hmData.put("MsgId", msgId2);
                    hmData.put("MsgView", msgView2);
                    logger.info(hmData);
//                    json.put("Response", "Test");
                    msgId2 = msgId2 == null ? "" : msgId2;
                    if (msgId2.isEmpty()) {
                        strResp = Query.insQuery(strCmpCd, strLoginId, hmData);
                        if (strResp.contains("Inserted")) {
                            if (refType2.equalsIgnoreCase("SA")) {
                                msg2 = msg2.concat("| Sales Order: ").concat(dealId).concat("?");
                            } else {
                                msg2 = msg2.concat("| Service Order: ").concat(dealId).concat("?");
                            }
                            logger.info("Message: " + msg2 + " For: " + msgFor2 + " DealID: " + dealId);
                            SSEServlet.addMessage(strCmpCd, strLoginId, msgFor2, msg2);
                            json.put("Response", "Ok");
                        } else {
                            json.put("Response", "Failed");
                        }
                        //Added above lines on 01.06.2021
                    } else {
                        strResp = Query.updQuery(strCmpCd, strLoginId, hmData);
                        if (strResp.equalsIgnoreCase("Updated")) {
                            if (refType2.equalsIgnoreCase("SA")) {
                                msg2 = msg2.concat("| Sales Order: ").concat(dealId).concat("?");
                            } else {
                                msg2 = msg2.concat("| Service Order: ").concat(dealId).concat("?");
                            }
                            logger.info("Message: " + msg2 + " For: " + msgFor2 + " DealID: " + dealId);
                            SSEServlet.addMessage(strCmpCd, strLoginId, msgFor2, msg2);
                            json.put("Response", "Ok");
                        } else {
                            json.put("Response", "Failed");
                        }
                    }
                    pw.println(json);

                    break;

                case GET_QUERIES: //Added on 02.06.2021
                    logger.info("At GET_QUERIES");
                    dealId = request.getParameter("dealId");
                    //String refType3 = "SA";
                    String refType3 = request.getParameter("refType");
                    hmData = new HashMap();
                    hmData.put("RefType", refType3);
                    hmData.put("RefId", dealId);
                    alData = Query.getQueries(strCmpCd, strLoginId, hmData);
                    json.put("Data", alData);
                    pw.println(json);
                    break;

                case GET_STATES: //Added on 13.12.2019
                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                    try {
                        obj = parser.parse(new FileReader(String_rootPath + "\\docs\\IndiaStates.json"));
                        json.put("States", (JSONArray) obj);
                    } catch (ParseException ex) {
                        logger.error(ex);
                    }
                    pw.println(json);
                    break;

                case CHECK_DEAL_NAME_EXISTS:
                    //String dealName = request.getParameter("dealName");
                    String dealName = request.getParameter("o_name");
                    boolean bStatus = CrmAsyncDbManager.isDealNameExist(strCmpCd, dealName);
                    logger.info("DealExists: " + bStatus);
                    //bStatus = true;
                    json.put("Exists", bStatus);
                    pw.println(json);
                    break;

                case CHECK_DEAL_ID_EXISTS: //Added on 22.09.2020
                    dealId = request.getParameter("dealId");
                    bStat = Deal.isDealExists(strCmpCd, dealId);
                    logger.info("DealIdExists: " + bStat);
                    json.put("Exists", bStat);
                    pw.println(json);
                    break;

                case INSERT_DEAL:
                    //Added below lines on 01.07.2020
                    custId = (String) request.getParameter("cust_id");
                    if (custId.isEmpty()) {
                        hmData = new HashMap();
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("CustType", request.getParameter("c_type"));
                        hmData.put("Industry", request.getParameter("ind_type"));
                        hmData.put("OffType", request.getParameter("off_type"));
                        hmData.put("WebSite", request.getParameter("web_site"));
                        hmData.put("EMailId", request.getParameter("co_email_id"));
                        hmData.put("ToNotify", request.getParameter("to_notify"));
                        custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                        custId = custId.split(" ")[2];
                    }
                    //Added above lines on 01.07.2020
                    //Added below lines on 20.03.2021
                    custAddrId = (String) request.getParameter("c_addr");
                    if (custAddrId.equalsIgnoreCase("NEW")) {
                        hmData = new HashMap();
                        hmData.put("CustId", custId);
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("L1", (String) request.getParameter("b_add1"));
                        hmData.put("L2", (String) request.getParameter("b_add2"));
                        hmData.put("CI", (String) request.getParameter("b_city"));
                        hmData.put("ST", (String) request.getParameter("b_state"));
                        hmData.put("PI", (String) request.getParameter("b_pin"));
                        hmData.put("GSTN", (String) request.getParameter("b_gst"));
                        hmData.put("CP", (String) request.getParameter("bc_per"));
                        hmData.put("CN", (String) request.getParameter("b_cno"));
                        hmData.put("EM", (String) request.getParameter("b_emailId"));
                        custAddrId = Customer.insCustAddress(strCmpCd, strLoginId, hmData);
                        custAddrId = custAddrId.split(" ")[2];
                        logger.info("New CustAddr: " + custAddrId);
                    }

                    jsaCont = new JSONArray();
                    jsoCont = new JSONObject();
                    jsoCont.put("CType", (String) request.getParameter("typeOfContact"));
                    jsoCont.put("L1", (String) request.getParameter("b_add1"));
                    jsoCont.put("L2", (String) request.getParameter("b_add2"));
                    jsoCont.put("CI", (String) request.getParameter("b_city"));
                    jsoCont.put("ST", (String) request.getParameter("b_state"));
                    jsoCont.put("PI", (String) request.getParameter("b_pin"));
                    jsoCont.put("CP", (String) request.getParameter("bc_per"));
                    jsoCont.put("CN", (String) request.getParameter("b_cno"));
                    jsoCont.put("EM", (String) request.getParameter("b_emailId"));
                    jsoCont.put("GSTN", (String) request.getParameter("b_gst"));
                    jsaCont.add(jsoCont);
                    //Added above lines on 20.03.2021

                    hmData = new HashMap();
                    hmData.put("OrdName", (String) request.getParameter("o_name"));
                    hmData.put("ClientName", (String) request.getParameter("cmp_name"));
                    hmData.put("CustId", custId); //Added on 01.07.2020
                    hmData.put("PoNo", (String) request.getParameter("po_number"));
                    hmData.put("PoDate", (String) request.getParameter("po_date"));
                    hmData.put("PoValue", (String) request.getParameter("po_value"));
                    hmData.put("PoType", (String) request.getParameter("po_type"));
                    hmData.put("AccMngr", (String) request.getParameter("accMgr"));
                    hmData.put("DueDate", (String) request.getParameter("due_delv_date"));
                    /*
                     logger.info(hmData.toString());
                     String strStat = Deal.insDeal(strCmpCd, strLoginId, strOffCd, hmData);
                     json.put("Result", strStat);
                     */
                    //Commented temporarily for testing purpose
                    hmData.put("isProj", (String) request.getParameter("isProj"));
                    /* Commented on 20.03.2021
                     iCount = Integer.parseInt((String) request.getParameter("NoOfCont"));
                     JSONArray jsaCont = new JSONArray();
                     if (iCount > 0) {
                     for (int i = 0; i < iCount; i++) {
                     jsoCont = new JSONObject();
                     jsoCont.put("CType", (String) request.getParameter("typeOfContact" + i));
                     jsoCont.put("L1", (String) request.getParameter("b_add1" + i));
                     jsoCont.put("L2", (String) request.getParameter("b_add2" + i));
                     jsoCont.put("CI", (String) request.getParameter("b_city" + i));
                     jsoCont.put("ST", (String) request.getParameter("b_state" + i));
                     jsoCont.put("PI", (String) request.getParameter("b_pin" + i));
                     jsoCont.put("CP", (String) request.getParameter("bc_per" + i));
                     jsoCont.put("CN", (String) request.getParameter("b_cno" + i));
                     jsoCont.put("EM", (String) request.getParameter("b_emailId" + i));
                     jsoCont.put("GSTN", (String) request.getParameter("b_gst" + i));
                     jsoCont.put("NOTIFY", (String) request.getParameter("notification" + i));
                     jsaCont.add(jsoCont);
                     }
                     }
                     */

                    JSONObject jsoContacts = new JSONObject();
                    jsoContacts.put("Contacts", jsaCont);
                    hmData.put("Contacts", jsoContacts.toString());
                    //Added below 3 lines on 18.03.2020
                    hmData.put("PayTerms", (String) request.getParameter("termsOfPay"));
                    hmData.put("CrDays", (String) request.getParameter("crDays"));
                    hmData.put("DelvTerms", (String) request.getParameter("termsOfDelv"));
                    //Added below 3 lines on 14.07.2020
                    hmData.put("PBGReq", (String) request.getParameter("pbg-req"));
                    hmData.put("PBGValue", (String) request.getParameter("pbg-value"));
                    hmData.put("PBGDuration", (String) request.getParameter("pbg-duration"));
                    hmData.put("PrCateg", (String) request.getParameter("pr_categ")); //Added on 08.07.2021
                    logger.info(hmData.toString());
                    String strStat = Deal.insDeal(strCmpCd, strLoginId, strOffCd, hmData);
                    json.put("Result", strStat);
                    pw.println(json);

                    //Added below lines on 05.07.2021
                    sb = new StringBuilder();

                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                    try {
                        FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "ITRDeclaration.html");
                        int ch;
                        while ((ch = fr.read()) != -1) {
                            sb.append((char) ch);
                        }
                    } catch (FileNotFoundException fe) {
                        logger.error(fe);
                    }

                    String mainUrl = "https://opxl.in";
                    if (isDeveloper) {
                        mainUrl = "http://localhost:8090/BioAs_MT_VER3.1";
                    }
                    String declUrl = mainUrl + "/Crm.do?operation=getCustDeclFrm&mainCd=" + strCmpCd + "&custId=" + custId;
                    int iStart = sb.indexOf("<opxlLink>");
                    int iEnd = iStart + 10;
                    String strUrl = "<a href=" + declUrl + "> Click Here</a>";
                    sb.replace(iStart, iEnd, strUrl);

                    alData = new ArrayList();
                    String accMngr = (String) request.getParameter("accMgr");
                    alData.add(Deal.getAMEmailID(strCmpCd, accMngr));
                    emIDs = new String[alData.size()];
                    for (int i = 0; i < alData.size(); i++) {
                        emIDs[i] = (String) alData.get(i);
                    }

                    sendMail(sb.toString(), "Request for Declaration - Amendments under IT Act (u/s 194Q & u/s 206CCA/206AB) -- Reg.", emIDs);
                    //Added above lines on 05.07.2021

                    break;

                case INSERT_SERV_CONTRACT: //Added on 18.09.2020
                    logger.info("At 347 INSERT_SERV_CONTRAC");
                    custId = (String) request.getParameter("cust_id");
                    if (custId.isEmpty()) {
                        hmData = new HashMap();
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("CustType", request.getParameter("c_type"));
                        hmData.put("Industry", request.getParameter("ind_type"));
                        hmData.put("OffType", request.getParameter("off_type"));
                        hmData.put("WebSite", request.getParameter("web_site"));
                        hmData.put("EMailId", request.getParameter("co_email_id"));
                        hmData.put("ToNotify", request.getParameter("to_notify"));
                        custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                        custId = custId.split(" ")[2];
                    }
                    //Added above lines on 01.07.2020
                    custAddrId = (String) request.getParameter("c_addr");
                    if (custAddrId.equalsIgnoreCase("NEW")) {
                        hmData = new HashMap();
                        hmData.put("CustId", custId);
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("L1", (String) request.getParameter("b_add1"));
                        hmData.put("L2", (String) request.getParameter("b_add2"));
                        hmData.put("CI", (String) request.getParameter("b_city"));
                        hmData.put("ST", (String) request.getParameter("b_state"));
                        hmData.put("PI", (String) request.getParameter("b_pin"));
                        hmData.put("GSTN", (String) request.getParameter("b_gst"));
                        hmData.put("CP", (String) request.getParameter("bc_per"));
                        hmData.put("CN", (String) request.getParameter("b_cno"));
                        hmData.put("EM", (String) request.getParameter("b_emailId"));
                        custAddrId = Customer.insCustAddress(strCmpCd, strLoginId, hmData);
                        custAddrId = custAddrId.split(" ")[2];
                    }

                        hmData = new HashMap();
                        hmData.put("ClientName", (String) request.getParameter("cmp_name"));
                        hmData.put("CustId", custId); //Added on 01.07.2020
                        hmData.put("CustAddrId", custAddrId);
                        hmData.put("ContrDesc", (String) request.getParameter("contr_desc"));
                        hmData.put("PoNo", (String) request.getParameter("po_number"));
                        hmData.put("PoDate", (String) request.getParameter("po_date"));
                        hmData.put("PoValue", (String) request.getParameter("po_value"));
                        hmData.put("AccMngr", (String) request.getParameter("accMgr"));
                        hmData.put("BillCycle", (String) request.getParameter("bill_cycle"));
                        hmData.put("OthMonths", (String) request.getParameter("othMonths")); //Added on 26.10.2020
                        hmData.put("PayTerm", (String) request.getParameter("pay_term"));
                        hmData.put("StartDate", (String) request.getParameter("start_date"));
                        hmData.put("EndDate", (String) request.getParameter("end_date"));
                        hmData.put("BillAmt", (String) request.getParameter("billing_amt")); //Added on 27.10.2020

                        jsoCont = new JSONObject();
                        jsoCont.put("L1", (String) request.getParameter("b_add1"));
                        jsoCont.put("L2", (String) request.getParameter("b_add2"));
                        jsoCont.put("CI", (String) request.getParameter("b_city"));
                        jsoCont.put("ST", (String) request.getParameter("b_state"));
                        jsoCont.put("PI", (String) request.getParameter("b_pin"));
                        jsoCont.put("CP", (String) request.getParameter("bc_per"));
                        jsoCont.put("CN", (String) request.getParameter("b_cno"));
                        jsoCont.put("EM", (String) request.getParameter("b_emailId"));
                        jsoCont.put("GSTN", (String) request.getParameter("b_gst"));
                        jsoCont.put("NOTIFY", (String) request.getParameter("notification"));
                        hmData.put("Contact", jsoCont.toString());
                        logger.info(hmData.toString());
                        strResp = ServiceContract.insServContract(strCmpCd, strLoginId, strOffCd, hmData);
                        json.put("Result", strResp);
    //                    json.put("Result", "ToDo");
                        pw.println(json);
                    break;
                case UPDATE_SERV_CONTRACT: //Added on 14.10.2020
                    custId = (String) request.getParameter("cust_id");
                    if (custId.isEmpty()) {
                        hmData = new HashMap();
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("CustType", request.getParameter("c_type"));
                        hmData.put("Industry", request.getParameter("ind_type"));
                        hmData.put("OffType", request.getParameter("off_type"));
                        hmData.put("WebSite", request.getParameter("web_site"));
                        hmData.put("EMailId", request.getParameter("co_email_id"));
                        hmData.put("ToNotify", request.getParameter("to_notify"));
                        custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                        custId = custId.split(" ")[2];
                    }
                    custAddrId = (String) request.getParameter("c_addr");
                    if (custAddrId.equalsIgnoreCase("NEW")) {
                        hmData = new HashMap();
                        hmData.put("CustId", custId);
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("L1", (String) request.getParameter("b_add1"));
                        hmData.put("L2", (String) request.getParameter("b_add2"));
                        hmData.put("CI", (String) request.getParameter("b_city"));
                        hmData.put("ST", (String) request.getParameter("b_state"));
                        hmData.put("PI", (String) request.getParameter("b_pin"));
                        hmData.put("GSTN", (String) request.getParameter("b_gst"));
                        hmData.put("CP", (String) request.getParameter("bc_per"));
                        hmData.put("CN", (String) request.getParameter("b_cno"));
                        hmData.put("EM", (String) request.getParameter("b_emailId"));
                        custAddrId = Customer.insCustAddress(strCmpCd, strLoginId, hmData);
                        custAddrId = custAddrId.split(" ")[2];
                    }

                    hmData = new HashMap();
                    hmData.put("ContrId", (String) request.getParameter("contrId"));
                    hmData.put("ClientName", (String) request.getParameter("cmp_name"));
                    hmData.put("CustId", custId); //Added on 01.07.2020
                    hmData.put("CustAddrId", custAddrId);
                    hmData.put("ContrDesc", (String) request.getParameter("contr_desc"));
                    hmData.put("PoNo", (String) request.getParameter("po_number"));
                    hmData.put("PoDate", (String) request.getParameter("po_date"));
                    hmData.put("PoValue", (String) request.getParameter("po_value"));
                    hmData.put("AccMngr", (String) request.getParameter("accMgr"));
                    hmData.put("BillCycle", (String) request.getParameter("bill_cycle"));
                    hmData.put("PayTerm", (String) request.getParameter("pay_term"));
                    hmData.put("StartDate", (String) request.getParameter("start_date"));
                    hmData.put("EndDate", (String) request.getParameter("end_date"));
                    hmData.put("OthMonths", (String) request.getParameter("othMonths")); //Added on 26.10.2020
                    hmData.put("BillAmt", (String) request.getParameter("billing_amt")); //Added on 27.10.2020

                    jsoCont = new JSONObject();
                    jsoCont.put("L1", (String) request.getParameter("b_add1"));
                    jsoCont.put("L2", (String) request.getParameter("b_add2"));
                    jsoCont.put("CI", (String) request.getParameter("b_city"));
                    jsoCont.put("ST", (String) request.getParameter("b_state"));
                    jsoCont.put("PI", (String) request.getParameter("b_pin"));
                    jsoCont.put("CP", (String) request.getParameter("bc_per"));
                    jsoCont.put("CN", (String) request.getParameter("b_cno"));
                    jsoCont.put("EM", (String) request.getParameter("b_emailId"));
                    jsoCont.put("GSTN", (String) request.getParameter("b_gst"));
                    jsoCont.put("NOTIFY", (String) request.getParameter("notification"));
                    hmData.put("Contact", jsoCont.toString());
                    logger.info(hmData.toString());

                    strResp = ServiceContract.updServContract(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPDATE_DEAL: //Added on 20.07.2020
                    custId = (String) request.getParameter("cust_id");
                    if (custId.isEmpty()) {
                        custId = Customer.getCustId(strCmpCd, "C", (String) request.getParameter("cmp_name"));
                        if (custId == null) {
                            hmData = new HashMap();
                            hmData.put("CustName", request.getParameter("cmp_name"));
                            hmData.put("CustType", request.getParameter("c_type"));
                            hmData.put("Industry", request.getParameter("ind_type"));
                            hmData.put("OffType", request.getParameter("off_type"));
                            hmData.put("WebSite", request.getParameter("web_site"));
                            hmData.put("EMailId", request.getParameter("co_email_id"));
                            hmData.put("ToNotify", request.getParameter("to_notify"));
                            custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                            custId = custId.split(" ")[2];
                        }
                    }

                    //Added below lines on 20.03.2021
                    custAddrId = (String) request.getParameter("c_addr");
                    if (custAddrId.equalsIgnoreCase("NEW")) {
                        hmData = new HashMap();
                        hmData.put("CustId", custId);
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("L1", (String) request.getParameter("b_add1"));
                        hmData.put("L2", (String) request.getParameter("b_add2"));
                        hmData.put("CI", (String) request.getParameter("b_city"));
                        hmData.put("ST", (String) request.getParameter("b_state"));
                        hmData.put("PI", (String) request.getParameter("b_pin"));
                        hmData.put("GSTN", (String) request.getParameter("b_gst"));
                        hmData.put("CP", (String) request.getParameter("bc_per"));
                        hmData.put("CN", (String) request.getParameter("b_cno"));
                        hmData.put("EM", (String) request.getParameter("b_emailId"));
                        custAddrId = Customer.insCustAddress(strCmpCd, strLoginId, hmData);
                        custAddrId = custAddrId.split(" ")[2];
                        logger.info("New CustAddr: " + custAddrId);
                    }

                    jsaCont = new JSONArray();
                    jsoCont = new JSONObject();
                    jsoCont.put("CType", (String) request.getParameter("typeOfContact"));
                    jsoCont.put("L1", (String) request.getParameter("b_add1"));
                    jsoCont.put("L2", (String) request.getParameter("b_add2"));
                    jsoCont.put("CI", (String) request.getParameter("b_city"));
                    jsoCont.put("ST", (String) request.getParameter("b_state"));
                    jsoCont.put("PI", (String) request.getParameter("b_pin"));
                    jsoCont.put("CP", (String) request.getParameter("bc_per"));
                    jsoCont.put("CN", (String) request.getParameter("b_cno"));
                    jsoCont.put("EM", (String) request.getParameter("b_emailId"));
                    jsoCont.put("GSTN", (String) request.getParameter("b_gst"));
                    jsaCont.add(jsoCont);
                    //Added above lines on 20.03.2021

                    hmData = new HashMap();
                    hmData.put("OrdId", (String) request.getParameter("dealId"));
                    hmData.put("ClientName", (String) request.getParameter("cmp_name"));
                    hmData.put("CustId", custId); //Added on 01.07.2020
                    hmData.put("PoNo", (String) request.getParameter("po_number"));
                    hmData.put("PoDate", (String) request.getParameter("po_date"));
                    hmData.put("PoValue", (String) request.getParameter("po_value"));
                    hmData.put("PoType", (String) request.getParameter("po_type"));
                    hmData.put("AccMngr", (String) request.getParameter("accMgr"));
                    hmData.put("DueDate", (String) request.getParameter("due_delv_date"));
                    hmData.put("PayTerms", (String) request.getParameter("termsOfPay"));
                    hmData.put("CrDays", (String) request.getParameter("crDays"));
                    hmData.put("DelvTerms", (String) request.getParameter("termsOfDelv"));
                    hmData.put("PBGReq", (String) request.getParameter("pbg-req"));
                    hmData.put("PBGValue", (String) request.getParameter("pbg-value"));
                    hmData.put("PBGDuration", (String) request.getParameter("pbg-duration"));
                    hmData.put("PrCateg", (String) request.getParameter("pr_categ")); //Added on 08.07.2021

                    JSONObject jsoContacts2 = new JSONObject();
                    jsoContacts2.put("Contacts", jsaCont);
                    hmData.put("Contacts", jsoContacts2.toString());
                    logger.info(hmData.toString());
                    strResp = Deal.updDeal(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPDATE_DEAL_STAT: //Added on 11.12.2020
                    hmData = new HashMap();
                    hmData.put("OrdId", (String) request.getParameter("su_dealId"));
                    hmData.put("OrdStat", (String) request.getParameter("statType"));
                    hmData.put("StatDesc", (String) request.getParameter("su_desc"));
                    logger.info(hmData.toString());
                    strResp = Deal.updDealStatus(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case APPROVE_E_VOUCHER: //Added on 30.01.2021
                    hmData = new HashMap();
                    hmData.put("VchrNo", (String) request.getParameter("su_vchr_no"));
                    hmData.put("VchrStat", (String) request.getParameter("statType"));
                    hmData.put("Remarks", (String) request.getParameter("su_rem")); //Added on 08.04.2021
                    logger.info(hmData.toString());
                    strResp = Voucher.updVchrStatus(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPD_E_VCH_PAY_DTLS: //Added on 11.02.2021
                    hmData = new HashMap();
                    hmData.put("VchrNo", (String) request.getParameter("su_vchr_no"));
                    hmData.put("PaidOn", (String) request.getParameter("paid_date"));
                    hmData.put("PayMode", (String) request.getParameter("payMode"));
                    String refNo = (String) request.getParameter("pay_ref_no");
                    refNo = refNo == null ? "" : refNo;
                    hmData.put("PayRefNo", refNo);
                    logger.info(hmData.toString());
                    strResp = Voucher.updVchrPayDtls(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case PENDING_DEALS_COUNT:
                    iCount = Deal.getPendingDealsCount(strCmpCd, login_dtls); //Added login_dtls param on 11.10.2019
                    logger.info(iCount);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case PENDING_SERV_CONTR_COUNT: //Added on 01.02.2021
                    iCount = ServiceContract.getPendContrCount(strCmpCd, login_dtls);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case DEALS_COUNT: //Added on 23.10.2019
                    alData = Deal.getDealsCount(strCmpCd, login_dtls, null, null);
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case GET_TARG_ACHV_DATA: //Added on 26.03.2021
                    //Added below lines on 01.07.2021
                    String toDate = request.getParameter("toDate");
                    if (toDate == null) {
                        alData = BusinessTargets.getTargetPeriods(strCmpCd, login_dtls);
                        json.put("TargPeriods", alData);
                    }
                    //Added above lines on 01.07.2021
                    alData = BusinessTargets.getTargetsAndActuals(strCmpCd, login_dtls, toDate); //toDate param added on 01.07.2021
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case ENQ_COUNTS: //Added on 03.07.2020
                    alData = Enquiry.getEnqCounts(strCmpCd, login_dtls);
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case TODAYS_COUNT: //Added on 20.06.2020
                    alData = Deal.getTodaysCount(strCmpCd, login_dtls);
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case RMA_COUNT: //Added on 07.10.2020
                    alData = RMA.getCounts(strCmpCd, login_dtls);
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case OTH_COUNT: //Added on 29.01.2021
                    iCount = Voucher.getPendVchrsCount(strCmpCd, login_dtls);
                    json.put("PendVchrs", iCount);
                    iCount = Voucher.getPendForPayCount(strCmpCd, login_dtls);
                    json.put("PendForPay", iCount);
                    //Added below 2 lines on 19.03.2021
                    iCount = Product.getWarrLapsesCount(strCmpCd, login_dtls);
                    json.put("WarrLapsesCnt", iCount);
                    pw.println(json);
                    break;

                case PENDING_PROCURE_COUNT: //Added on 21.06.2019
                    iCount = Deal.getPendingProcureCount(strCmpCd, login_dtls); //Added login_dtls param on 11.10.2019);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case INSERT_DEAL_DETAILS:
                    items = Integer.parseInt((String) request.getParameter("items"));
                    logger.info(items);
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++) {
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("OrdId", (String) request.getParameter("id1" + i));
                        hmDealDtls.put("OrdRowId", (String) request.getParameter("pr_dealRowId" + i));//Added on 30.09.2019
                        hmDealDtls.put("DBOper", (String) request.getParameter("db_oper" + i)); //Added on 04.10.2019
                        hmDealDtls.put("OrdName", (String) request.getParameter("d_name" + i));
                        hmDealDtls.put("ClientName", (String) request.getParameter("c_name" + i));
                        hmDealDtls.put("ProdName", (String) request.getParameter("p_name" + i));
                        hmDealDtls.put("ProdQty", (String) request.getParameter("pqyt" + i));
                        hmDealDtls.put("BillAddr", (String) request.getParameter("bill_add" + i));
                        hmDealDtls.put("ShipAddr", (String) request.getParameter("ship_add" + i));
                        //Added below on 08.07.2019
                        hmDealDtls.put("ProdSpecs", (String) request.getParameter("specs" + i));
                        hmDealDtls.put("UnitPrice", (String) request.getParameter("unitPr" + i));
                        hmDealDtls.put("GSTRate", (String) request.getParameter("gstRate" + i));
                        hmDealDtls.put("TotPrice", (String) request.getParameter("totPr" + i));
                        hmDealDtls.put("ProdWarr", (String) request.getParameter("prodWar" + i));
                        hmDealDtls.put("ShipReq", (String) request.getParameter("shipReq" + i));
                        hmDealDtls.put("InstReq", (String) request.getParameter("instReq" + i));
                        hmDealDtls.put("ReturnItem", (String) request.getParameter("itemReturn" + i)); //Added on 23.06.2021
                        //Added above on 08.07.2019
                        hmDealDtls.put("ProdId", (String) request.getParameter("prId" + i));
                        hmDealDtls.put("DistKm", (String) request.getParameter("distKm" + i));
                        //Added above 2 lines on 17.01.2020
                        alData.add(hmDealDtls);
                    }
                    logger.info(alData);
                    strResp = Deal.insDealDetails(strCmpCd, strLoginId, alData);
                    json.put("Result", strResp);
                    //Commented above for testing purpose on 17.01.2020
                    //json.put("Result", "Test");
                    pw.println(json);
                    break;

                 case INSERT_PO_DETAILS:
                     
                      logger.info("insPODetails");
                       logger.info(strCmpCd);
               
             
                      
                     items = Integer.parseInt((String) request.getParameter("items"));
                      
                      logger.info("items: " + items);
                      
                        Po_id = Integer.parseInt((String) request.getParameter("POId"));
                        logger.info("po_id: " + Po_id);
                        logger.info("test");
                      
                    logger.info(" reached insrt po ");
                     
                    hmData=new HashMap();
                    
                     hmData.put("POId", Po_id);
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++) {
                      
                       HashMap hmDealDtls = new HashMap();
                  
                       
                       
                        
                        hmDealDtls.put("DBOper", (String) request.getParameter("db_oper" + i));
                        hmDealDtls.put("RowID", (String) request.getParameter("RowId" + i));
                        hmDealDtls.put("ProdName", (String) request.getParameter("p_name" + i));
                        hmDealDtls.put("ProdQty", (String) request.getParameter("pqyt" + i));
                        hmDealDtls.put("ProdSpecs", (String) request.getParameter("specs" + i));
                        hmDealDtls.put("UnitPrice", (String) request.getParameter("unitPr" + i));
                        hmDealDtls.put("GSTRate", (String) request.getParameter("gstRate" + i));
                        hmDealDtls.put("TotPrice", (String) request.getParameter("totPr" + i));
                        hmDealDtls.put("ProdWarr", (String) request.getParameter("prodWar" + i));
                        hmDealDtls.put("ShipReq", (String) request.getParameter("shipReq" + i));
                        hmDealDtls.put("InstReq", (String) request.getParameter("instReq" + i));
                        hmDealDtls.put("ProdId", (String) request.getParameter("prId" + i));
          
                        hmDealDtls.put("ProdDealId", (String) request.getParameter("prDealId" + i));
                        hmDealDtls.put("ProdDealRowId", (String) request.getParameter("pr_dealRowId" + i));
              
                        
                        alData.add(hmDealDtls);
                    }
                    hmData.put("Items", alData);
                    logger.info(hmData.toString());
                //    strResp = PurchaseOrder.insPO(strCmpCd, strLoginId, strOffCd, hmData);
                    strResp = PurchaseOrder.insPODetails(strCmpCd, strLoginId, strOffCd, hmData);
                    System.out.println("strResp" + strResp);
                    json.put("Result", strResp);
                    //Commented above for testing purpose on 17.01.2020
//                    json.put("Result", "Test");
                    pw.println(json);
                          
                     
                  
                      
                              
                    
                     
                     
                    
                    break;
                    
                    
                case UPDATE_DEAL_ADDR: //Added on 13.10.2020
                    hmData = new HashMap();
                    hmData.put("OrdId", (String) request.getParameter("mo_dealId"));
                    hmData.put("DistKm", (String) request.getParameter("mo_distance"));
                    sb = new StringBuilder();
                    sb.append("L1:").append((String) request.getParameter("pr_b_add1")).append("; ")
                            .append("L2:").append((String) request.getParameter("pr_b_add2")).append("; ")
                            .append("CI:").append((String) request.getParameter("pr_b_city")).append("; ")
                            .append("ST:").append((String) request.getParameter("pr_b_state")).append("; ")
                            .append("PI:").append((String) request.getParameter("pr_b_pin")).append("; ")
                            .append("CN:").append((String) request.getParameter("pr_b_cno")).append("; ")
                            .append("EM:").append((String) request.getParameter("pr_b_emailId")).append("; ")
                            .append("GSTN:").append((String) request.getParameter("pr_b_gst")).append("; ")
                            .append("CP:").append((String) request.getParameter("pr_bc_per"));

                    String prBillTo = sb.toString();
                    hmData.put("PrBillTo", prBillTo);

                    sb = new StringBuilder();
                    sb.append("L1:").append((String) request.getParameter("mo_b_add1")).append("; ")
                            .append("L2:").append((String) request.getParameter("mo_b_add2")).append("; ")
                            .append("CI:").append((String) request.getParameter("mo_b_city")).append("; ")
                            .append("ST:").append((String) request.getParameter("mo_b_state")).append("; ")
                            .append("PI:").append((String) request.getParameter("mo_b_pin")).append("; ")
                            .append("CN:").append((String) request.getParameter("mo_b_cno")).append("; ")
                            .append("EM:").append((String) request.getParameter("mo_b_emailId")).append("; ")
                            .append("GSTN:").append((String) request.getParameter("mo_b_gst")).append("; ")
                            .append("CP:").append((String) request.getParameter("mo_bc_per"));

                    String modBillTo = sb.toString();
                    hmData.put("ModBillTo", modBillTo);

                    sb = new StringBuilder();
                    sb.append("L1:").append((String) request.getParameter("pr_s_add1")).append("; ")
                            .append("L2:").append((String) request.getParameter("pr_s_add2")).append("; ")
                            .append("CI:").append((String) request.getParameter("pr_s_city")).append("; ")
                            .append("ST:").append((String) request.getParameter("pr_s_state")).append("; ")
                            .append("PI:").append((String) request.getParameter("pr_s_pin")).append("; ")
                            .append("CN:").append((String) request.getParameter("pr_s_cno")).append("; ")
                            .append("EM:").append((String) request.getParameter("pr_s_emailId")).append("; ")
                            .append("GSTN:").append((String) request.getParameter("pr_s_gst")).append("; ")
                            .append("CP:").append((String) request.getParameter("pr_sc_per"));

                    String prShipTo = sb.toString();
                    hmData.put("PrShipTo", prShipTo);

                    sb = new StringBuilder();
                    sb.append("L1:").append((String) request.getParameter("mo_s_add1")).append("; ")
                            .append("L2:").append((String) request.getParameter("mo_s_add2")).append("; ")
                            .append("CI:").append((String) request.getParameter("mo_s_city")).append("; ")
                            .append("ST:").append((String) request.getParameter("mo_s_state")).append("; ")
                            .append("PI:").append((String) request.getParameter("mo_s_pin")).append("; ")
                            .append("CN:").append((String) request.getParameter("mo_s_cno")).append("; ")
                            .append("EM:").append((String) request.getParameter("mo_s_emailId")).append("; ")
                            .append("GSTN:").append((String) request.getParameter("mo_s_gst")).append("; ")
                            .append("CP:").append((String) request.getParameter("mo_sc_per"));

                    String modShipTo = sb.toString();
                    hmData.put("ModShipTo", modShipTo);
                    logger.info(hmData);
                    logger.info(prBillTo.equalsIgnoreCase(modBillTo));
                    logger.info(prShipTo.equalsIgnoreCase(modShipTo));
                    
                    if(request.getParameter("flag").equalsIgnoreCase("m")){
                        logger.info("Test --m");
                        if (!prBillTo.equalsIgnoreCase(modBillTo) || !prShipTo.equalsIgnoreCase(modShipTo)) {
                        strResp = Deal.updDealAddr(strCmpCd, strLoginId, hmData);
                        } else {
                            strResp = "Nothing to Modify";
                        }
                    }else if(request.getParameter("flag").equalsIgnoreCase("rv")){
                        logger.info("Test --rv");
                        strResp = Deal.reverseBillAndShip(strCmpCd,strLoginId, hmData);
                    }else{
                        strResp = "";
                    }
                    
                    json.put("Result", strResp);
                    //Commented above for testing purpose on 17.01.2020
//                    json.put("Result", "Test");
                    pw.println(json);
                    break;

                case INSERT_SERV_CONTR_DETAILS: //Added on 19.09.2020
                    items = Integer.parseInt((String) request.getParameter("items"));
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++) {
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("ContrId", (String) request.getParameter("id1" + i));
                        hmDealDtls.put("ContrRowId", (String) request.getParameter("pr_dealRowId" + i)); //Added on 30.09.2019
                        hmDealDtls.put("DBOper", (String) request.getParameter("db_oper" + i)); //Added on 04.10.2019
                        hmDealDtls.put("ContrDesc", (String) request.getParameter("d_name" + i));
                        hmDealDtls.put("ClientName", (String) request.getParameter("c_name" + i));
                        hmDealDtls.put("ProdName", (String) request.getParameter("p_name" + i));
                        hmDealDtls.put("ProdQty", (String) request.getParameter("pqyt" + i));
                        hmDealDtls.put("BillAddr", (String) request.getParameter("bill_add" + i));
                        hmDealDtls.put("ShipAddr", (String) request.getParameter("ship_add" + i));
                        hmDealDtls.put("ProdSpecs", (String) request.getParameter("specs" + i));
                        hmDealDtls.put("UnitPrice", (String) request.getParameter("unitPr" + i));
                        hmDealDtls.put("GSTRate", (String) request.getParameter("gstRate" + i));
                        hmDealDtls.put("TotPrice", (String) request.getParameter("totPr" + i));
                        hmDealDtls.put("ProdWarr", (String) request.getParameter("prodWar" + i));
                        hmDealDtls.put("ShipReq", (String) request.getParameter("shipReq" + i));
                        hmDealDtls.put("InstReq", (String) request.getParameter("instReq" + i));
                        hmDealDtls.put("ProdId", (String) request.getParameter("productId" + i));
                        alData.add(hmDealDtls);
                    }
                    logger.info(alData);
                    strResp = ServiceContract.insDetails(strCmpCd, strLoginId, alData);
                    json.put("Result", strResp);
                    //Commented above for testing purpose on 17.01.2020
//                    json.put("Result", "Test");
                    pw.println(json);
                    break;

                case INSERT_PO: //Added on 21.07.2020
                    
              //      String strResp = PurchaseOrder.insPO(strCmpCd, strLoginId, strOffCd,);
                    logger.info("insPO");
                    custId = (String) request.getParameter("cust_id");
                     custType=(String) request.getParameter("c_Type");
                     logger.info(custType);
                    
                    logger.info(custId);
                    if (custId.isEmpty()){
                        hmData = new HashMap();
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("CustType", request.getParameter("c_type"));
                        hmData.put("Industry", request.getParameter("ind_type"));
                        hmData.put("OffType", request.getParameter("off_type"));
                        hmData.put("WebSite", request.getParameter("web_site"));
                        hmData.put("EMailId", request.getParameter("co_email_id"));
                       hmData.put("ToNotify", request.getParameter("to_notify"));
                       custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                        custId = custId.split(" ")[2];
                    }

                    custAddrId = (String) request.getParameter("c_addr");
                   logger.info(custAddrId);
                    if (custAddrId.equalsIgnoreCase("NEW")) {
                        hmData = new HashMap();
                        hmData.put("CustId", custId);
                        hmData.put("CustName", request.getParameter("cmp_name"));
                        hmData.put("L1", (String) request.getParameter("b_add1"));
                        hmData.put("L2", (String) request.getParameter("b_add2"));
                        hmData.put("CI", (String) request.getParameter("b_city"));
                        hmData.put("ST", (String) request.getParameter("b_state"));
                        hmData.put("PI", (String) request.getParameter("b_pin"));
                        hmData.put("GSTN", (String) request.getParameter("b_gst"));
                        hmData.put("CP", (String) request.getParameter("bc_per"));
                        hmData.put("CN", (String) request.getParameter("b_cno"));
                        hmData.put("EM", (String) request.getParameter("b_emailId"));
                        custAddrId = Customer.insCustAddress(strCmpCd, strLoginId, hmData);
                        custAddrId = custAddrId.split(" ")[2];
                    }

                    hmData = new HashMap();
                    hmData.put("ClientName", (String) request.getParameter("cmp_name"));
                    hmData.put("CustId", custId);
                    hmData.put("CustAddrId", custAddrId);
                    hmData.put("PoNo", (String) request.getParameter("po_number"));
                    hmData.put("PoDate", (String) request.getParameter("po_date"));
                    hmData.put("AddrL1", (String) request.getParameter("b_add1"));
                    hmData.put("AddrL2", (String) request.getParameter("b_add2"));
                    hmData.put("City", (String) request.getParameter("b_city"));
                    hmData.put("PinCode", (String) request.getParameter("b_pin"));
                    hmData.put("State", (String) request.getParameter("b_state"));
                    hmData.put("Country", (String) request.getParameter("b_country"));
                    hmData.put("GstNo", (String) request.getParameter("b_gst"));
                    //hmData.put("PayTerms", (String) request.getParameter("termsOfPay"));
                    //Commented above and modified as below on 11.08.2020
                    payTerms = (String) request.getParameter("termsOfPay");
                    othTOP = (String) request.getParameter("oth_top");
                    payTerms = payTerms.equalsIgnoreCase("OT") ? othTOP : payTerms;
                    hmData.put("PayTerms", payTerms);

                    hmData.put("CrDays", (String) request.getParameter("crDays"));
                    hmData.put("DelvTerms", (String) request.getParameter("termsOfDelv"));
                    hmData.put("VendRefNo", (String) request.getParameter("v_ref_no"));
                    hmData.put("CP", (String) request.getParameter("bc_per"));
                    hmData.put("CN", (String) request.getParameter("b_cno"));
                    hmData.put("EM", (String) request.getParameter("b_emailId"));
                    //Added below lines on 06.08.2020
                    hmData.put("STClientName", (String) request.getParameter("s_cl_name"));
                    hmData.put("STAddrL1", (String) request.getParameter("s_add1"));
                    hmData.put("STAddrL2", (String) request.getParameter("s_add2"));
                    hmData.put("STCity", (String) request.getParameter("s_city"));
                    hmData.put("STPinCode", (String) request.getParameter("s_pin"));
                    hmData.put("STState", (String) request.getParameter("s_state"));
                    hmData.put("STCountry", (String) request.getParameter("s_country"));
                    hmData.put("STGstNo", (String) request.getParameter("s_gst"));
                    hmData.put("STCP", (String) request.getParameter("sc_per"));
                    hmData.put("STCN", (String) request.getParameter("s_cno"));
                    hmData.put("STEM", (String) request.getParameter("s_emailId"));
                    //Added above lines on 06.08.2020
                    items = Integer.parseInt((String) request.getParameter("items"));
//                    logger.info(items);
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++) {
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("ProdName", (String) request.getParameter("p_name" + i));
                        hmDealDtls.put("ProdQty", (String) request.getParameter("pqyt" + i));
                        hmDealDtls.put("ProdSpecs", (String) request.getParameter("specs" + i));
                        hmDealDtls.put("UnitPrice", (String) request.getParameter("unitPr" + i));
                        hmDealDtls.put("GSTRate", (String) request.getParameter("gstRate" + i));
                        hmDealDtls.put("TotPrice", (String) request.getParameter("totPr" + i));
                        hmDealDtls.put("ProdWarr", (String) request.getParameter("prodWar" + i));
                        hmDealDtls.put("ShipReq", (String) request.getParameter("shipReq" + i));
                        hmDealDtls.put("InstReq", (String) request.getParameter("instReq" + i));
                        hmDealDtls.put("ProdId", (String) request.getParameter("prId" + i));
                        //Added below 2 lines on 30.07.2020
                        hmDealDtls.put("ProdDealId", (String) request.getParameter("prDealId" + i));
                        hmDealDtls.put("ProdDealRowId", (String) request.getParameter("prDealRowId" + i));
                        alData.add(hmDealDtls);
                    }
                    hmData.put("Items", alData);
                    logger.info(hmData.toString());
                    strResp = PurchaseOrder.insPO(strCmpCd, strLoginId, strOffCd, hmData);
                    json.put("Result", strResp);
                    //Commented above for testing purpose on 17.01.2020
//                    json.put("Result", "Test");
                    pw.println(json);
                    break;
                    
                //Added below line of code for Auto generation PO against quotation on 11.04.2024
                case GENERATE_PO_RFQ:
                    DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
                    ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);                                
                    List<FileItem> vitems = uploadHandler.parseRequest(request);
                    HashMap<String,String> inptFiled=new HashMap();
                    HashMap<String,FileItem> fileField=new HashMap();
                    for(FileItem ob:vitems){
                        if(ob.isFormField()){
                            inptFiled.put(ob.getFieldName(), ob.getString());
                        }else{
                            fileField.put(ob.getFieldName(), ob);
                        }                                                
                    }
                    
                    ArrayList poList = new ArrayList();
                    HashMap poMap = new HashMap();
                    logger.info("We reached to auto generation po against quote no");                                              
                        int venItems = Integer.parseInt((String) inptFiled.get("vendItems"));                        
                        int lineItems = Integer.parseInt((String) inptFiled.get("lineItems"));
                        String qtNo = (String) inptFiled.get("quoteNo");
                        poMap.put("qtNo", qtNo);
                        
                        ArrayList vendList = new ArrayList();
                        int ind = 0;
                        for(int vc = 0; vc < venItems; vc++){                            
                            HashMap vnMap = new HashMap();
                            vnMap.put("VendName", (String) inptFiled.get("name"+vc));
                            vnMap.put("vendAddr", (String) inptFiled.get("v_addr"+vc));
                            vnMap.put("vendId", (String) inptFiled.get("vendId"+vc));
                            vnMap.put("payTerms", (String) inptFiled.get("pTerms"+vc));
                            vnMap.put("delvTerms", (String) inptFiled.get("delvTerms"+vc));
                            vendList.add(vnMap);                                                               
                        }
                        poMap.put("vendDtls", vendList);
                        //Added product details against of vendor for PO
                        ArrayList prodList = new ArrayList();
                        for(int i=1; i<=lineItems; i++){
                            HashMap prodMap = new HashMap();
                            prodMap.put("vendId", (String) inptFiled.get("vId"+i));
                            prodMap.put("product", (String) inptFiled.get("product"+i));
                            prodMap.put("prQty", (String) inptFiled.get("qty"+i));
                            prodMap.put("prSpecs", (String) inptFiled.get("prSpecs"+i));
                            prodMap.put("prWar", (String) inptFiled.get("war"+i));
                            prodMap.put("prPrice", (String)inptFiled.get("price"+i));
                            prodMap.put("totPrice", (String)inptFiled.get("totPrice"+i));
                            prodMap.put("gstRate", (String)inptFiled.get("gstRate"+i));
                            prodMap.put("prId", (String)inptFiled.get("prId"+i));
                            prodList.add(prodMap);
                        }
                        poMap.put("prodDtls", prodList);                                   
                        String autoStatus = RequestForQuotation.autoGenPo(strCmpCd, strLoginId, strOffCd, poMap);                         
                        json.put("Result", autoStatus);
                        pw.print(json);                                                
                    break;                            
                    
                case INSERT_QUOTE: //Added on 04.04.2020
                    items = Integer.parseInt((String) request.getParameter("items"));
                    logger.info(items);
                    ArrayList alMData = new ArrayList();
                    alData = new ArrayList();
                    //Added below lines on 06.04.2020
                    HashMap hmQuoteMD = new HashMap();
                    hmQuoteMD.put("QuoteId", (String) request.getParameter("hQuoteId"));
                    hmQuoteMD.put("EnqId", (String) request.getParameter("hEnqId"));
                    hmQuoteMD.put("CmpName", (String) request.getParameter("hCmpName"));
                    hmQuoteMD.put("EnqDesc", (String) request.getParameter("hEnqDesc"));
                    //hmQuoteMD.put("PayTerms", (String) request.getParameter("hPayTerms"));
                    //Commented above and modified as below on 29.04.2020
                    payTerms = (String) request.getParameter("hPayTerms");
                    othTOP = (String) request.getParameter("hOthTOP");
                    payTerms = payTerms.equalsIgnoreCase("OT") ? othTOP : payTerms;
                    hmQuoteMD.put("PayTerms", payTerms);
                    hmQuoteMD.put("CrDays", (String) request.getParameter("hCrDays"));
                    hmQuoteMD.put("DelvTerms", (String) request.getParameter("hDelvTerms"));
                    hmQuoteMD.put("ValidFor", (String) request.getParameter("hValidFor"));
                    hmQuoteMD.put("AccMngr", (String) request.getParameter("hAccMngr"));
                    alMData.add(hmQuoteMD);
                    //Add above lines on 06.04.2020
                    for (int i = 0; i < items; i++) {
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("EnqId", (String) request.getParameter("id1" + i));
                        hmDealDtls.put("QuoteRowId", (String) request.getParameter("pr_quoteRowId" + i));
                        hmDealDtls.put("EnqRowId", (String) request.getParameter("pr_enqRowId" + i));
                        hmDealDtls.put("DBOper", (String) request.getParameter("db_oper" + i));
                        hmDealDtls.put("PersName", (String) request.getParameter("d_name" + i));
                        hmDealDtls.put("ClientName", (String) request.getParameter("c_name" + i));
                        hmDealDtls.put("ProdName", (String) request.getParameter("p_name" + i));
                        hmDealDtls.put("ProdQty", (String) request.getParameter("pqyt" + i));
                        hmDealDtls.put("BillAddr", (String) request.getParameter("bill_add" + i));
                        hmDealDtls.put("ShipAddr", (String) request.getParameter("ship_add" + i));
                        hmDealDtls.put("ProdSpecs", (String) request.getParameter("specs" + i));
                        hmDealDtls.put("UnitPrice", (String) request.getParameter("unitPr" + i));
                        hmDealDtls.put("GSTRate", (String) request.getParameter("gstRate" + i));
                        hmDealDtls.put("TotPrice", (String) request.getParameter("totPr" + i));
                        hmDealDtls.put("ProdWarr", (String) request.getParameter("prodWar" + i));
                        hmDealDtls.put("ShipReq", (String) request.getParameter("shipReq" + i));
                        hmDealDtls.put("InstReq", (String) request.getParameter("instReq" + i));
                        hmDealDtls.put("ProdId", (String) request.getParameter("prId" + i));
                        hmDealDtls.put("DistKm", (String) request.getParameter("distKm" + i));
                        alData.add(hmDealDtls);
                    }
                    alMData.add(alData);
                    logger.info(alMData);
                    strResp = Enquiry.insQuote(strCmpCd, login_dtls, alMData);
                    json.put("Result", strResp);
                    //Commented above for testing purpose on 17.01.2020
                    //json.put("Result", "Test");
                    pw.println(json);
                    break;

                case INS_RMA_INW_REQ: //Added on 25.08.2020
                    hmData = new HashMap();
                    hmData.put("InwDate", (String) request.getParameter("inw_date"));
                    hmData.put("RefNo", (String) request.getParameter("ref_no"));
                    hmData.put("CmpName", (String) request.getParameter("i_cmp_name"));
                    hmData.put("DealId", (String) request.getParameter("dealId"));
                    hmData.put("DealRowId", (String) request.getParameter("dealRowId"));
                    hmData.put("ProdSNo", (String) request.getParameter("productSNo"));
                    hmData.put("ProdName", (String) request.getParameter("productName"));
                    hmData.put("Remarks", (String) request.getParameter("cl_remarks"));
                    //Added below lines on 15.09.2020
                    String mSStat = (String) request.getParameter("mSStat");
                    String mRepl = (String) request.getParameter("mRepl");
                    String mPStat = (String) request.getParameter("mPStat");
                    mPStat = mPStat == null ? "" : mPStat;
                    String s_godown = (String) request.getParameter("s_godown");
                    s_godown = s_godown == null ? "" : s_godown;

                    hmData.put("MSStat", mSStat);
                    hmData.put("MRepl", mRepl);
                    hmData.put("MPStat", mPStat);
                    hmData.put("Godown", s_godown);

                    if (mSStat.equalsIgnoreCase("TPK")) {
                        sb = new StringBuilder();
                        sb.append("CL:").append((String) request.getParameter("p_cl_name"))
                                .append("; L1:").append((String) request.getParameter("p_add1"))
                                .append("; L2:").append((String) request.getParameter("p_add2"))
                                .append("; CI:").append((String) request.getParameter("p_city"))
                                .append("; PI:").append((String) request.getParameter("p_pin"))
                                .append("; ST:").append((String) request.getParameter("p_state"))
                                .append("; CP: ").append((String) request.getParameter("pc_per"))
                                .append("; CN:").append((String) request.getParameter("p_cno"))
                                .append("; EM:").append((String) request.getParameter("p_emailId"))
                                .append("; GSTN:").append((String) request.getParameter("p_gst"));

                        hmData.put("PickAddr", sb.toString());
                    } else {
                        hmData.put("PickAddr", "");
                    }

                    /*
                     if (mRepl.equalsIgnoreCase("IM")) {
                     sb = new StringBuilder();
                     sb.append("CL:").append((String) request.getParameter("s_cl_name"))
                     .append("; L1:").append((String) request.getParameter("s_add1"))
                     .append("; L2:").append((String) request.getParameter("s_add2"))
                     .append("; CI:").append((String) request.getParameter("s_city"))
                     .append("; PI:").append((String) request.getParameter("s_pin"))
                     .append("; ST:").append((String) request.getParameter("s_state"))
                     .append("; CP: ").append((String) request.getParameter("sc_per"))
                     .append("; CN:").append((String) request.getParameter("s_cno"))
                     .append("; EM:").append((String) request.getParameter("s_emailId"))
                     .append("; GSTN:").append((String) request.getParameter("s_gst"));

                     hmData.put("ShipAddr", sb.toString());
                     } else {
                     hmData.put("ShipAddr", "");
                     }
                     */
                    //Commented above and modified as below on 17.02.2021
                    //Shipping address made compulsory
                    sb = new StringBuilder();
                    sb.append("CL:").append((String) request.getParameter("s_cl_name"))
                            .append("; L1:").append((String) request.getParameter("s_add1"))
                            .append("; L2:").append((String) request.getParameter("s_add2"))
                            .append("; CI:").append((String) request.getParameter("s_city"))
                            .append("; PI:").append((String) request.getParameter("s_pin"))
                            .append("; ST:").append((String) request.getParameter("s_state"))
                            .append("; CP: ").append((String) request.getParameter("sc_per"))
                            .append("; CN:").append((String) request.getParameter("s_cno"))
                            .append("; EM:").append((String) request.getParameter("s_emailId"))
                            .append("; GSTN:").append((String) request.getParameter("s_gst"));

                    hmData.put("ShipAddr", sb.toString());

                    //Added above lines on 15.09.2020
                    logger.info(hmData);
                    strResp = RMA.insInwReq(strCmpCd, strLoginId, strOffCd, hmData);
                    json.put("Result", strResp);
//                    json.put("Result", "Test");
                    pw.println(json);
                    break;

                case INS_SERV_CALL: //Added on 11.08.2021
                    hmData = new HashMap();
                    //Added below 4 lines on 11.10.2021
                    String hidOpr = (String) request.getParameter("hidOpr");
                    String hidRMA = (String) request.getParameter("hidRMA");
                    String tktNo = (String) request.getParameter("tkt_no");
                    hmData.put("TktNo", tktNo);
                    hmData.put("SCSource", (String) request.getParameter("sc_source"));
                    hmData.put("SCDateTime", (String) request.getParameter("call_date") + " " + (String) request.getParameter("start_time"));
                    hmData.put("InwDate", (String) request.getParameter("call_date") + " " + (String) request.getParameter("start_time"));
                    hmData.put("CmpName", (String) request.getParameter("i_cmp_name"));
                    hmData.put("DealId", (String) request.getParameter("dealId"));
                    hmData.put("DealRowId", (String) request.getParameter("dealRowId"));
                    hmData.put("ProdSNo", (String) request.getParameter("productSNo"));
                    hmData.put("ProdName", (String) request.getParameter("productName"));
                    hmData.put("Remarks", (String) request.getParameter("cl_remarks"));
                    hmData.put("SWIssue", (String) request.getParameter("software"));
                    String hwIssue = (String) request.getParameter("hardware");
                    hmData.put("HWIssue", hwIssue);
                    hmData.put("UidaiIssue", (String) request.getParameter("uidai"));
                    hmData.put("ProblemObs", (String) request.getParameter("problemObserved"));
                    hmData.put("Resolution", (String) request.getParameter("resolution"));
                    hmData.put("QueryAns", (String) request.getParameter("queryAns"));
                    hmData.put("OemCaseId", (String) request.getParameter("oemCaseId"));
                    hmData.put("OemEmail", (String) request.getParameter("oemEmailAddress"));
                    hmData.put("EscWithOemOn", (String) request.getParameter("escWithOemOn"));
                    hmData.put("SupportMode", (String) request.getParameter("supportMode"));
                    hmData.put("CallStatus", (String) request.getParameter("status"));

                    String mSStatSC = (String) request.getParameter("mSStat");
                    mSStatSC = mSStatSC == null ? "" : mSStatSC;
                    String mReplSC = (String) request.getParameter("mRepl");
                    mReplSC = mReplSC == null ? "" : mReplSC;
                    String mPStatSC = (String) request.getParameter("mPStat");
                    mPStatSC = mPStatSC == null ? "" : mPStatSC;
                    String s_godownSC = (String) request.getParameter("s_godown");
                    s_godownSC = s_godownSC == null ? "" : s_godownSC;

                    hmData.put("MSStat", mSStatSC);
                    hmData.put("MRepl", mReplSC);
                    hmData.put("MPStat", mPStatSC);
                    hmData.put("Godown", s_godownSC);

                    if (mSStatSC.equalsIgnoreCase("TPK")) {
                        sb = new StringBuilder();
                        sb.append("CL:").append((String) request.getParameter("cl_name"))
                                .append("; L1:").append((String) request.getParameter("c_add1"))
                                .append("; L2:").append((String) request.getParameter("c_add2"))
                                .append("; CI:").append((String) request.getParameter("c_city"))
                                .append("; PI:").append((String) request.getParameter("c_pin"))
                                .append("; ST:").append((String) request.getParameter("c_state"))
                                .append("; CP: ").append((String) request.getParameter("c_per"))
                                .append("; CN:").append((String) request.getParameter("c_cno"))
                                .append("; EM:").append((String) request.getParameter("c_emailId"))
                                .append("; GSTN:").append((String) request.getParameter("c_gst"));

                        hmData.put("PickAddr", sb.toString());
                    } else {
                        hmData.put("PickAddr", "");
                    }

                    sb = new StringBuilder();
                    sb.append("CL:").append((String) request.getParameter("cl_name"))
                            .append("; L1:").append((String) request.getParameter("c_add1"))
                            .append("; L2:").append((String) request.getParameter("c_add2"))
                            .append("; CI:").append((String) request.getParameter("c_city"))
                            .append("; PI:").append((String) request.getParameter("c_pin"))
                            .append("; ST:").append((String) request.getParameter("c_state"))
                            .append("; CP: ").append((String) request.getParameter("c_per"))
                            .append("; CN:").append((String) request.getParameter("c_cno"))
                            .append("; EM:").append((String) request.getParameter("c_emailId"))
                            .append("; GSTN:").append((String) request.getParameter("c_gst"));

                    hmData.put("ShipAddr", sb.toString());

                    logger.info(hmData);
                    logger.info(hidOpr);
                    if (hidOpr.equalsIgnoreCase("insert")) { //Added check on 18.10.2021
                        strResp = ServiceCall.insServCall(strCmpCd, strLoginId, strOffCd, hmData);
                        if (strResp.contains("Inserted")) {
                            hmData.put("RefNo", (String) strResp.replace("Inserted ", ""));
                            if (hwIssue.equalsIgnoreCase(ServiceCall.SC_HW_ISSUE_NTR_) || hwIssue.equalsIgnoreCase(ServiceCall.SC_HW_ISSUE_NTREPL_)) {
                                String strResp2 = RMA.insInwReq(strCmpCd, strLoginId, strOffCd, hmData);
                                if (strResp2.contains("Inserted")) {
                                    strResp = strResp.concat(", RMA entry Created");
                                }
                            }
                        }
                    } else { //Added else part on 18.10.2021
                        strResp = ServiceCall.updServCall(strCmpCd, strLoginId, strOffCd, hmData);
                        if (hidRMA.equalsIgnoreCase("no")) {
                            if (strResp.contains("Updated")) {
                                hmData.put("RefNo", (String) strResp.replace("Updated ", ""));
                                Date dt = new Date();
                                hmData.put("InwDate", sdf_YYYMMDD_HHmmss.format(dt));
                                if (hwIssue.equalsIgnoreCase(ServiceCall.SC_HW_ISSUE_NTR_) || hwIssue.equalsIgnoreCase(ServiceCall.SC_HW_ISSUE_NTREPL_)) {
                                    String strResp2 = RMA.insInwReq(strCmpCd, strLoginId, strOffCd, hmData);
                                    if (strResp2.contains("Inserted")) {
                                        strResp = strResp.concat(", RMA entry Created");
                                    }
                                }
                            }
                        }
                    }
                    json.put("Result", strResp);
//                    json.put("Result", "Test");
                    pw.println(json);
                    break;

                case GET_SERV_CALL_INFO: //Added on 30.09.2021
                    dealId = request.getParameter("tktNo");
                    alData = ServiceCall.getServCallDtls(login_dtls, dealId, "ALL", null, null); //Added two null params on 04.10.2021
                    logger.info(alData);
                    json.put("Data", alData);
                    pw.println(json);
                    break;

                case CHK_RMA_REFNO: //Added on 26.08.2020
                    dealId = request.getParameter("refno");
                    strResp = RMA.chkRefNoExists(strCmpCd, dealId);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case CHK_DEAL_INVNO: //Added on 28.01.2021
                    invNo = request.getParameter("inv_no");
                    logger.info(invNo);
                    strResp = Deal.getDealId(strCmpCd, invNo);
                    strResp = strResp == null ? "" : strResp;
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case CHK_SERV_CONTR_INVNO: //Added on 10.02.2021
                    invNo = request.getParameter("inv_no");
                    strResp = ServiceContract.getServContrId(strCmpCd, invNo);
                    strResp = strResp == null ? "" : strResp;
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case CHK_PONO: //Added on 10.02.2021
                    invNo = request.getParameter("po_no");
                    logger.info(invNo);
                    strResp = PurchaseOrder.getPOId(strCmpCd, invNo);
                    strResp = strResp == null ? "" : strResp;
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case APPR_RMA_REQ: //Added on 17.09.2020
                    hmData = new HashMap();
                    hmData.put("RMAId", (String) request.getParameter("m_rmaId"));
                    hmData.put("UpdDate", (String) request.getParameter("updDate"));
                    hmData.put("RMAStat", (String) request.getParameter("selStatus"));
                    strResp = RMA.updRMAStat(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPD_RMA_REMARKS: //Added on 23.11.2021
                    hmData = new HashMap();
                    hmData.put("RMAId", (String) request.getParameter("m_rmaId"));
                    hmData.put("UpdDate", (String) request.getParameter("updDate"));
                    hmData.put("Remarks", (String) request.getParameter("remarks"));
                    logger.info(hmData + " CmpCd: " + strCmpCd + " LoginId: " + strLoginId);
                    strResp = RMA.updRemarks(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;
                    
                case UPD_RMA: //Added on 02.02.2021
                    hmData = new HashMap();
                    hmData.put("UpdDate", (String) request.getParameter("updDate"));
                    hmData.put("RmaID", (String) request.getParameter("m_rmaId"));
                    hmData.put("Remarks", (String) request.getParameter("remarks"));

                    String mSStat2 = (String) request.getParameter("mSStat");
                    String mRepl2 = (String) request.getParameter("mRepl");
                    String mPStat2 = (String) request.getParameter("mPStat");
                    mPStat2 = mPStat2 == null ? "" : mPStat2;
                    String s_godown2 = (String) request.getParameter("s_godown");
                    s_godown2 = s_godown2 == null ? "" : s_godown2;

                    hmData.put("MSStat", mSStat2);
                    hmData.put("MRepl", mRepl2);
                    hmData.put("MPStat", mPStat2);
                    hmData.put("Godown", s_godown2);

                    //Added below 3 lines on 27.11.2021
                    hmData.put("CourName", (String) request.getParameter("courier_name"));
                    hmData.put("CourDocNo", (String) request.getParameter("courier_doc_no"));
                    hmData.put("CourChgs", (String) request.getParameter("courier_amt_due"));
                    
                    if (mSStat2.equalsIgnoreCase("TPK")) {
                        sb = new StringBuilder();
                        sb.append("CL:").append((String) request.getParameter("p_cl_name"))
                                .append("; L1:").append((String) request.getParameter("p_add1"))
                                .append("; L2:").append((String) request.getParameter("p_add2"))
                                .append("; CI:").append((String) request.getParameter("p_city"))
                                .append("; PI:").append((String) request.getParameter("p_pin"))
                                .append("; ST:").append((String) request.getParameter("p_state"))
                                .append("; CP: ").append((String) request.getParameter("pc_per"))
                                .append("; CN:").append((String) request.getParameter("p_cno"))
                                .append("; EM:").append((String) request.getParameter("p_emailId"))
                                .append("; GSTN:").append((String) request.getParameter("p_gst"));

                        hmData.put("PickAddr", sb.toString());
                    } else {
                        hmData.put("PickAddr", "");
                    }

                    if (mRepl2.equalsIgnoreCase("IM")) {
                        sb = new StringBuilder();
                        sb.append("CL:").append((String) request.getParameter("s_cl_name"))
                                .append("; L1:").append((String) request.getParameter("s_add1"))
                                .append("; L2:").append((String) request.getParameter("s_add2"))
                                .append("; CI:").append((String) request.getParameter("s_city"))
                                .append("; PI:").append((String) request.getParameter("s_pin"))
                                .append("; ST:").append((String) request.getParameter("s_state"))
                                .append("; CP: ").append((String) request.getParameter("sc_per"))
                                .append("; CN:").append((String) request.getParameter("s_cno"))
                                .append("; EM:").append((String) request.getParameter("s_emailId"))
                                .append("; GSTN:").append((String) request.getParameter("s_gst"));

                        hmData.put("ShipAddr", sb.toString());
                    } else {
                        hmData.put("ShipAddr", "");
                    }

                    logger.info(hmData);
                    strResp = RMA.updRMA(strCmpCd, strLoginId, strOffCd, hmData);
                    json.put("Result", strResp);

                    pw.println(json);
                    break;

                case UPD_RMA_TCHK_STATUS: //Added on 18.03.2021
                    hmData = new HashMap();
                    hmData.put("UpdDate", (String) request.getParameter("updDate"));
                    hmData.put("RmaID", (String) request.getParameter("m_rmaId"));

                    String mPStat3 = (String) request.getParameter("mPStat");
                    mPStat3 = mPStat3 == null ? "" : mPStat3;
                    String s_godown3 = (String) request.getParameter("s_godown");
                    s_godown3 = s_godown3 == null ? "" : s_godown3;

                    hmData.put("MPStat", mPStat3);
                    hmData.put("Godown", s_godown3);

                    logger.info(hmData);
                    strResp = RMA.updTCHKStat(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);

                    pw.println(json);
                    break;

                case UPD_RMA_TSSC_STATUS: //Added on 26.06.2021
                    hmData = new HashMap();
                    hmData.put("UpdDate", (String) request.getParameter("updDate"));
                    hmData.put("RmaID", (String) request.getParameter("m_rmaId"));

                    String mPStat4 = (String) request.getParameter("mPStat");
                    mPStat4 = mPStat4 == null ? "" : mPStat4;
                    String s_godown4 = (String) request.getParameter("s_godown");
                    s_godown4 = s_godown4 == null ? "" : s_godown4;

                    hmData.put("MPStat", mPStat4);
                    hmData.put("Godown", s_godown4);

                    logger.info(hmData);
                    strResp = RMA.updTSSCStat(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);

                    pw.println(json);
                    break;

                case GET_DEAL_DETAILS: //Added on 29.05.2019
                    dealId = request.getParameter("dealId");
                    invNo = request.getParameter("invNo"); //Added on 24.09.2020
                    logger.info("DealId:" + dealId + " InvNo: " + invNo);
                    //ArrayList alDeal = Deal.getDealDetails(strCmpCd, dealId, null);
                    //Commented above and modified as below on 24.09.2020
                    ArrayList alDeal = Deal.getDealDetails(strCmpCd, dealId, invNo);
                    logger.info(alDeal);
                    json.put("Deal", alDeal);
                    pw.println(json);
                    break;

                case GET_DEAL_PRIMARY_INFO: //Added on 06.10.2020
                    dealId = request.getParameter("dealId");
                    logger.info("DealId:" + dealId);
                    alData = Deal.getDealPrimaryInfo(strCmpCd, dealId);
                    json.put("Deal", alData);
                    pw.println(json);
                    break;

                case GET_SERV_CONTR_DETAILS: //Added on 19.09.2020
                    dealId = request.getParameter("dealId");
                    invNo = request.getParameter("invNo"); //Added on 11.03.2021
                    logger.info("DealId:" + dealId);
                    //alData = ServiceContract.getDetails(strCmpCd, dealId, null);
                    //Commented above and modified as below on 11.03.2021
                    alData = ServiceContract.getDetails(strCmpCd, dealId, invNo);
                    logger.info(alData);
                    json.put("SContract", alData);
                    pw.println(json);
                    break;

                case UPD_DEAL_INV_DETAILS:
                    int updItems = Integer.parseInt((String) request.getParameter("invItems"));
                    logger.info(updItems);
                    ArrayList alUpdData = new ArrayList();
                    for (int i = 0; i < updItems; i++) {
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                        hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                        String strInvNo = (String) request.getParameter("inv_no" + i);
                        String strInvDt = (String) request.getParameter("inv_dt" + i);
                        logger.info(strInvNo.isEmpty());
                        hmDealDtls.put("InvNo", strInvNo);
                        hmDealDtls.put("InvDt", strInvDt);
                        if (!(strInvNo.isEmpty() || strInvDt.isEmpty())) {
                            alUpdData.add(hmDealDtls);
                        }
                    }
                    logger.info(alUpdData);
                    if (alUpdData.isEmpty()) {
                        json.put("Result", "No Data to Update");
                    } else {
                        String strUpdResp = Deal.updDealInvDetails(strCmpCd, strLoginId, alUpdData);
                        json.put("Result", strUpdResp);
                    }
                    pw.println(json);
                    break;

                case UPD_SERV_CONTR_INV_DETAILS: //Added on 21.09.2020
                    iCount = Integer.parseInt((String) request.getParameter("invItems"));
                    logger.info(iCount);
                    alData = new ArrayList();
                    for (int i = 0; i < iCount; i++) {
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("ContrId", (String) request.getParameter("i_contrId" + i));
                        hmDealDtls.put("ContrRowId", (String) request.getParameter("i_contrRowId" + i));
                        String strInvNo = (String) request.getParameter("inv_no" + i);
                        String strInvDt = (String) request.getParameter("inv_dt" + i);
                        logger.info(strInvNo.isEmpty());
                        hmDealDtls.put("InvNo", strInvNo);
                        hmDealDtls.put("InvDt", strInvDt);
                        if (!(strInvNo.isEmpty() || strInvDt.isEmpty())) {
                            alData.add(hmDealDtls);
                        }
                    }
                    if (alData.isEmpty()) {
                        json.put("Result", "No Data to Update");
                    } else {
                        //Added below 3 lines on 16.10.2020
                        ArrayList alMain = new ArrayList();
                        alMain.add(alData);
                        alMain.add((String) request.getParameter("i_contr_status"));
                        alMain.add((String) request.getParameter("i_bill_due_dt"));
                        alMain.add((String) request.getParameter("i_bill_cycle"));
                        alMain.add((String) request.getParameter("i_pay_term"));
                        alMain.add((String) request.getParameter("i_start_dt"));
                        logger.info(alMain);

                        strResp = ServiceContract.updInvDetails(strCmpCd, strLoginId, alMain);
                        json.put("Result", strResp);
                    }
                    pw.println(json);
                    break;

                case GET_DEAL_INVOICES: //Added on 29.05.2019
                    String dealIdInv = request.getParameter("dealId");
                    ArrayList alDealInv = Deal.getDealInvoices(strCmpCd, dealIdInv);
                    logger.info(alDealInv);
                    json.put("DealInv", alDealInv);
                    pw.println(json);
                    break;

                case GET_DEAL_ALL_INVOICES: //Added on 24.09.2020
                    dealId = request.getParameter("dealId");
                    alData = Deal.getDealInvs(strCmpCd, dealId, null);
                    logger.info(alData);
                    json.put("DealInv", alData);
                    pw.println(json);
                    break;

                case GET_SERV_CONTR_INVOICES: //Added on 22.09.2020
                    dealId = request.getParameter("contrId");
                    alData = ServiceContract.getInvoices(strCmpCd, dealId);
                    logger.info(alData);
                    json.put("ContrInv", alData);
                    pw.println(json);
                    break;

                case GET_SERV_CONTR_ALL_INVOICES: //Added on 11.03.2021
                    dealId = request.getParameter("contrId");
                    alData = ServiceContract.getContrInvs(strCmpCd, dealId, null);
                    logger.info(alData);
                    json.put("ContrInv", alData);
                    pw.println(json);
                    break;

                case GET_DEAL_INV_DTLS: //Added on 29.05.2019
                    dealId = request.getParameter("dealId");
                    invNo = request.getParameter("invNo");
                    alData = Deal.getDealInvDtls(strCmpCd, dealId, invNo);
                    logger.info(alData);
                    json.put("InvDtls", alData);
                    pw.println(json);
                    break;

                case GET_SERV_CONTR_INV_DTLS: //Added on 22.09.2020
                    dealId = request.getParameter("contrId");
                    invNo = request.getParameter("invNo");
                    alData = ServiceContract.getInvDtls(strCmpCd, dealId, invNo);
                    logger.info(alData);
                    json.put("InvDtls", alData);
                    pw.println(json);
                    break;

                case GET_PEND_PO_ITEMS: //Added on 07.09.2020
                    dealId = request.getParameter("poId");
                    alData = PurchaseOrder.getPendPOItems(strCmpCd, dealId);
                    logger.info(alData);
                    json.put("POItems", alData);
                    pw.println(json);
                    break;

                case GET_DEAL_INV_DTLS_PACK: //Added on 25.07.2019
                    dealId = request.getParameter("dealId");
                    invNo = request.getParameter("invNo");
                    alData = Deal.getDealInvDtlsPack(strCmpCd, dealId, invNo);
                    logger.info(alData);
                    json.put("InvDtls", alData);
                    pw.println(json);
                    break;

                case INS_DEAL_INV_SNOS:
                case INS_SERV_CONTR_INV_SNOS: //Added on 22.09.2020
                    int invItems = Integer.parseInt((String) request.getParameter("s_invItems"));
                    logger.info(invItems);
                    alData = new ArrayList();
                    for (int i = 0; i < invItems; i++) {
                        //Added below lines on 25.07.2019
                        String toProcess = (String) request.getParameter("chkProcess" + i);
                        toProcess = toProcess == null ? "N" : toProcess;
                        if (toProcess.equals("Y")) {
                            //Added above check on 25.07.2019
                            HashMap hmDealDtls = new HashMap();
                            /*
                             hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                             */
                            //Commented above and modified as below on 22.09.2020
                            if (oprx.equals(INS_DEAL_INV_SNOS)) {
                                hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                                hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                                hmDealDtls.put("ProdId", (String) request.getParameter("i_prId" + i)); //Added on 30.11.2020
                            } else {
                                hmDealDtls.put("ContrId", (String) request.getParameter("i_contrId" + i));
                                hmDealDtls.put("ContrRowId", (String) request.getParameter("i_contrRowId" + i));
                            }
                            int qty = Integer.parseInt((String) request.getParameter("i_qty" + i));
                            hmDealDtls.put("ProdQty", qty);
                            String snoEx = (String) request.getParameter("sNo_EX" + i);
                            snoEx = snoEx == null ? "N" : snoEx;
                            hmDealDtls.put("SNOs", snoEx);
                            logger.info(hmDealDtls);
                            ArrayList alSNOs = new ArrayList();
                            if (snoEx.equals("Y")) {
                                /*
                                 for (int i2 = 0; i2 < qty; i2++) {
                                 String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                 alSNOs.add(sno);
                                 }
                                 */
                                //Commented above and modified as below on 25.07.2019
                                //sNo_InSer
                                String snoInSer = (String) request.getParameter("sNo_InSer" + i);
                                snoInSer = snoInSer == null ? "N" : snoInSer;
                                if (snoInSer.equals("Y")) {
                                    //sNo_Rows
                                    int iRows = Integer.parseInt((String) request.getParameter("sNo_Rows" + i));
                                    for (int i2 = 0; i2 < iRows; i2++) {
                                        String snoAlpha = "";
                                        String snoFr = (String) request.getParameter("SNoFr" + i + "" + i2);
                                        String snoTo = (String) request.getParameter("SNoTo" + i + "" + i2);
                                        alSNOs.add(snoFr);
                                        int iSNoFr;
                                        int iSNoTo;
                                        try {
                                            iSNoFr = Integer.parseInt(snoFr);
                                            iSNoTo = Integer.parseInt(snoTo);
                                        } catch (NumberFormatException numberFormatException) {
                                            /*
                                             iSNoFr = Integer.parseInt(snoFr.replaceAll("\\D+", ""));
                                             iSNoTo = Integer.parseInt(snoTo.replaceAll("\\D+", ""));
                                             snoAlpha = snoFr.replace(String.valueOf(iSNoFr), "");
                                             */
                                            //Commented above and modified as below on 20.08.2019
                                            try {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - (String.valueOf(qty).length() + 1)));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - (String.valueOf(qty).length() + 1)));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - (String.valueOf(qty).length() + 1));
                                            } catch (NumberFormatException numberFormatException1) {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - String.valueOf(qty).length()));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - String.valueOf(qty).length()));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - String.valueOf(qty).length());
                                            }
                                        }
                                        while (iSNoFr != iSNoTo) {
                                            iSNoFr++;
                                            if (snoAlpha.isEmpty()) {
                                                alSNOs.add(String.valueOf(iSNoFr));
                                            } else {
                                                int orLen = snoFr.length();
                                                int exLen = String.valueOf(iSNoFr).length();
                                                while (snoAlpha.length() + exLen != orLen) {
                                                    snoAlpha = snoAlpha.concat("0");
                                                }
                                                alSNOs.add(snoAlpha.concat(String.valueOf(iSNoFr)));
                                            }
                                        }
                                    }

                                } else {
                                    for (int i2 = 0; i2 < qty; i2++) {
                                        String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                        //alSNOs.add(sno);
                                        //Commented above and added below lines on 26.12.2020
                                        ArrayList alT = new ArrayList();
                                        alT.add(sno);
                                        alT.add((String) request.getParameter("pkg_box" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgLNo" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgGrpNo" + i + "_" + i2));
                                        alSNOs.add(alT);
                                    }

                                }

                            }
                            hmDealDtls.put("SNOsData", alSNOs);
                            alData.add(hmDealDtls);
                        }
                    }
                    logger.info(alData);
                    //strResp = Deal.insProdSNOs(strCmpCd, strLoginId, alData);
                    //Commented above and modified as below on 22.09.2020
                    if (oprx.equals(INS_DEAL_INV_SNOS)) {
                        strResp = Deal.insProdSNOs(strCmpCd, strLoginId, alData);
                    } else {
                        strResp = ServiceContract.insProdSNOs(strCmpCd, strLoginId, alData);
                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case INS_INW_STOCK: //Added on 08.09.2020
                case INS_STOCK: //Added on 30.09.2020
                    int iItems = Integer.parseInt((String) request.getParameter("s_poItems"));
                    logger.info(iItems);
                    alData = new ArrayList();
                    for (int i = 0; i < iItems; i++) {
                        String toProcess = (String) request.getParameter("chkProcess" + i);
                        toProcess = toProcess == null ? "N" : toProcess;
                        if (toProcess.equals("Y")) {
                            HashMap hmDealDtls = new HashMap();
                            hmDealDtls.put("Godown", (String) request.getParameter("s_godown"));
                            hmDealDtls.put("InvNo", (String) request.getParameter("s_inv_no")); //Added on 04.02.2021
                            hmDealDtls.put("RecdDate", (String) request.getParameter("s_rect_date"));
                            //Added above 2 lines on 14.09.2020
                            //Added below lines on 29.06.2021
                            String strStkFor = (String) request.getParameter("stk_for");
                            strStkFor = strStkFor == null ? "" : strStkFor;
                            hmDealDtls.put("StockFor", strStkFor);
                            String strStkStat = (String) request.getParameter("stk_stat");
                            strStkStat = strStkStat == null ? "" : strStkStat;
                            hmDealDtls.put("StockStat", strStkStat);
                            //Added above lines on 29.06.2021
                            hmDealDtls.put("POId", (String) request.getParameter("i_poId" + i));
                            hmDealDtls.put("PORowId", (String) request.getParameter("i_poRowId" + i));
                            hmDealDtls.put("ProdId", (String) request.getParameter("i_prodId" + i));
                            hmDealDtls.put("ProdSpecs", (String) request.getParameter("i_prodSpecs" + i));
                            int qty = Integer.parseInt((String) request.getParameter("i_qty" + i));
                            hmDealDtls.put("ProdQty", qty);
                            int aQty = Integer.parseInt((String) request.getParameter("i_aQty" + i));
                            aQty = aQty == 0 ? qty : aQty;
                            hmDealDtls.put("ProdActQty", aQty); //Added on 05.02.2021
                            String snoEx = (String) request.getParameter("sNo_EX" + i);
                            snoEx = snoEx == null ? "N" : snoEx;
                            hmDealDtls.put("SNOs", snoEx);
                            logger.info(hmDealDtls);
                            ArrayList alSNOs = new ArrayList();
                            if (snoEx.equals("Y")) {
                                String snoInSer = (String) request.getParameter("sNo_InSer" + i);
                                snoInSer = snoInSer == null ? "N" : snoInSer;
                                if (snoInSer.equals("Y")) {
                                    //sNo_Rows
                                    int iRows = Integer.parseInt((String) request.getParameter("sNo_Rows" + i));
                                    logger.info(iRows);
                                    for (int i2 = 0; i2 < iRows; i2++) {
                                        String snoAlpha = "";
                                        String snoFr = (String) request.getParameter("SNoFr" + i + "" + i2);
                                        String snoTo = (String) request.getParameter("SNoTo" + i + "" + i2);
                                        alSNOs.add(snoFr);
                                        int iSNoFr;
                                        int iSNoTo;
                                        try {
                                            iSNoFr = Integer.parseInt(snoFr);
                                            iSNoTo = Integer.parseInt(snoTo);
                                        } catch (NumberFormatException numberFormatException) {
                                            try {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - (String.valueOf(qty).length() + 1)));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - (String.valueOf(qty).length() + 1)));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - (String.valueOf(qty).length() + 1));
                                            } catch (NumberFormatException numberFormatException1) {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - String.valueOf(qty).length()));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - String.valueOf(qty).length()));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - String.valueOf(qty).length());
                                            }
                                        }
                                        logger.info(iSNoFr + " " + iSNoTo);
                                        while (iSNoFr != iSNoTo) {
                                            iSNoFr++;
                                            if (snoAlpha.isEmpty()) {
                                                alSNOs.add(String.valueOf(iSNoFr));
                                            } else {
                                                int orLen = snoFr.length();
                                                int exLen = String.valueOf(iSNoFr).length();
                                                logger.info(snoAlpha + " " + orLen + " " + exLen);
                                                if ((snoAlpha.length() + exLen) <= orLen) {
                                                    while ((snoAlpha.length() + exLen) != orLen) {
                                                        snoAlpha = snoAlpha.concat("0");
                                                    }
                                                } else {
                                                    snoAlpha = snoAlpha.substring(0, snoAlpha.length() - 1);
                                                }
                                                logger.info(snoAlpha.concat(String.valueOf(iSNoFr)));
                                                alSNOs.add(snoAlpha.concat(String.valueOf(iSNoFr)));
                                            }
                                        }
                                    }

                                } else {
                                    for (int i2 = 0; i2 < qty; i2++) {
                                        String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                        alSNOs.add(sno);
                                    }

                                }

                            }
                            hmDealDtls.put("SNOsData", alSNOs);
                            hmDealDtls.put("ReturnItem", "N"); //Added on 25.06.2021
                            
                            //Added fllowing line below fetch poNo on 21-01.2025
                            hmDealDtls.put("poNo",request.getParameter("s_pono"));    
                            alData.add(hmDealDtls);
                        }
                    }
                    logger.info(alData);
                    //strResp = PurchaseOrder.insProdStock(strCmpCd, login_dtls, alData);
                    //Commented above and modified as below on 30.09.2020
                    if (oprx.equalsIgnoreCase(INS_INW_STOCK)) {
                        strResp = PurchaseOrder.insProdStock(strCmpCd, login_dtls, alData);
                        
                    } else {
                        strResp = PurchaseOrder.insStock(strCmpCd, login_dtls, alData);
                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;
                case INS_STOCK_TRANSFER: //Added on 26.10.2023 by Rabindra Sharma
                    int rowsCounts=0;
                    HashMap stData = new HashMap();
                    stData.put("refNo",request.getParameter("refNo"));
                    stData.put("stDate",request.getParameter("stTDate"));                    
                    stData.put("stBillAddr",(String) request.getParameter("bill_add"));
                    stData.put("stClientName",(String) request.getParameter("client_name"));
                    stData.put("stType",(String) request.getParameter("stType")); 
                    stData.put("sGodown",request.getParameter("s_godown")); 
                    stData.put("dGodown",request.getParameter("d_godown")); 
                    sb = new StringBuilder();
                    sb.append("L1:").append((String) request.getParameter("s_add1")).append("; ")
                                .append("L2:").append((String) request.getParameter("s_add2")).append("; ")
                                .append("CI:").append((String) request.getParameter("s_city")).append("; ")
                                .append("ST:").append((String) request.getParameter("s_state")).append("; ")
                                .append("PI:").append((String) request.getParameter("s_pin")).append("; ")
                                .append("CN:").append((String) request.getParameter("s_cno")).append("; ")
                                .append("EM:").append((String) request.getParameter("s_emailId")).append("; ")
                                .append("GSTN:").append((String) request.getParameter("s_gst")).append("; ")
                                .append("CP:").append((String) request.getParameter("sc_per"));
                        String shipTOAdd = sb.toString();
                        sb = new StringBuilder();
                        sb.append("L1:").append((String) request.getParameter("b_add1")).append("; ")
                                .append("L2:").append((String) request.getParameter("b_add2")).append("; ")
                                .append("CI:").append((String) request.getParameter("b_city")).append("; ")
                                .append("ST:").append((String) request.getParameter("b_state")).append("; ")
                                .append("PI:").append((String) request.getParameter("b_pin")).append("; ")
                                .append("CN:").append((String) request.getParameter("b_cno")).append("; ")
                                .append("EM:").append((String) request.getParameter("b_emailId")).append("; ")
                                .append("GSTN:").append((String) request.getParameter("b_gst")).append("; ")
                                .append("CP:").append((String) request.getParameter("bc_per"));
                    String shipFromAdd = sb.toString();
                    int stCount = Integer.parseInt(request.getParameter("index"));
                    stData.put("shipToAddr",shipTOAdd);
                    stData.put("shipFromAddr",shipFromAdd);
                    ArrayList stprodDtls = new ArrayList();
                    for(int i=0;i<stCount;i++){
                        HashMap dtls = new HashMap();
                        dtls.put("productName",request.getParameter("productName"+i));
                        dtls.put("prodId",request.getParameter("i_prodId"+i));
                        dtls.put("prodSpecs",request.getParameter("productSpecs"+i));
                        dtls.put("prodQty",request.getParameter("i_qty"+i).trim());
                        dtls.put("prodShipReq",request.getParameter("i_prodShipReq"+i).trim());
                        dtls.put("unitPrice",request.getParameter("i_unitPrice"+i));
                        dtls.put("gst",request.getParameter("i_gst"+i));
                        dtls.put("totalAmt",request.getParameter("i_totalAmt"+i)); 
                        stprodDtls.add(dtls);
                    }

                    stData.put("items",stprodDtls);
                    String stId = (String) request.getParameter("stId"); 
                    stId = stId==null ? "N": stId;
                    String atResult = "";
                    if(stId.equalsIgnoreCase("N")){
                         logger.info("reached stock transfer entry segment");
//                         logger.info("All Data : "+stData);
                         atResult = StockTransfer.insStockTransfer(strCmpCd,strLoginId,stData);
                    }else{
                        logger.info("reached to update stock transfer data");
                        stData.put("stId",  stId);
                        atResult = StockTransfer.updStockTransfer(strCmpCd, strLoginId, stData);
                    }
                    logger.info("result: "+atResult);
                    json.put("Result", atResult);
                    pw.println(json);
                   break;
                case UPD_RETURN_DTLS: //Added on 24.06.2021
                    alData = new ArrayList();
                    hmData = new HashMap();
                    hmData.put("Godown", (String) request.getParameter("s_godown"));
                    hmData.put("RecdDate", (String) request.getParameter("r_date"));
                    hmData.put("OrdId", (String) request.getParameter("rectDealId"));
                    hmData.put("OrdRowId", (String) request.getParameter("rectDealRowId"));
                    hmData.put("ProdId", (String) request.getParameter("rectProdId"));
                    hmData.put("ProdSpecs", (String) request.getParameter("rectProdSpecs"));
                    int qty = Integer.parseInt((String) request.getParameter("rectProdQty"));
                    hmData.put("ProdQty", qty);
                    String snos = (String) request.getParameter("rectSNOs");
                    String snoEx = snos.equalsIgnoreCase("NA") ? "N" : "Y";
                    hmData.put("SNOs", snoEx);
                    logger.info(hmData);
                    ArrayList alSNOs = new ArrayList();
                    if (snoEx.equals("Y")) {
                        String[] snosArr = snos.split(",");
                        for (String snosArr1 : snosArr) {
                            alSNOs.add(snosArr1.trim());
                        }
                    }
                    hmData.put("SNOsData", alSNOs);
                    hmData.put("ReturnItem", "Y");
                    alData.add(hmData);
                    logger.info(alData);
                    //strResp = PurchaseOrder.insProdStock(strCmpCd, login_dtls, alData);
                    //Commented above and modified as below on 30.09.2020
                    strResp = PurchaseOrder.insStock(strCmpCd, login_dtls, alData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case GET_DEAL_INV_PACK: //Added on 07.06.2019
                    dealId = request.getParameter("dealId");
                    alData = Deal.getDealInvoices(strCmpCd, dealId, "N");
                    json.put("DealInv", alData);
                    pw.println(json);
                    break;

                case GET_PEND_DEAL_INV_INST: //Added on 20.06.2020
                    dealId = request.getParameter("dealId");
                    alData = Deal.getPendDealInvForInst(strCmpCd, dealId);
                    json.put("DealInv", alData);
                    pw.println(json);
                    break;

                case INS_DEAL_PACK_LIST:
                    items = Integer.parseInt((String) request.getParameter("pkg_invItems"));
                    logger.info(items);
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++) {
                        //Added below check on 03.09.2019
                        String strAllowPKG = (String) request.getParameter("chkAllowPKG" + i);
                        strAllowPKG = strAllowPKG == null ? "N" : strAllowPKG;
                        if (strAllowPKG.equals("Y")) {
                            //Added above on 03.09.2019
                            HashMap hmDealDtls = new HashMap();
                            hmDealDtls.put("OrdId", (String) request.getParameter("pkg_dealId" + i));
                            hmDealDtls.put("OrdRowId", (String) request.getParameter("pkg_dealRowId" + i));
                        //hmDealDtls.put("PkgDesc", (String) request.getParameter("pkg_desc" + i));
                            //hmDealDtls.put("BoxId", (String) request.getParameter("pkg_grp" + i));
                            //hmDealDtls.put("PkgBoxes", (String) request.getParameter("pkg_box" + i));
                            //Commented above and modified as below on 01.08.2019
                        /*
                             int iProdQty = Integer.parseInt((String) request.getParameter("pkg_qty" + i));
                             hmDealDtls.put("ProdQty", iProdQty);
                             ArrayList alBoxDtls = new ArrayList();
                             for (int j = 0; j < iProdQty; j++) {
                             ArrayList al = new ArrayList();
                             al.add((String) request.getParameter("pkg_desc" + i + j));
                             al.add((String) request.getParameter("pkg_box" + i + j));
                             alBoxDtls.add(al);
                             }
                             hmDealDtls.put("BoxDtls", alBoxDtls);
                             */
                            //Commented above and modified as below on 30.08.2019
                            ArrayList alBoxDtls = new ArrayList();
                            String pkgDesc = request.getParameter("pkg_desc" + i);
                            if (pkgDesc == null) {
                                int iProdQty = Integer.parseInt((String) request.getParameter("pkg_qty" + i));
                                hmDealDtls.put("ProdQty", iProdQty);
                                for (int j = 0; j < iProdQty; j++) {
                                    ArrayList al = new ArrayList();
                                    /*
                                     al.add((String) request.getParameter("pkg_desc" + i + j));
                                     al.add((String) request.getParameter("pkg_box" + i + j));
                                     //Added below 2 lines on 05.09.2019
                                     al.add((String) request.getParameter("pkgLNo" + i + j));
                                     al.add((String) request.getParameter("pkgGrpNo" + i + j));
                                     */
                                    //Commented above and modified as below on 23.03.2020
                                    al.add((String) request.getParameter("pkg_desc" + i + "_" + j));
                                    al.add((String) request.getParameter("pkg_box" + i + "_" + j));
                                    al.add((String) request.getParameter("pkgLNo" + i + "_" + j));
                                    al.add((String) request.getParameter("pkgGrpNo" + i + "_" + j));

                                    alBoxDtls.add(al);
                                }

                            } else {
                                String pkgBoxes[] = pkgDesc.split(",");
                                String grpDesc = request.getParameter("pkg_grp" + i);
                                String grpBoxes[] = grpDesc.split(",");
                                for (int j = 0; j < pkgBoxes.length; j++) {
                                    ArrayList al = new ArrayList();
                                    String pkgBox = (String) pkgBoxes[j];
                                    String boxArr[] = pkgBox.split("X");
                                    al.add(pkgBox); // PCC X BOX
                                    al.add((String) grpBoxes[j]); //Box Group Id
                                    al.add((String) boxArr[1]); //No of Boxes                                
                                    alBoxDtls.add(al);
                                }

                            }

                            hmDealDtls.put("BoxDtls", alBoxDtls);
                            //Modified above lines on 30.08.2019

                            alData.add(hmDealDtls);
                        }
                    }
                    logger.info(alData);
                    strResp = Deal.insDealPackDtls(strCmpCd, strLoginId, alData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;
                //Added below 1 case for stock transfer packing list on 03.11.2023 by Rabindra Sharma
                case INS_STOCK_TR_PACK_LIST:
                    items = Integer.parseInt((String) request.getParameter("pkg_invItems"));
                    logger.info(items);
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++) {
                        //Added below check on 03.09.2019
                        String strAllowPKG = (String) request.getParameter("chkAllowPKG" + i);
                        strAllowPKG = strAllowPKG == null ? "N" : strAllowPKG;
                        if (strAllowPKG.equals("Y")) {
                            //Added above on 03.09.2019
                            HashMap hmDealDtls = new HashMap();
                            hmDealDtls.put("OrdId", (String) request.getParameter("pkg_dealId" + i));
                            hmDealDtls.put("OrdRowId", (String) request.getParameter("pkg_dealRowId" + i));
                        //hmDealDtls.put("PkgDesc", (String) request.getParameter("pkg_desc" + i));
                            //hmDealDtls.put("BoxId", (String) request.getParameter("pkg_grp" + i));
                            //hmDealDtls.put("PkgBoxes", (String) request.getParameter("pkg_box" + i));
                            //Commented above and modified as below on 01.08.2019
                        /*
                             int iProdQty = Integer.parseInt((String) request.getParameter("pkg_qty" + i));
                             hmDealDtls.put("ProdQty", iProdQty);
                             ArrayList alBoxDtls = new ArrayList();
                             for (int j = 0; j < iProdQty; j++) {
                             ArrayList al = new ArrayList();
                             al.add((String) request.getParameter("pkg_desc" + i + j));
                             al.add((String) request.getParameter("pkg_box" + i + j));
                             alBoxDtls.add(al);
                             }
                             hmDealDtls.put("BoxDtls", alBoxDtls);
                             */
                            //Commented above and modified as below on 30.08.2019
                            ArrayList alBoxDtls = new ArrayList();
                            String pkgDesc = request.getParameter("pkg_desc" + i);
                            if (pkgDesc == null) {
                                int iProdQty = Integer.parseInt((String) request.getParameter("pkg_qty" + i));
                                hmDealDtls.put("ProdQty", iProdQty);
                                for (int j = 0; j < iProdQty; j++) {
                                    ArrayList al = new ArrayList();
                                    /*
                                     al.add((String) request.getParameter("pkg_desc" + i + j));
                                     al.add((String) request.getParameter("pkg_box" + i + j));
                                     //Added below 2 lines on 05.09.2019
                                     al.add((String) request.getParameter("pkgLNo" + i + j));
                                     al.add((String) request.getParameter("pkgGrpNo" + i + j));
                                     */
                                    //Commented above and modified as below on 23.03.2020
                                    al.add((String) request.getParameter("pkg_desc" + i + "_" + j));
                                    al.add((String) request.getParameter("pkg_box" + i + "_" + j));
                                    al.add((String) request.getParameter("pkgLNo" + i + "_" + j));
                                    al.add((String) request.getParameter("pkgGrpNo" + i + "_" + j));

                                    alBoxDtls.add(al);
                                }

                            } else {
                                String pkgBoxes[] = pkgDesc.split(",");
                                String grpDesc = request.getParameter("pkg_grp" + i);
                                String grpBoxes[] = grpDesc.split(",");
                                for (int j = 0; j < pkgBoxes.length; j++) {
                                    ArrayList al = new ArrayList();
                                    String pkgBox = (String) pkgBoxes[j];
                                    String boxArr[] = pkgBox.split("X");
                                    al.add(pkgBox); // PCC X BOX
                                    al.add((String) grpBoxes[j]); //Box Group Id
                                    al.add((String) boxArr[1]); //No of Boxes                                
                                    alBoxDtls.add(al);
                                }

                            }

                            hmDealDtls.put("BoxDtls", alBoxDtls);
                            //Modified above lines on 30.08.2019
                            
                            //Modified below lines on 02.11.2023 by Rabindra Sharma
                            hmDealDtls.put("pkgStNo", (String) request.getParameter("pkgStNo"));
                            hmDealDtls.put("pkgDealNo", (String) request.getParameter("stDealNo"));

                            alData.add(hmDealDtls);
                        }
                    }
                    logger.info(alData);
                    strResp = StockTransfer.insDealStPackDtls(strCmpCd, strLoginId, alData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case GET_INV_PACK_LIST: //Added on 11.06.2019
                    invNo = request.getParameter("invNo");
                    alData = Deal.getInvPackList(strCmpCd, invNo);
                    json.put("InvPackList", alData);
                    pw.println(json);
                    break;
                // Added below 1 case for stock transfer packing list dtls on 03.11.2023 by Rabindra Sharma
                case GET_STOCK_TR_PACK_LIST:
                    invNo = request.getParameter("invNo");
                    alData = StockTransfer.getStPackList(strCmpCd, invNo);
                    json.put("StPackList", alData);
                    pw.println(json);
                    break;

                case GET_DEAL_STK_DTLS: //Added on 19.06.2019
                    dealId = request.getParameter("dealId");
                    logger.info("DealId:" + dealId);
                    alDeal = Deal.getDealStkDetails(strCmpCd, dealId, null);
                    logger.info(alDeal);
                    json.put("Deal", alDeal);
                    pw.println(json);
                    break;

                case UPD_DEAL_STK_STAT: //Added on 19.06.2019
                    items = Integer.parseInt((String) request.getParameter("stkItems"));
                    alData = new ArrayList();
                    for (int i = 0; i < items; i++){
                        HashMap hmDealDtls = new HashMap();
                        hmDealDtls.put("OrdId", (String) request.getParameter("stk_dealId" + i));
                        hmDealDtls.put("OrdRowId", (String) request.getParameter("stk_dealRowId" + i));
                        hmDealDtls.put("StkStat", (String) request.getParameter("stk_pos" + i));
                        hmDealDtls.put("StkQty", (String) request.getParameter("stk_qty" + i));
                        alData.add(hmDealDtls);
                    }
                    logger.info(alData);
                    strResp = Deal.updDealStkStatus(strCmpCd, strLoginId, alData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case GET_INV_STICKER_INFO: //Added on 24.06.2019
                    invNo = request.getParameter("invNo");
                    String grpId = request.getParameter("grpId");
                    String plNo = request.getParameter("plNo"); //Added on 03.03.2020
                    alData = Deal.getInvStickerInfo(strCmpCd, invNo, grpId, plNo);
                    json.put("StickerInfo", alData);
                    pw.println(json);
                    break;
                //Added below 1 case for stock transfer sticker info on 03.11.2023 by Rabindra Sharma
                case GET_STOCK_TR_STICKER_INFO:
                    invNo = request.getParameter("invNo");
                    String grpStId = request.getParameter("grpId");
                    String plStNo = request.getParameter("plNo"); //Added on 03.03.2020
                    alData = StockTransfer.getStStickerInfo(strCmpCd, invNo, grpStId, plStNo);
                    logger.info("Sticker Info :"+alData);
                    json.put("StStickerInfo", alData);
                    pw.println(json);
                    break;
                //Added below 1 case for stock transfer dtls for shipments on 03.11.2023 by Rabindra Sharma
                case GET_STOCK_TR_SHIPM_DTLS:
                    dealId = request.getParameter("dealId");
                    alData = StockTransfer.getDealStForShipm(strCmpCd, dealId);
                    logger.info(alData);
                    json.put("InvDtls", alData);
                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                    try {
                        obj = parser.parse(new FileReader(String_rootPath + "\\docs\\" + strCmpCd + "Couriers.json"));
                        json.put("CourierDtls", (JSONArray) obj);
                    } catch (ParseException ex) {
                        logger.error(ex);
                    }
                    logger.info(json.toString());
                    pw.println(json);
                    break;
                
                case GET_INV_FOR_SHIPM: //Added on 26.06.2019
                    dealId = request.getParameter("dealId");
                    alData = Deal.getDealInvForShipm(strCmpCd, dealId);
                    logger.info(alData);
                    json.put("InvDtls", alData);
                    //Added below on 26.07.2019
                    String_contextPath = request.getServletPath();
                    String_realPath = context.getRealPath(String_contextPath);
                    String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                    try {
                        obj = parser.parse(new FileReader(String_rootPath + "\\docs\\" + strCmpCd + "Couriers.json"));
                        json.put("CourierDtls", (JSONArray) obj);
                    } catch (ParseException ex) {
                        logger.error(ex);
                    }
                    logger.info(json.toString());
                    //Added above on 26.07.2019
                    pw.println(json);
                    break;

                case INS_INV_SHIPM_DTLS: //Added on 26.06.2019
                case UPD_INV_SHIPM_DTLS: //Added on 02.12.2020
                    dealId = (String) request.getParameter("shipDealId");
                    HashMap hmSMData = new HashMap();
                    hmSMData.put("DealId", dealId);
                    invNo = (String) request.getParameter("select_inv");
                    hmSMData.put("InvNo", invNo);
                    cnNo = (String) request.getParameter("cn_no");
                    hmSMData.put("CNNo", cnNo);
                    String shipDate = (String) request.getParameter("ship_date");
                    hmSMData.put("CNDate", shipDate);
                    String trName = (String) request.getParameter("transporter_name");
                    hmSMData.put("TranpName", trName);
                    hmSMData.put("EWBNo", (String) request.getParameter("eway_bill_no"));
                    hmSMData.put("TruckNo", (String) request.getParameter("truck_no"));
                    String trackLink = (String) request.getParameter("tracking_link");
                    hmSMData.put("TrackLink", trackLink);
                    logger.info(hmSMData);
                    if (oprx.equalsIgnoreCase(INS_INV_SHIPM_DTLS)) {
                        strResp = Deal.insInvShipmDtls(strCmpCd, strLoginId, hmSMData);
                    } else {
                        strResp = Deal.updInvShipmDtls(strCmpCd, strLoginId, hmSMData); //Added on 02.12.2020
                    }
                    logger.info(strResp);
                    if (strResp.equals("Inserted")) { //Added on 24.10.2019
                        //String strDStat = Deal.checkAndUpdDealStatus(strCmpCd, dealId, invNo);
                        //Commented above and modified as below on 05.11.2019
                        String strDStat = Deal.checkAndUpdDealStatus(strCmpCd, dealId);
                        if (strDStat.equals("done")) {
                            strResp = "Order execution completed";
                        }
                        emIDs = Deal.getEmailIDs(strCmpCd, dealId, strLoginId);
                        //logger.info(emIDs.length);
                        if (emIDs.length > 0) {
                            alData = Deal.getDealInfoForMail(strCmpCd, dealId, invNo);
                            //logger.info(alData);
                            sb = new StringBuilder();
                            /*
                             sb.append("Dear ")
                             .append(alData.get(2))
                             .append(",\n\n")
                             .append("Bearing Deal Name: ")
                             .append(alData.get(1))
                             .append("\t")
                             .append("for the Client: ")
                             .append(alData.get(3))
                             .append("\n")
                             .append("PO No: ")
                             .append(alData.get(4))
                             .append("\t")
                             .append("Dated: ")
                             .append(alData.get(5))
                             .append("\n")
                             .append("is ready for shipment.  Details as below:\n\n")
                             .append("Docket No: ")
                             .append((String) request.getParameter("cn_no"))
                             .append("\n")
                             .append("Through Courier: ")
                             .append((String) request.getParameter("transporter_name"))
                             .append("\n\n");
                            
                             */
                            //Commented above and modified as below on 05.11.2019
                            ArrayList alDealDtls = (ArrayList) alData.get(6);
                            String strBillTo = ((ArrayList) alDealDtls.get(0)).get(1).toString();
                            //strBillTo = strBillTo.replace(trName, dealName)
                            String strShipTo = ((ArrayList) alDealDtls.get(0)).get(2).toString();
                            sb.append("Dear Sir/Madam,<br><br>")
                                    .append("With reference to the subject purchase order released by <b>")
                                    .append(alData.get(3))
                                    .append("</b>, we have dispatched the material. Details as under: <br>")
                                    .append("<table border=1 width=75%>")
                                    .append("<tr><th>PO NO.</th><th>")
                                    .append(alData.get(4))
                                    .append("</th><th><br></th><th>Dated</th><th>")
                                    .append(alData.get(5))
                                    .append("</th></tr><tr><td>Billed To</td><td colspan=4>")
                                    .append(strBillTo)
                                    .append("</td></tr><tr><td>Shipped To</td><td colspan=4>")
                                    .append(strShipTo)
                                    .append("</td></tr><tr><td colspan=5><br></td></tr><tr><td colspan=5>Ordered Items</td></tr>")
                                    .append("<tr><td colspan=4>Item</td><td>Quantity</td></tr>");

                            int iSNo = 0;
                            for (Object alDealDtl : alDealDtls) {
                                ArrayList alTemp = (ArrayList) alDealDtl;
                                sb.append("<tr><td colspan=4>")
                                        .append(++iSNo)
                                        .append(". ")
                                        .append(alTemp.get(3))
                                        .append("</td><td>")
                                        .append(alTemp.get(4))
                                        .append("</td></tr><tr><td colspan=5>SNOs: ")
                                        .append(alTemp.get(9))
                                        .append("</td></tr>");
                            }

                            sb.append("<tr><td colspan=5><br></td></tr>")
                                    .append("<tr><td>Invoice No:</td><td colspan=4>")
                                    .append(invNo)
                                    .append("</td></tr><tr><td>Docket No:</td><td>")
                                    .append(cnNo)
                                    .append("</td><td><br></td><td>Date:</td><td>")
                                    .append(shipDate)
                                    .append("</td></tr><tr><td>Shipped through</td><td colspan=4>")
                                    .append(trName)
                                    //Added below on 20.11.2019
                                    .append("</td></tr><tr><td>Tracking Link</td><td colspan=4>")
                                    .append("<a href=\"")
                                    .append(trackLink)
                                    .append("\">")
                                    .append(trackLink)
                                    .append("</a>")
                                    //Added above on 20.11.2019
                                    .append("</td></tr></table>")
                                    .append("<br><br>")
                                    .append("<b>Note:</b> This is system generated mail, please do not reply back.  Please contact your account manager for further details.")
                                    .append("<br><br>Thanks & Regards.<br>");

                            //.append(login_dtls.getCmpMst().getCmpName());
                            //Commented above and modified as below on 07.11.2019
                            String_contextPath = request.getServletPath();
                            String_realPath = context.getRealPath(String_contextPath);
                            String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                            try {
                                FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                                int ch;
                                while ((ch = fr.read()) != -1) {
                                    sb.append((char) ch);
                                }
                            } catch (FileNotFoundException fe) {
                                logger.error(fe);
                            }

                            String strSubj = "Intimation -- Dispatch details of PO No: " + (String) alData.get(4) + " Dated: " + (String) alData.get(5) + " -- Reg. ";

                            //Added below lines on 19.11.2019
                            ArrayList alEMIds = new ArrayList();
                            String[] billto = strBillTo.split("<br>");
                            String[] shipto = strShipTo.split("<br>");
                            if (billto[8].equals(shipto[8])) {
                                alEMIds.add(billto[8].replace("EMail: ", ""));
                            } else {
                                alEMIds.add(billto[8].replace("EMail: ", ""));
                                alEMIds.add(shipto[8].replace("EMail: ", ""));
                            }
                            alEMIds.addAll(Arrays.asList(emIDs));
                            emIDs = new String[alEMIds.size()];
                            for (int i = 0; i < alEMIds.size(); i++) {
                                emIDs[i] = (String) alEMIds.get(i);
                            }
                            //Added above lines on 19.11.2019

                            //sendMail(sb.toString(), "OPEXCEL Order Shipment -- Reg.", emIDs);
                            //Commented above and modified as below on 25.10.2019
                            String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                            String fileName = realpath + "\\" + strCmpCd + "_" + dealId + "_CRM_INV_" + invNo.replace("/", "-") + ".pdf";
                            //sendMail(sb.toString(), "OPEXCEL Order Shipment -- Reg.", emIDs, fileName);
                            //Commented above and modified as below on 05.11.2019
                            //sendMail(sb.toString(), strSubj, emIDs, fileName);
                            //Commented above and modified as below on 25.06.2021
                            String fileName2 = realpath + "\\" + strCmpCd + "_CRM_ITRD.pdf";
                            String[] fileNames = {fileName, fileName2};
                            sendMail(sb.toString(), strSubj, emIDs, fileNames);

                        }

                    }
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                //Added below 1 case for insert shipment dtls for stock transfer provision on 04.11.2023 by Rabindra Sharma
                case INS_STOCK_TR_SHIPM_DTLS:
                case UPD_STOCK_TR_SHIPM_DTLS:
                    dealId = (String) request.getParameter("shipDealId");
                    HashMap hmSMData1 = new HashMap();
                    hmSMData1.put("DealId", dealId);
                    invNo = (String) request.getParameter("select_inv");
                    hmSMData1.put("stNo", invNo);
                    cnNo = (String) request.getParameter("cn_no");
                    hmSMData1.put("CNNo", cnNo);
                    String shipDate1 = (String) request.getParameter("ship_date");
                    hmSMData1.put("CNDate", shipDate1);
                    String trName1 = (String) request.getParameter("transporter_name");
                    hmSMData1.put("TranpName", trName1);
                    hmSMData1.put("EWBNo", (String) request.getParameter("eway_bill_no"));
                    hmSMData1.put("TruckNo", (String) request.getParameter("truck_no"));
                    String trackLink1 = (String) request.getParameter("tracking_link");
                    hmSMData1.put("TrackLink", trackLink1);
                    logger.info(hmSMData1);
                    if (oprx.equalsIgnoreCase(INS_STOCK_TR_SHIPM_DTLS)) {
                        strResp = StockTransfer.insStShipmDtls(strCmpCd, strLoginId, hmSMData1);
                    } else {
                        strResp = StockTransfer.updStShipmDtls(strCmpCd, strLoginId, hmSMData1); //Added on 04.11.2023
                    }
                    logger.info(strResp);
                    if (strResp.equals("Inserted")) { 
                        String strDStat = StockTransfer.checkAndUpdStStatus(strCmpCd, dealId);
                        if (strDStat.equals("done")) {
                            strResp = "Order execution completed";
                        }else{
                            strResp = "execution failed";
                        }
                        emIDs = StockTransfer.getEmailIDs(strCmpCd, dealId, strLoginId);
                        if (emIDs.length > 0) {
                            alData = StockTransfer.getStInfoForMail(strCmpCd, dealId, invNo);
                            logger.info("All Data :"+ alData);
                            sb = new StringBuilder();
                            /*
                             sb.append("Dear ")
                             .append(alData.get(2))
                             .append(",\n\n")
                             .append("Bearing Deal Name: ")
                             .append(alData.get(1))
                             .append("\t")
                             .append("for the Client: ")
                             .append(alData.get(3))
                             .append("\n")
                             .append("PO No: ")
                             .append(alData.get(4))
                             .append("\t")
                             .append("Dated: ")
                             .append(alData.get(5))
                             .append("\n")
                             .append("is ready for shipment.  Details as below:\n\n")
                             .append("Docket No: ")
                             .append((String) request.getParameter("cn_no"))
                             .append("\n")
                             .append("Through Courier: ")
                             .append((String) request.getParameter("transporter_name"))
                             .append("\n\n");
                            
                             */
                            //Commented above and modified as below on 05.11.2019
                            ArrayList alDealDtls = (ArrayList) alData.get(2);
//                            String strBillTo = ((ArrayList) alDealDtls.get(0)).get(1).toString();
                            String strBillTo = ((ArrayList) alDealDtls.get(0)).get(1).toString();
                            //strBillTo = strBillTo.replace(trName, dealName)
//                            String strShipTo = ((ArrayList) alDealDtls.get(0)).get(2).toString();
                            String strShipTo = ((ArrayList) alDealDtls.get(0)).get(2).toString();
                            String stNo1 = ((ArrayList) alDealDtls.get(0)).get(5).toString();
                            String stDate = ((ArrayList) alDealDtls.get(0)).get(6).toString();
                            sb.append("Dear Sir/Madam,<br><br>")
                                    .append("With reference to the subject purchase order released by <b>")
//                                    .append(alData.get(3))
                                    .append("</b>, we have dispatched the material. Details as under: <br>")
                                    .append("<table border=1 width=75%>")
//                                    .append("<tr><th>PO NO.</th><th>")
//                                    .append(alData.get(4))
                                    .append("</th><th><br></th><th>Dated</th><th>")
//                                    .append(alData.get(5))
                                    .append("</th></tr><tr><td>Billed To</td><td colspan=4>")
                                    .append(strBillTo)
                                    .append("</td></tr><tr><td>Shipped To</td><td colspan=4>")
                                    .append(strShipTo)
                                    .append("</td></tr><tr><td colspan=5><br></td></tr><tr><td colspan=5>Ordered Items</td></tr>")
                                    .append("<tr><td colspan=4>Item</td><td>Quantity</td></tr>");

                            int iSNo = 0;
                            for (Object alDealDtl : alDealDtls) {
                                ArrayList alTemp = (ArrayList) alDealDtl;
                                sb.append("<tr><td colspan=4>")
                                        .append(++iSNo)
                                        .append(". ")
                                        .append(alTemp.get(3))
                                        .append("</td><td>")
                                        .append(alTemp.get(4))
                                        .append("</td></tr><tr><td colspan=5>SNOs: ")
                                        .append(alTemp.get(9))
                                        .append("</td></tr>");
                            }
                            sb.append("<tr><td colspan=5><br></td></tr>")
                                    .append("<tr><td>Invoice No:</td><td colspan=4>")
                                    .append(invNo)
                                    .append("</td></tr><tr><td>Docket No:</td><td>")
                                    .append(cnNo)
                                    .append("</td><td><br></td><td>Date:</td><td>")
                                    .append(shipDate1)
                                    .append("</td></tr><tr><td>Shipped through</td><td colspan=4>")
                                    .append(trName1)
                                    //Added below on 20.11.2019
                                    .append("</td></tr><tr><td>Tracking Link</td><td colspan=4>")
                                    .append("<a href=\"")
                                    .append(trackLink1)
                                    .append("\">")
                                    .append(trackLink1)
                                    .append("</a>")
                                    //Added above on 20.11.2019
                                    .append("</td></tr></table>")
                                    .append("<br><br>")
                                    .append("<b>Note:</b> This is system generated mail, please do not reply back.  Please contact your account manager for further details.")
                                    .append("<br><br>Thanks & Regards.<br>");

                            //.append(login_dtls.getCmpMst().getCmpName());
                            //Commented above and modified as below on 07.11.2019
                            String_contextPath = request.getServletPath();
                            String_realPath = context.getRealPath(String_contextPath);
                            String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                            try {
                                FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                                int ch;
                                while ((ch = fr.read()) != -1) {
                                    sb.append((char) ch);
                                }
                            } catch (FileNotFoundException fe) {
                                logger.error(fe);
                            }

                            String strSubj = "Intimation -- Dispatch details of Stock Transfer No: " + stNo1 + " Dated: " + stDate + " -- Reg. ";

                            //Added below lines on 19.11.2019
                            ArrayList alEMIds = new ArrayList();
                            /*String[] billto = strBillTo.split("<br>");
                            String[] shipto = strShipTo.split("<br>");
                            if (billto[8].equals(shipto[8])) {
                                alEMIds.add(billto[8].replace("EMail: ", ""));
                            } else {
                                alEMIds.add(billto[8].replace("EMail: ", ""));
                                alEMIds.add(shipto[8].replace("EMail: ", ""));
                            }*/
                            alEMIds.addAll(Arrays.asList(emIDs));
                            emIDs = new String[alEMIds.size()];
                            for (int i = 0; i < alEMIds.size(); i++) {
                                emIDs[i] = (String) alEMIds.get(i);
                            }
                            //Added above lines on 19.11.2019
                            //sendMail(sb.toString(), "OPEXCEL Order Shipment -- Reg.", emIDs);
                            //Commented above and modified as below on 25.10.2019
                            String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                            String fileName = realpath + "\\" + strCmpCd + "_" + dealId + "_CRM_INV_" + invNo.replace("/", "-") + ".pdf";
                            //sendMail(sb.toString(), "OPEXCEL Order Shipment -- Reg.", emIDs, fileName);
                            //Commented above and modified as below on 05.11.2019
                            //sendMail(sb.toString(), strSubj, emIDs, fileName);
                            //Commented above and modified as below on 25.06.2021
                            String fileName2 = realpath + "\\" + strCmpCd + "_CRM_ITRD.pdf";
                            String[] fileNames = {fileName, fileName2};
                            sendMail(sb.toString(), strSubj, emIDs, fileNames);
                        }
                    }
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);    
                    break;
                case INS_RMA_SHIPM_DTLS: //Added on 12.11.2020
                    dealId = (String) request.getParameter("sm_rmaId");
                    HashMap rmaSMData = new HashMap();
                    rmaSMData.put("RmaId", dealId);
                    invNo = (String) request.getParameter("ch_no");
                    rmaSMData.put("InvNo", invNo);
                    cnNo = (String) request.getParameter("cn_no");
                    rmaSMData.put("CNNo", cnNo);
                    rmaSMData.put("CNDate", (String) request.getParameter("ship_date"));
                    rmaSMData.put("TranpName", (String) request.getParameter("transporter_name"));
                    rmaSMData.put("EWBNo", (String) request.getParameter("eway_bill_no"));
                    rmaSMData.put("TruckNo", (String) request.getParameter("truck_no"));
                    rmaSMData.put("TrackLink", (String) request.getParameter("tracking_link"));
                    rmaSMData.put("ProdSNO", (String) request.getParameter("sm_pr_sno"));
                    rmaSMData.put("Product", (String) request.getParameter("sm_prodName")); //Added on 01.02.2021
                    //Added below 2 lines on 06.03.2021
                    rmaSMData.put("ReplProduct", (String) request.getParameter("sm_replProdName"));
                    rmaSMData.put("ReplProdId", (String) request.getParameter("productId"));
                     //Added below 2 lines on 20.11.2021
                    rmaSMData.put("StockFR", (String) request.getParameter("selItemFrom"));
                    rmaSMData.put("PrProdSNO", (String) request.getParameter("pr_pr_sno"));
                    rmaSMData.put("PrPhyStat", (String) request.getParameter("pr_phyStat")); //Added on 22.11.2021

                    logger.info(rmaSMData);
                    strResp = RMA.insShipmDtls(strCmpCd, strLoginId, rmaSMData);
                    logger.info(strResp);
//                    if (strResp.equals("Inserted")) {
//                        String strDStat = Deal.checkAndUpdDealStatus(strCmpCd, dealId);
//                        if (strDStat.equals("done")) {
//                            strResp = "Order execution completed";
//                        }
//                        emIDs = Deal.getEmailIDs(strCmpCd, dealId, strLoginId);
//                        if (emIDs.length > 0) {
//                            alData = Deal.getDealInfoForMail(strCmpCd, dealId, invNo);
//                            sb = new StringBuilder();
//                            ArrayList alDealDtls = (ArrayList) alData.get(6);
//                            String strBillTo = ((ArrayList) alDealDtls.get(0)).get(1).toString();
//                            String strShipTo = ((ArrayList) alDealDtls.get(0)).get(2).toString();
//                            sb.append("Dear Sir/Madam,<br><br>")
//                                    .append("With reference to the subject purchase order released by <b>")
//                                    .append(alData.get(3))
//                                    .append("</b>, we have dispatched the material. Details as under: <br>")
//                                    .append("<table border=1 width=75%>")
//                                    .append("<tr><th>PO NO.</th><th>")
//                                    .append(alData.get(4))
//                                    .append("</th><th><br></th><th>Dated</th><th>")
//                                    .append(alData.get(5))
//                                    .append("</th></tr><tr><td>Billed To</td><td colspan=4>")
//                                    .append(strBillTo)
//                                    .append("</td></tr><tr><td>Shipped To</td><td colspan=4>")
//                                    .append(strShipTo)
//                                    .append("</td></tr><tr><td colspan=5><br></td></tr><tr><td colspan=5>Ordered Items</td></tr>")
//                                    .append("<tr><td colspan=4>Item</td><td>Quantity</td></tr>");
//
//                            int iSNo = 0;
//                            for (Object alDealDtl : alDealDtls) {
//                                ArrayList alTemp = (ArrayList) alDealDtl;
//                                sb.append("<tr><td colspan=4>")
//                                        .append(++iSNo)
//                                        .append(". ")
//                                        .append(alTemp.get(3))
//                                        .append("</td><td>")
//                                        .append(alTemp.get(4))
//                                        .append("</td></tr><tr><td colspan=5>SNOs: ")
//                                        .append(alTemp.get(9))
//                                        .append("</td></tr>");
//                            }
//
//                            sb.append("<tr><td colspan=5><br></td></tr>")
//                                    .append("<tr><td>Invoice No:</td><td colspan=4>")
//                                    .append(invNo)
//                                    .append("</td></tr><tr><td>Docket No:</td><td>")
//                                    .append(cnNo)
//                                    .append("</td><td><br></td><td>Date:</td><td>")
//                                    .append(shipDate)
//                                    .append("</td></tr><tr><td>Shipped through</td><td colspan=4>")
//                                    .append(trName)
//                                    //Added below on 20.11.2019
//                                    .append("</td></tr><tr><td>Tracking Link</td><td colspan=4>")
//                                    .append("<a href=\"")
//                                    .append(trackLink)
//                                    .append("\">")
//                                    .append(trackLink)
//                                    .append("</a>")
//                                    //Added above on 20.11.2019
//                                    .append("</td></tr></table>")
//                                    .append("<br><br>")
//                                    .append("<b>Note:</b> This is system generated mail, please do not reply back.  Please contact your account manager for further details.")
//                                    .append("<br><br>Thanks & Regards.<br>");
//
//                            String_contextPath = request.getServletPath();
//                            String_realPath = context.getRealPath(String_contextPath);
//                            String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
//                            try {
//                                FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
//                                int ch;
//                                while ((ch = fr.read()) != -1) {
//                                    sb.append((char) ch);
//                                }
//                            } catch (FileNotFoundException fe) {
//                                logger.error(fe);
//                            }
//
//                            String strSubj = "Intimation -- Dispatch details of PO No: " + (String) alData.get(4) + " Dated: " + (String) alData.get(5) + " -- Reg. ";
//
//                            //Added below lines on 19.11.2019
//                            ArrayList alEMIds = new ArrayList();
//                            String[] billto = strBillTo.split("<br>");
//                            String[] shipto = strShipTo.split("<br>");
//                            if (billto[8].equals(shipto[8])) {
//                                alEMIds.add(billto[8].replace("EMail: ", ""));
//                            } else {
//                                alEMIds.add(billto[8].replace("EMail: ", ""));
//                                alEMIds.add(shipto[8].replace("EMail: ", ""));
//                            }
//                            alEMIds.addAll(Arrays.asList(emIDs));
//                            emIDs = new String[alEMIds.size()];
//                            for (int i = 0; i < alEMIds.size(); i++) {
//                                emIDs[i] = (String) alEMIds.get(i);
//                            }
//
//                            String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
//                            String fileName = realpath + "\\" + strCmpCd + "_" + dealId + "_CRM_INV_" + invNo.replace("/", "-") + ".pdf";
//                            sendMail(sb.toString(), strSubj, emIDs, fileName);
//
//                        }
//
//                    }
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case INS_RMA_TSSC_DTLS: //Added on 20.11.2020
                    dealId = (String) request.getParameter("sc_rmaId");
                    HashMap rmaTSSCData = new HashMap();
                    rmaTSSCData.put("RmaId", dealId);
                    invNo = (String) request.getParameter("sc_ch_no");
                    rmaTSSCData.put("InvNo", invNo);
                    cnNo = (String) request.getParameter("sc_cn_no");
                    rmaTSSCData.put("CNNo", cnNo);
                    rmaTSSCData.put("CNDate", (String) request.getParameter("sc_ship_date"));
                    rmaTSSCData.put("TranpName", (String) request.getParameter("sc_transporter_name"));
                    rmaTSSCData.put("EWBNo", (String) request.getParameter("sc_eway_bill_no"));
                    rmaTSSCData.put("TruckNo", (String) request.getParameter("sc_truck_no"));
                    rmaTSSCData.put("TrackLink", (String) request.getParameter("sc_tracking_link"));
                    rmaTSSCData.put("ProdSNO", (String) request.getParameter("sc_sm_pr_sno"));

                    sb = new StringBuilder();
                    sb.append("CL:").append((String) request.getParameter("sc_cl_name"))
                            .append("; L1:").append((String) request.getParameter("sc_add1"))
                            .append("; L2:").append((String) request.getParameter("sc_add2"))
                            .append("; CI:").append((String) request.getParameter("sc_city"))
                            .append("; PI:").append((String) request.getParameter("sc_pin"))
                            .append("; ST:").append((String) request.getParameter("sc_state"))
                            .append("; CP: ").append((String) request.getParameter("sc_c_per"))
                            .append("; CN:").append((String) request.getParameter("sc_cno"))
                            .append("; EM:").append((String) request.getParameter("sc_emailId"))
                            .append("; GSTN:").append((String) request.getParameter("sc_gst"));

                    rmaTSSCData.put("SCAddr", sb.toString());

                    logger.info(rmaTSSCData);
                    strResp = RMA.insTSSCDtls(strCmpCd, strLoginId, rmaTSSCData);
                    logger.info(strResp);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case SEND_QUOTE: //Added on 10.04.2020
                    String quoteId = (String) request.getParameter("quoteId");
                    String enqId = (String) request.getParameter("enqId");
                    String emailId = (String) request.getParameter("emailId");
                    String reqMent = (String) request.getParameter("reqMent");
                    String persName = (String) request.getParameter("persName");
                    String persDesig = (String) request.getParameter("persDesig");
                    logger.info("QuoteId: " + quoteId + " EnqId: " + enqId + " EMailId: " + emailId + " ReqMent: " + reqMent + " PersName: " + persName + " PersDesig: " + persDesig);
                    hmData = new HashMap();
                    hmData.put("EnqId", enqId);
                    hmData.put("EnqStat", "QM"); //Quote Mailed
                    hmData.put("FollowupType", "ALL");
                    logger.info(hmData.toString());
//                    hmData.put("NextDate", request.getParameter("followupDate"));
//                    hmData.put("Remarks", request.getParameter("remarks"));
                    strResp = Enquiry.updEnquiry(strCmpCd, strLoginId, strOffCd, hmData);
                    logger.info(strResp);
                    if (strResp.equals("Updated")) {
                        emIDs = Enquiry.getEmailIDs(strCmpCd, quoteId, strLoginId);
                        if (emIDs.length > 0) {
                            sb = new StringBuilder();
                            sb.append("Dear Sir/Madam,<br><br>")
                                    .append("Kind Attn: ")
                                    .append(persName);

                            if (!persDesig.isEmpty()) {
                                sb.append(" (")
                                        .append(persDesig)
                                        .append(") <br><br>");
                            }

                            sb.append("With reference to the subject requirement, please find enclosed our Quotation.  <br>")
                                    .append("Hope you find the same as competitive.<br>");

                            sb.append("<br><br>")
                                    .append("<b>Note:</b> This is system generated mail.  Please contact your account manager for further details.")
                                    .append("<br><br>Thanks & Regards.<br>");

                            String_contextPath = request.getServletPath();
                            String_realPath = context.getRealPath(String_contextPath);
                            String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                            try {
                                FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                                int ch;
                                while ((ch = fr.read()) != -1) {
                                    sb.append((char) ch);
                                }
                            } catch (FileNotFoundException fe) {
                                logger.error(fe);
                            }

                            String strSubj = "Quotation -- Requirement of " + reqMent + " -- Reg. ";

                            ArrayList alEMIds = new ArrayList();
                            alEMIds.add(emailId);
                            alEMIds.addAll(Arrays.asList(emIDs));
                            emIDs = new String[alEMIds.size()];
                            for (int i = 0; i < alEMIds.size(); i++) {
                                emIDs[i] = (String) alEMIds.get(i);
                            }

                            String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                            String fileName = realpath + "\\" + strCmpCd + "_" + quoteId + "_CRM_QUOTE_" + enqId + ".pdf";
                            sendMail(sb.toString(), strSubj, emIDs, fileName);

                        }

                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;
                    
                case SEND_QUOTE_RFQ: //Added on 10.04.2020
                    String quoteIds = (String) request.getParameter("quoteId");
                    String vendId = (String) request.getParameter("enqId");
                    String vendEmailId = (String) request.getParameter("emailId");
                    String vendReqMent = (String) request.getParameter("reqMent");
                    String vendName = (String) request.getParameter("persName");
                    String vendDesig = (String) request.getParameter("persDesig");
                    String isSentTo = (String) request.getParameter("isSentTo");
//                    logger.info("isSentTo :"+isSentTo);                    
//                    logger.info("QuoteId: " + quoteIds + " EnqId: " + vendId + " EMailId: " + vendEmailId + " ReqMent: " + vendReqMent + " PersName: " + vendName + " PersDesig: " + vendDesig);
                    hmData = new HashMap();
                    hmData.put("EnqId", vendId);
                    hmData.put("EnqStat", "QM"); //Quote Mailed
                    hmData.put("FollowupType", "ALL");
                    
                    if (vendEmailId.length() > 0) {
                            String strSubj = "Quotation -- Requirement of " + vendReqMent + " -- Reg. ";    
                             byte[] bytes = CrmProperties.SECRET.getBytes();                             
                             if(isSentTo.equalsIgnoreCase("ALL")){       
                                SecretKey key = new SecretKeySpec(bytes,"AES");
                                TokenSecurity encrypter = new TokenSecurity(key);  
                                ArrayList vendDtlsList = RequestForQuotation.getVendDtls(strCmpCd, strLoginId, quoteIds);                                                                                              
                                for(int vIndx = 0; vIndx<vendDtlsList.size(); vIndx++){                                    
                                    ArrayList vItem = (ArrayList) vendDtlsList.get(vIndx);                                   
                                    String vendorId = (String) vItem.get(0);
                                    vendName = (String) vItem.get(2);
                                    String vendEmail = (String) vItem.get(4);                                    

                                    String tokenString = strCmpCd+":"+vendorId+":"+quoteIds; 
                                    String secretKey = encrypter.encrypt(tokenString);
                                    logger.info("secret key : "+secretKey);                                    
                                    logger.info("Decrypted :- "+vIndx+" "+encrypter.decrypt(secretKey));                                    
                                    
                                    String linkUrl = "http://localhost:8080/BioAs_MT_VER3.1/Crm.do?operation=getQuote&tokenKey=".concat(secretKey).trim();
                                    sb = new StringBuilder();
                                    sb.append("Dear Sir/Madam,<br><br>")
                                    .append("Kind Attn: ")
                                       .append(vendName).append(" <br><br>")                                   
                                        .append("With reference to the subject requirement, please find enclosed our Quotation.  <br>")
                                        .append("Hope you find the same as competitive.<br><br>")
                                        .append("<strong>Please fillout the quotation on the link given below :</strong> <br>")
                                        .append("<a href=").append(linkUrl).append(">").append(linkUrl).append("</a>");

                                        sb.append("<br><br>")
                                       .append("<b>Note:</b> This is system generated mail.  Please contact your account manager for further details.")
                                       .append("<br><br>Thanks & Regards.<br>");
                                        
                                       String_contextPath = request.getServletPath();
                                       String_realPath = context.getRealPath(String_contextPath);
                                       String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                                    try {
                                        FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                                        int ch;
                                        while ((ch = fr.read()) != -1) {
                                            sb.append((char) ch);
                                        }
                                    } catch (FileNotFoundException fe) {
                                        logger.error(fe);
                                    }
                                        String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                                        String fileName = realpath + "\\" + strCmpCd + "_" + quoteIds + "_RFQ_" + vendorId + ".pdf";                                                        
                                        sendMailSingle(sb.toString(), strSubj, vendEmail, fileName);
                                        RequestForQuotation.updateMailedStatus(strCmpCd, quoteIds, vendorId);
                                }                                                                                              
                            }else{                                 
                                SecretKey key = new SecretKeySpec(bytes,"AES");
                                TokenSecurity encrypter = new TokenSecurity(key); 
                                String tokenString = strCmpCd+":"+vendId+":"+quoteIds;                                                                                            
                                String secretKey = encrypter.encrypt(tokenString);                                
                                logger.info("secret key:"+secretKey);                                    
                                logger.info("Decrypted :- "+encrypter.decrypt(secretKey)); 
                                
                                String linkUrl = "http://localhost:8080/BioAs_MT_VER3.1/Crm.do?operation=getQuote&tokenKey=".concat(secretKey).trim();                    
                                sb = new StringBuilder();
                                sb.append("Kind Attn: ")
                                    .append(vendName);

                                if (!vendDesig.isEmpty()) {
                                    sb.append(" (")
                                        .append(vendDesig)
                                        .append(") <br><br>");
                                }

                                sb.append("With reference to the subject requirement, please find enclosed our Quotation.  <br>")
                                        .append("Hope you find the same as competitive.<br><br>")
                                        .append("<strong>Please fillout the quotation on the link given below :</strong> <br>")
                                        .append("<a href=").append(linkUrl).append(">").append(linkUrl).append("</a>");

                                sb.append("<br><br>")
                                        .append("<b>Note:</b> This is system generated mail.  Please contact your account manager for further details.")
                                        .append("<br><br>Thanks & Regards.<br>");
                                String_contextPath = request.getServletPath();
                                String_realPath = context.getRealPath(String_contextPath);
                                String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                                try {
                                    FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                                    int ch;
                                    while ((ch = fr.read()) != -1) {
                                        sb.append((char) ch);
                                    }
                                } catch (FileNotFoundException fe) {
                                    logger.error(fe);
                                }

                                ArrayList alEMIds = new ArrayList();
                                alEMIds.add(vendEmailId);   
                                emIDs = new String[alEMIds.size()];
                                for (int i = 0; i < alEMIds.size(); i++) {
                                    emIDs[i] = (String) alEMIds.get(i);
                                }                                                                                 
                                String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                                String fileName = realpath + "\\" + strCmpCd + "_" + quoteIds + "_RFQ_" + vendId + ".pdf";
                                logger.info("Filename: "+fileName);                            
                                sendMail(sb.toString(), strSubj, emIDs, fileName);
                                RequestForQuotation.updateMailedStatus(strCmpCd, quoteIds, vendId);
                                
                            }
                        }

//                    }
                    json.put("Result", "Updated");
                    pw.println(json);
                    break;

                case SEND_PRO: //Added on 07.08.2020
                    
                    String poId = (String) request.getParameter("poId");
                   String poNo = (String) request.getParameter("poNo");
                    String emId = (String) request.getParameter("emailId");
                    String vPersName = (String) request.getParameter("persName");
                    logger.info("POId: " + poId + " PONo: " + poNo + " EMailId: " + emId + " PersName: " + vPersName);
                    //Added below on 14.08.2020
                    hmData = new HashMap();
                    hmData.put("POId", poId);
                    hmData.put("PONo", poNo);
                    hmData.put("Status", "M"); //PO Mailed
                    logger.info(hmData.toString());
                    strResp = PurchaseOrder.updPOStatus(strCmpCd, strLoginId, strOffCd, hmData);
                    logger.info(strResp);
                    if (strResp.equalsIgnoreCase("Updated")) {
                        //Added above on 14.08.2020
                    if (true) {
                        emIDs = PurchaseOrder.getEmailIDs(strCmpCd, poId, strLoginId);
                        if (emIDs.length > 0) {
                            sb = new StringBuilder();
                            sb.append("Dear Sir/Madam,<br><br>")
                                    .append("Kind Attn: ")
                                    .append(vPersName)
                                    .append("<br><br>");

                            sb.append("With reference to the subject matter, please find enclosed our PO.  <br>")
                                    .append("Please do the needful accordingly.<br>");

                            sb.append("<br><br>")
                                    .append("<b>Note:</b> This is system generated mail.  Please contact your account manager for further details.")
                                    .append("<br><br>Thanks & Regards.<br>");

                            String_contextPath = request.getServletPath();
                            String_realPath = context.getRealPath(String_contextPath);
                            String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                            try {
                                FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                                int ch;
                                try {
                                    while ((ch = fr.read()) != -1) {
                                        sb.append((char) ch);
                                    }
                                } catch (IOException ex) {
                                    java.util.logging.Logger.getLogger(CrmAsyncReqProcessor.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            } catch (FileNotFoundException fe) {
                                logger.error(fe);
                            }

                            String strSubj = "Purchase Order -- Reg. ";

                            ArrayList alEMIds = new ArrayList();
                            //alEMIds.add(emId); //Commented for testing purpose
                            alEMIds.addAll(Arrays.asList(emIDs));
                            emIDs = new String[alEMIds.size()];
                            for (int i = 0; i < alEMIds.size(); i++) {
                                emIDs[i] = (String) alEMIds.get(i);
                            }

                            String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                           poNo = poNo.replace("/", "-");
                            String fileName = realpath + "\\" + strCmpCd + "_" + poId + "_CRM_PRO_" + poNo + ".pdf";
//                            sendMail(sb.toString(), strSubj, emIDs, fileName);
                            strResp = "PO Mailed";
                            logger.info(strResp);

                        }
                    }
                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case SEND_SERV_INV: //Added on 12.10.2020
                    dealId = (String) request.getParameter("contrId");
                    invNo = (String) request.getParameter("invNo");
                    strResp = "Error";
                    emIDs = ServiceContract.getEmailIDs(strCmpCd, dealId, strLoginId);
                    if (emIDs.length > 0) {
                        sb = new StringBuilder();
                        sb.append("Dear Sir/Madam,")
                                .append("<br><br>");

                        sb.append("With reference to the subject matter, please find enclosed Invoice.  <br>")
                                .append("Please do the needful accordingly.<br>");

                        sb.append("<br><br>")
                                .append("<b>Note:</b> This is system generated mail.  Please contact your account manager for further details.")
                                .append("<br><br>Thanks & Regards.<br>");

                        String_contextPath = request.getServletPath();
                        String_realPath = context.getRealPath(String_contextPath);
                        String_rootPath = String_realPath.substring(0, String_realPath.lastIndexOf("\\"));
                        try {
                            FileReader fr = new FileReader(String_rootPath + "\\jsp\\crm\\reports\\" + strCmpCd + "Addr2.jsp");
                            int ch;
                            while ((ch = fr.read()) != -1) {
                                sb.append((char) ch);
                            }
                        } catch (FileNotFoundException fe) {
                            logger.error(fe);
                        }

                        String strSubj = "Service Invoice -- Reg. ";

                        ArrayList alEMIds = new ArrayList();
                        //alEMIds.add(emId); //Commented for testing purpose
                        alEMIds.addAll(Arrays.asList(emIDs));
                        emIDs = new String[alEMIds.size()];
                        for (int i = 0; i < alEMIds.size(); i++) {
                            emIDs[i] = (String) alEMIds.get(i);
                        }

                        String realpath = request.getServletContext().getRealPath(FILE_DIR_PATH);
                        invNo = invNo.replace("/", "-");
                        String fileName = realpath + "\\" + strCmpCd + "_" + dealId + "_CRM_SC_INV_" + invNo + ".pdf";
                        sendMail(sb.toString(), strSubj, emIDs, fileName);
                        strResp = "Invoice Mailed";

                    }

                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case SEND_MAIL: //Added on 10.04.2020
                    String clName = (String) request.getParameter("u_name");
                    String clMobNo = (String) request.getParameter("u_no");
                    String clEmailId = (String) request.getParameter("u_email");
                    //String toEmailIDs = (String) request.getParameter("toEmailIds");
                    //Commented above and modified as below on 29.04.2020
                    String toEmailIDs = efToMailIDs;
                    String clMsg = (String) request.getParameter("msg");
                    logger.info("Name: " + clName + " MobNo: " + clMobNo + " EMailId: " + clEmailId + " Message: " + clMsg);
                    strResp = "failed";
                    if (!clEmailId.isEmpty()) {
                        emIDs = toEmailIDs.split(",");
                        if (emIDs.length > 0) {
                            sb = new StringBuilder();
                            sb.append("Dear Sir,<br><br>");

                            sb.append("An enquiry raised from the portal <b>idsurv.com</b>, details of the same is as below: <br>");

                            sb.append("<br><br>")
                                    .append("   Name: <b>")
                                    .append(clName)
                                    .append("</b><br>   Contact No: <b>")
                                    .append(clMobNo)
                                    .append("</b><br>   EMail Id: <b>")
                                    .append(clEmailId)
                                    .append("</b><br>   Message: <b>")
                                    .append(clMsg)
                                    .append("</b><br><br>")
                                    .append("<b>Note:</b> This is system generated mail, please do not reply back. ")
                                    .append("<br><br>Thanks & Regards.<br>");

                            String strSubj = "Enquiry from idsurv.com -- Reg. ";

                            ArrayList alEMIds = new ArrayList();
                            alEMIds.addAll(Arrays.asList(emIDs));
                            emIDs = new String[alEMIds.size()];
                            for (int i = 0; i < alEMIds.size(); i++) {
                                emIDs[i] = (String) alEMIds.get(i);
                            }

                            //sendMail(sb.toString(), strSubj, emIDs, null);
                            //Commented above and modified as below on 25.06.2021
                            sendMail(sb.toString(), strSubj, emIDs);

                            //Added below lines on 29.04.2020
                            HashMap hmEnq = new HashMap();
                            hmEnq.put("PersName", clName);
                            hmEnq.put("Desig", "NA");
                            hmEnq.put("EMailId", clEmailId);
                            hmEnq.put("MobNo", clMobNo);
                            hmEnq.put("CustId", "0");
                            hmEnq.put("ReqFor", clMsg);
                            hmEnq.put("EnqDate", sdf.format(new Date()));
                            hmEnq.put("LeadSource", LeadSource.WSITE_);
                            hmEnq.put("EnqValue", "0");
                            hmEnq.put("NextDate", sdf.format(new Date()));
                            hmEnq.put("Remarks", "Enquiry raised from web site");
                            hmEnq.put("AccMngr", efMainUser.split(":")[2]);
                            logger.info(hmEnq.toString());
                            strResp = Enquiry.insEnquiry(efMainUser.split(":")[0], efMainUser.split(":")[2], efMainUser.split(":")[1], hmEnq);
                            logger.info(strResp);
                            //Added above lines on 29.04.2020
                            if (strResp.equalsIgnoreCase("Inserted")) {
                                strResp = "success";
                            }
                        }

                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                //Added above lines on 10.04.2020
                case GET_PEND_CNS_FOR_DELV: //Added on 27.06.2019
                    dealId = request.getParameter("dealId");
                    alData = Deal.getPendCNsForDelv(strCmpCd, dealId);
                    json.put("PendCNs", alData);
                    pw.println(json);
                    break;
                // Added below case lines for delivery pending status of stock transfer on 08.11.2023 by Rabindra Sharma 
                case GET_STOCK_TR_FOR_DELV: //Added on 27.06.2019
                    dealId = request.getParameter("dealId");
                    alData = StockTransfer.getPendStForDelv(strCmpCd, dealId);
                    logger.info("Stock No : "+alData);
                    json.put("PendCNs", alData);
                    pw.println(json);
                    break;
                // Added below case lines for stock transfer status on 14.11.2023  by Rabindra Sharma
                case GET_STOCK_STATUS_DTLS:
                    dealId = request.getParameter("dealId");
                    String shiPReq = (String) request.getParameter("shipReq");
                    String stockNo = StockTransfer.getStockStatusDtls(strCmpCd, dealId,shiPReq);
                    logger.info("Stock Id : "+stockNo);
                    json.put("stNo", stockNo);
                    pw.println(json);
                    break;
                case GET_PEND_CNS_FOR_PAY: //Added on 30.03.2021
                    alData = Deal.getPendCNsForPay(strCmpCd, request.getParameter("transpName"), request.getParameter("frDate"), request.getParameter("toDate"));
                    json.put("PendCNs", alData);
                    pw.println(json);
                    break;

                case GET_PAID_CNS: //Added on 02.04.2021
                    alData = Deal.getPaidCNs(strCmpCd, request.getParameter("vchrNo"));
                    json.put("PaidCNs", alData);
                    pw.println(json);
                    break;

                case GET_PEND_CN_DTLS: //Added on 27.06.2019
                    dealId = request.getParameter("dealId");
                    cnNo = request.getParameter("cnNo");
                    alData = Deal.getPendCNDtls(strCmpCd, dealId, cnNo);
                    json.put("CNDtls", alData);
                    pw.println(json);
                    break;
                //Added below case for stock transfer for get pending consignment details on 08.11.2023 by Rabindra Sharma
                case GET_STOCK_TR_CN_DTLS:
                    dealId = request.getParameter("dealId");
                    cnNo = request.getParameter("cnNo");
                    alData = StockTransfer.getPendStCNDtls(strCmpCd, dealId, cnNo);
                    json.put("CNDtls", alData);
                    pw.println(json);
                    break;
                case GET_CN_DELV_DTLS: //Added on 16.03.2021
                    dealId = request.getParameter("dealId");
                    cnNo = request.getParameter("cnNo");
                    alData = Deal.getCNDelvDtls(strCmpCd, dealId, cnNo);
                    json.put("CNDtls", alData);
                    pw.println(json);
                    break;

                case UPD_CN_DELV_DATE: //Added on 28.06.2019
                    dealId = request.getParameter("delvDealId");
                    cnNo = request.getParameter("d_cn_no");
                    String delvDate = request.getParameter("delv_date");
                    if (dealId != null) { //Added this check on 19.11.2020
                        logger.info("Deal ID : "+dealId);
                        strResp = Deal.updCNDelvDate(strCmpCd, strLoginId, dealId, cnNo, delvDate);
                        if (strResp.equals("Updated")) { //Added on 30.10.2019
                            //String strDStat = Deal.checkAndUpdDealStatusUsingDelv(strCmpCd, dealId, cnNo);
                            String strDStat = Deal.checkAndUpdDealStatus(strCmpCd, dealId);
                            if (strDStat.equals("done")) {
                                strResp = "Order execution completed";
                            }
                        }
                    } else { //Added this block on 19.11.2020
                        rmaId = request.getParameter("delvRmaId");
                        logger.info("DelvRMA ID : "+rmaId);
                        strResp = Deal.updCNDelvDate(strCmpCd, strLoginId, rmaId, cnNo, delvDate);
                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;
                // Added below 1 case for update cn delivery date of stock transfer on 08.11.2023 by Rabindra Sharma
                case UPD_STOCK_TR_CN_DELV_DATE:
                    dealId = request.getParameter("delvDealId");
                    cnNo = request.getParameter("d_cn_no");
                    delvDate = request.getParameter("delv_date");
                    if (dealId != null) { //Added this check on 19.11.2020
                        logger.info("Deal ID : "+dealId);
                        strResp = StockTransfer.updStCNDelvDate(strCmpCd, strLoginId, dealId, cnNo, delvDate);
                        if (strResp.equals("Updated")) { //Added on 30.10.2019
                            //String strDStat = Deal.checkAndUpdDealStatusUsingDelv(strCmpCd, dealId, cnNo);
                            String strDStat = StockTransfer.checkAndUpdStStatus(strCmpCd, dealId);
                            if (strDStat.equals("done")) {
                                strResp = "Order execution completed";
                            }
                        }
                    } else { //Added this block on 19.11.2020
                        rmaId = request.getParameter("delvRmaId");
                        logger.info("DelvRMA ID : "+rmaId);
                        strResp = Deal.updCNDelvDate(strCmpCd, strLoginId, rmaId, cnNo, delvDate);
                    }
                    json.put("Result", strResp);
                    pw.println(json);
                    break;
                case GET_PEND_DELV_COUNT: //Added on 28.06.2019
                    iCount = Deal.getPendingDelvCount(strCmpCd, strOffCd, login_dtls); //Added login_dtls param on 11.10.2019);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case PENDING_SHIPMENT_COUNT: //Added on 01.11.2019
                    iCount = Deal.getPendingShipmentsCount(strCmpCd, strOffCd, login_dtls);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case PENDING_INST_COUNT: //Added on 28.11.2019
//                    iCount = Deal.getPendInstCount(strCmpCd, strOffCd, login_dtls);
//                    json.put("Result", String.valueOf(iCount));
                    //Commented above and modified as below on 05.09.2020
                    alData = Deal.getPendInstCount(strCmpCd, strOffCd, login_dtls);
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case UPD_PR_PO_DTLS: //Added on 13.07.2019
                    dealId = request.getParameter("poDealId");
                    dealRowId = request.getParameter("poDealRowId");
                    String prPoNo = request.getParameter("pr_po_no");
                    String prPoDate = request.getParameter("pr_po_date");
                    strResp = Deal.updPrPoDtls(strCmpCd, strLoginId, dealId, dealRowId, prPoNo, prPoDate);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPD_MAT_RECD_ON: //Added on 18.07.2019
                    dealId = request.getParameter("poDealId");
                    dealRowId = request.getParameter("poDealRowId");
                    String matRecdDate = request.getParameter("pr_recd_date");
                    String matQty = request.getParameter("pr_qty"); //Added on 27.12.2019
                    String matRecdQty = request.getParameter("pr_recd_qty");
                    strResp = Deal.updMatRecdOn(strCmpCd, strLoginId, dealId, dealRowId, matRecdDate, matRecdQty, matQty);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPD_RECT_DTLS: //Added on 11.07.2020
                    dealId = request.getParameter("rectDealId");
                    invNo = request.getParameter("rectInvNo");
                    String rectDate = request.getParameter("r_date");
                    String rectAmt = request.getParameter("r_amt");
                    //strResp = Deal.updRectDtls(strCmpCd, strLoginId, dealId, invNo, rectDate, rectAmt);
                    //Commented above and modified as below on 06.11.2020
                    String servContr = request.getParameter("serv_contr"); //Added on 06.11.2020
                    strResp = Deal.updRectDtls(strCmpCd, strLoginId, dealId, invNo, rectDate, rectAmt, servContr);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case ACTIVE_PROJECTS_COUNT:
                    iCount = Deal.getPendingDealsCount(strCmpCd, login_dtls, "Y");
                    logger.info(iCount);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case GET_DEAL_CONTACTS: //Added on 04.12.2019
                    dealId = request.getParameter("dealId");
                    logger.info("DealId:" + dealId);
                    ArrayList alDealC = Deal.getDealContacts(strCmpCd, dealId);
                    logger.info(alDealC);
                    json.put("DealCont", alDealC);
                    pw.println(json);
                    break;

                case CHECK_PRODUCT_EXISTS: //Added on 16.12.2019
                    prName = request.getParameter("pr_name");
                    bStat = CrmAsyncDbManager.isProductExists(strCmpCd, prName);
                    logger.info("PrExists: " + bStat);
                    json.put("Exists", bStat);
                    pw.println(json);
                    break;

                case INSERT_PRODUCT: //Added on 17.12.2019
                    HashMap hmProd = new HashMap();
                    hmProd.put("PrName", request.getParameter("pr_name"));
                    hmProd.put("PrDesc", request.getParameter("pr_desc"));
                    hmProd.put("PrType", request.getParameter("pr_type"));
                    hmProd.put("PrCateg", request.getParameter("pr_categ"));
                    hmProd.put("MfId", request.getParameter("mf_id"));
                    hmProd.put("MfPrId", request.getParameter("mf_pr_id"));
                    hmProd.put("KitStat", request.getParameter("kit_part"));
                    hmProd.put("MainPrId", request.getParameter("main_pr"));
                    hmProd.put("MUnit", request.getParameter("m_unit"));
                    hmProd.put("PrHsnCd", request.getParameter("pr_hsn_cd"));
                    logger.info(hmProd.toString());
                    strResp = Product.insProduct(strCmpCd, strLoginId, hmProd);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPDATE_PRODUCT: //Added on 10.06.2021
                    hmData = new HashMap();
                    hmData.put("PrID", request.getParameter("pr_id"));
                    hmData.put("PrName", request.getParameter("pr_name"));
                    hmData.put("PrDesc", request.getParameter("pr_desc"));
                    hmData.put("PrType", request.getParameter("pr_type"));
                    hmData.put("PrCateg", request.getParameter("pr_categ"));
                    hmData.put("MfId", request.getParameter("mf_id"));
                    hmData.put("MfPrId", request.getParameter("mf_pr_id"));
                    hmData.put("KitStat", request.getParameter("kit_part"));
                    hmData.put("MainPrId", request.getParameter("main_pr"));
                    hmData.put("MUnit", request.getParameter("m_unit"));
                    hmData.put("PrHsnCd", request.getParameter("pr_hsn_cd"));
                    logger.info(hmData.toString());
                    strResp = Product.updProduct(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case GET_MATCHING_PRODUCTS: //Added on 18.12.2019
                    String prodToFind = request.getParameter("pr_name");
                    alData = Product.getProducts(strCmpCd, "T", "ALL", prodToFind, true);
                    json.put("Products", alData);
                    pw.println(json);
                    break;

                case GET_PROD_INFO: //Added on 18.12.2019
                    String prodId = request.getParameter("pr_id");
                    logger.info(prodId + " " + strCmpCd);
                    logger.info("prodID:;" + prodId);
                    alData = Product.getProduct(strCmpCd, prodId, true);
                    json.put("Product", alData);
                    logger.info(alData);
                    pw.println(json);
                    break;

                case GET_PR_INFO_FOR_SNO: //Added on 19.08.2020
                    prName = request.getParameter("pr_name");
                    String prSNo = request.getParameter("pr_sno");
                    logger.info(prName + " " + prSNo);
                    alData = Product.getProductDtls(strCmpCd, prName, prSNo);
                    json.put("ProdDtls", alData);
                    logger.info(alData);
                    pw.println(json);
                    break;

                //Added below on 26.02.2020
                case CHECK_CUST_EXISTS:
                    custName = request.getParameter("c_name");
                    custType = request.getParameter("c_type");
                    bStat = CrmAsyncDbManager.isCustomerExists(strCmpCd, custName, custType);
                    logger.info("CustExists: " + bStat);
                    json.put("Exists", bStat);
                    pw.println(json);
                    break;

                case INSERT_CUSTOMER:
                    logger.info("Test - reached insert customer code segment");
                    HashMap hmCust = new HashMap();
                    hmCust.put("CustName", request.getParameter("c_name"));
                    hmCust.put("CustType", request.getParameter("c_type"));
                    hmCust.put("Industry", request.getParameter("ind_type"));
                    hmCust.put("OffType", request.getParameter("off_type"));
                    hmCust.put("WebSite", request.getParameter("web_site"));
                    hmCust.put("EMailId", request.getParameter("email_id"));
                    hmCust.put("ToNotify", request.getParameter("to_notify"));
                    logger.info(hmCust.toString());
                    strResp = Customer.insCustomer(strCmpCd, strLoginId, hmCust);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                //Added above lines on 26.02.2020
                case GET_MATCHING_CUST: //Added on 29.02.2020
                    String custToFind = request.getParameter("c_name");
                    custType = request.getParameter("c_type");
                    custType = custType == null ? "C" : custType;
                    alData = Customer.getMatchingCustomers(strCmpCd, "T", custToFind, custType);
                    json.put("Customers", alData);
                    pw.println(json);
                    break;

                case GET_CUST_ADDR: //Added on 03.08.2021
                    custId = request.getParameter("cust_id");
                    custType = request.getParameter("c_type");
                    custType = custType == null ? "C" : custType;
                    alData = Customer.getCustAddresses(strCmpCd, custType, custId);
                    json.put("CustAddr", alData);
                    pw.println(json);
                    break;

                case CHECK_ENQ_EXISTS: //Added on 04.03.2020
                    custId = request.getParameter("custId");
                    String pName = request.getParameter("pName");
                    String reqmFor = request.getParameter("reqFor");
                    bStat = CrmAsyncDbManager.isEnquiryExists(strCmpCd, custId, pName, reqmFor);
                    json.put("Exists", bStat);
                    pw.println(json);
                    break;

                case INSERT_ENQUIRY: //Added on 04.03.2020
                    custId = (String) request.getParameter("cust_id");
                    //Added below lines on 28.04.2020
                    if (custId.isEmpty()) {
                        hmData = new HashMap();
                        hmData.put("CustName", request.getParameter("c_name"));
                        hmData.put("CustType", request.getParameter("c_type"));
                        hmData.put("Industry", request.getParameter("ind_type"));
                        hmData.put("OffType", request.getParameter("off_type"));
                        hmData.put("WebSite", request.getParameter("web_site"));
                        hmData.put("EMailId", request.getParameter("co_email_id"));
                        hmData.put("ToNotify", request.getParameter("to_notify"));
                        custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                        custId = custId.split(" ")[2];
                    }
                    //Added above lines on 28.04.2020
                    HashMap hmEnq = new HashMap();
                    hmEnq.put("PersName", request.getParameter("p_name"));
                    hmEnq.put("Desig", request.getParameter("desig"));
                    hmEnq.put("EMailId", request.getParameter("email_id"));
                    hmEnq.put("MobNo", request.getParameter("mob_no"));
                    hmEnq.put("CustId", custId);
                    hmEnq.put("ReqFor", request.getParameter("reqm_for"));
                    hmEnq.put("EnqDate", request.getParameter("enq_date"));
                    hmEnq.put("LeadSource", request.getParameter("l_source"));
                    hmEnq.put("EnqValue", request.getParameter("enq_value"));
                    hmEnq.put("NextDate", request.getParameter("nf_date"));
                    hmEnq.put("Remarks", request.getParameter("remarks"));
                    hmEnq.put("AccMngr", request.getParameter("accMgr"));
                    logger.info(hmEnq.toString());
                    strResp = Enquiry.insEnquiry(strCmpCd, strLoginId, strOffCd, hmEnq);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPDATE_UN_ASSIGN_ENQUIRY: //Added on 01.05.2020
                    custId = (String) request.getParameter("cust_id");
                    custName = (String) request.getParameter("c_name");
                    logger.info(custId + " " + custName);
                    if (custId.isEmpty() && !custName.isEmpty()) {
                        hmData = new HashMap();
                        hmData.put("CustName", request.getParameter("c_name"));
                        hmData.put("CustType", request.getParameter("c_type"));
                        hmData.put("Industry", request.getParameter("ind_type"));
                        hmData.put("OffType", request.getParameter("off_type"));
                        hmData.put("WebSite", request.getParameter("web_site"));
                        hmData.put("EMailId", request.getParameter("co_email_id"));
                        hmData.put("ToNotify", request.getParameter("to_notify"));
                        custId = Customer.insCustomer(strCmpCd, strLoginId, hmData);
                        custId = custId.split(" ")[2];
                    }
                    //Added above lines on 28.04.2020
                    hmData = new HashMap();
                    hmData.put("EnqId", request.getParameter("hEnqId"));
                    hmData.put("PersName", request.getParameter("p_name"));
                    hmData.put("Desig", request.getParameter("desig"));
                    hmData.put("EMailId", request.getParameter("email_id"));
                    hmData.put("MobNo", request.getParameter("mob_no"));
                    hmData.put("CustId", custId);
                    hmData.put("ReqFor", request.getParameter("reqm_for"));
                    hmData.put("EnqDate", request.getParameter("enq_date"));
                    hmData.put("LeadSource", request.getParameter("l_source"));
                    hmData.put("EnqValue", request.getParameter("enq_value"));
                    hmData.put("NextDate", request.getParameter("nf_date"));
                    hmData.put("Remarks", request.getParameter("remarks"));
                    hmData.put("AccMngr", request.getParameter("accMgr"));
                    logger.info(hmData.toString());
                    strResp = Enquiry.updUnAssignedEnq(strCmpCd, strLoginId, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case UPDATE_ENQUIRY: //Added on 28.03.2020
                    hmData = new HashMap();
                    hmData.put("EnqId", request.getParameter("m_enqId"));
                    hmData.put("QuoteId", request.getParameter("m_quoteId"));
                    hmData.put("EnqStat", request.getParameter("selStatus"));
                    hmData.put("FollowupType", request.getParameter("selFollowupType"));
                    hmData.put("NextDate", request.getParameter("followupDate"));
                    hmData.put("Remarks", request.getParameter("remarks"));
                    //Added below 4 lines on 18.04.2020
                    hmData.put("PoNo", request.getParameter("po_no"));
                    hmData.put("PoDate", request.getParameter("po_date"));
                    hmData.put("PoValue", request.getParameter("po_value"));
                    hmData.put("DueDelvDate", request.getParameter("due_delv_date"));
                    //Added below on 25th and 26.06.2020
                    hmData.put("OrdId", request.getParameter("ord_id"));
                    hmData.put("ServContr", request.getParameter("selServContr")); //Added on 04.01.2021
                    String selStat = request.getParameter("selStatus");
                    if (selStat.equalsIgnoreCase("PD")) {
                        int pdqCnt = Integer.parseInt((String) request.getParameter("pdqs_count"));
                        ArrayList alPDQs = new ArrayList();
                        String strFP = request.getParameter("rbFP");
                        strFP = strFP == null ? "" : strFP;
                        alPDQs.add(strFP);
                        for (int i = 0; i < pdqCnt; i++) {
                            String chkStat = request.getParameter("chkNo" + i);
                            logger.info(chkStat);
                            if (chkStat != null) {
                                alPDQs.add((String) request.getParameter("pdq_id" + i));
                            }
                        }
                        String strLP = request.getParameter("rbLP");
                        strLP = strLP == null ? "" : strLP;
                        alPDQs.add(strLP);
                        hmData.put("Remarks", alPDQs.toString());
                    }
                    //Added above on 26.06.2020
                    logger.info(hmData.toString());
                    strResp = Enquiry.updEnquiry(strCmpCd, strLoginId, strOffCd, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case ACTIVE_ENQUIRIES_COUNT: //Added on 05.03.2020
                    iCount = Enquiry.getActiveCount(strCmpCd, login_dtls, false);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case UN_ASSIGN_ENQUIRIES_COUNT: //Added on 01.05.2020
                    iCount = Enquiry.getUnAssignedCount(strCmpCd, login_dtls);
                    json.put("Result", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case CRM_NOTIFY_INFO: //Added on 18.05.2020
                    iCount = Enquiry.getUnAssignedCount(strCmpCd, login_dtls);
                    json.put("UnAssCnt", String.valueOf(iCount));
                    iCount = Enquiry.getActiveCount(strCmpCd, login_dtls, true);
                    json.put("UpdPendCnt", String.valueOf(iCount));
                    pw.println(json);
                    break;

                case GET_EWB_JSON: //Added on 07.03.2020
                    HashMap hmEWB = new HashMap();
                    hmEWB.put("DealId", request.getParameter("dealId"));
                    hmEWB.put("InvNo", request.getParameter("invNo"));
                    hmEWB.put("TrpName", request.getParameter("trpName"));
                    hmEWB.put("TrpCode", request.getParameter("trpCode"));
                    hmEWB.put("TrkNo", request.getParameter("trkNo"));
                    hmEWB.put("SuplySubType", request.getParameter("suplSubType"));
                    hmEWB.put("DocType", request.getParameter("docType"));
                    hmEWB.put("TransMode", request.getParameter("transMode"));
                    hmEWB.put("VehType", request.getParameter("vehType"));
                    hmEWB.put("TransType", request.getParameter("transType"));
                    logger.info(hmEWB.toString());
                    org.json.simple.JSONObject jsObj = Deal.getEWBillJSON(strCmpCd, login_dtls, hmEWB);
                    json.put("Result", jsObj);
                    pw.println(json);
                    break;
                // Added below 1 case for get stock transfer web JSON dtls on 04.11.2023 by Rabindra Sharma
                case GET_STOCK_TR_WEB_JSON :
                    logger.info("we reached to GenWEBJSON for stock transfer side");
                    HashMap hmEWB1 = new HashMap();
                    hmEWB1.put("DealId", request.getParameter("dealId"));
                    hmEWB1.put("InvNo", request.getParameter("invNo"));
                    hmEWB1.put("TrpName", request.getParameter("trpName"));
                    hmEWB1.put("TrpCode", request.getParameter("trpCode"));
                    hmEWB1.put("TrkNo", request.getParameter("trkNo"));
                    hmEWB1.put("SuplySubType", request.getParameter("suplSubType"));
                    hmEWB1.put("DocType", request.getParameter("docType"));
                    hmEWB1.put("TransMode", request.getParameter("transMode"));
                    hmEWB1.put("VehType", request.getParameter("vehType"));
                    hmEWB1.put("TransType", request.getParameter("transType"));
                    logger.info(hmEWB1.toString());
                    org.json.simple.JSONObject jsObj1 = StockTransfer.getStEWBillJSON(strCmpCd, login_dtls, hmEWB1);
                    json.put("Result", jsObj1);
                    pw.println(json);
                    break;
                case INS_BUSINESS_TARGETS: //Added on 24.03.2021
                    hmData = new HashMap();
                    hmData.put("AccMngr", (String) request.getParameter("accMgr"));
                    hmData.put("PrType", (String) request.getParameter("pr_type"));
                    hmData.put("PrCateg", (String) request.getParameter("pr_categ"));
                    hmData.put("TotTargetAmt", (String) request.getParameter("tot_value"));
                    hmData.put("MonthlyTargetAmt", (String) request.getParameter("monthly_amt"));
                    hmData.put("BillCycle", (String) request.getParameter("bill_cycle"));
                    hmData.put("OthMonths", (String) request.getParameter("othMonths"));
                    hmData.put("StartDate", (String) request.getParameter("start_date"));
                    hmData.put("EndDate", (String) request.getParameter("end_date"));
                    logger.info(hmData.toString());
                    strResp = BusinessTargets.insTargets(strCmpCd, strLoginId, strOffCd, hmData);
                    json.put("Result", strResp);
                    pw.println(json);
                    break;

                case GET_BUSINESS_TARGETS: //Added on 24.03.2021
                    hmData = new HashMap();
                    hmData.put("AccMngr", (String) request.getParameter("acc_mngr"));
                    hmData.put("PrType", (String) request.getParameter("pr_type"));
                    hmData.put("PrCateg", (String) request.getParameter("pr_categ"));
                    logger.info(hmData.toString());
                    alData = BusinessTargets.getTargets(strCmpCd, login_dtls, hmData);
                    json.put("Result", alData);
                    pw.println(json);
                    break;

                case "ofc" + GenConstants.ENTITY_UPDATE: //Added below on 24.09.2021
                    hmData = Utilities.getFrmInput(request);
                    hmData.put("isdsPswrd", request.getParameter("isdsPswrd"));
                    logger.info(hmData);
                    Office off_ = new Office();
                    try {
                        if (off_.updateOffice(strCmpCd, hmData)) {
                            json.put("Response", "Updation successful");
                            pw.println(json);
                        }
                    } catch (JSONException ex) {
                        logger.error("Exception is : " + ex.toString());
                    }
                    break;

                case INSERT_TENDER://code for insert a new tender                               
                    {                                                
//                        Tender tender=new Tender();
//                        tender.setTenderNo((String)hmData.get("t_no"));
//                        tender.setOrgName((String)hmData.get("t_org"));
//                        tender.setTenderType((String)hmData.get("t_type"));                       
//                        tender.setTenderValue((String)hmData.get("t_value"));
//                        tender.setTenderFee((String)hmData.get("t_fee"));
//                        tender.setEmdAmt((String)hmData.get("t_emd_amt"));
//                        tender.setEmdException((String)hmData.get("t_emd_exemption"));
//                        tender.setAccMngr((String)hmData.get("t_acc_mgr"));
//                        tender.setContactNo((String)hmData.get("t_contact_no"));
//                        tender.setContactEmail((String)hmData.get("t_contact_email"));
//                        tender.setWebsite((String)hmData.get("t_website"));
//                        tender.setStatus((String)hmData.get("t_status"));
//                        tender.setReqType((String)hmData.get("t_req_type"));
//                        tender.setReqDesc((String)hmData.get("t_req_desc"));
//                        tender.setRemarks((String)hmData.get("t_remarks"));
//                        tender.setDueDate(TenderDao.getDateTime((String)hmData.get("t_due_date"), (String)hmData.get("t_due_time")));
//                        tender.setPublishDate(TenderDao.getDateTime((String)hmData.get("t_pub_date"), (String)hmData.get("t_pub_time")));
//                        tender.setPreBidQueryDate(TenderDao.getDateTime((String)hmData.get("t_pbq_date"), (String)hmData.get("t_pbq_time")));
//                        tender.setPreBidMeetingDate(TenderDao.getDateTime((String)hmData.get("t_pbm_date"), (String)hmData.get("t_pbm_time")));
//                        tender.setTenderProcessingFee((String)hmData.get("t_processing_fee"));
//                        tender.setEmdType((String)hmData.get("t_emd_type"));
//                        tender.setFinancialPQ((String)hmData.get("t_fpq"));
//                        tender.setTechnicalPQ((String)hmData.get("t_tpq"));

//                        String insStat=TenderDao.insertTenderInfo(strCmpCd, strLoginId, tender);
//                        hmData = crm.util.Utilities.getFormDataInputs(request);
//                        logger.info("Received Data : "+hmData);
//                        String insStat = TenderDao.insTender(strCmpCd, strOffCd, strLoginId, hmData);
                        json.put("Result", "Failed");
                    }                
                this.pw.print(json);
                break;

        case UPDATE_TENDER://code for update an existing tender                
                    {
                        Tender tender=new Tender();
                        tender.setTenderId(Long.parseLong(request.getParameter("t_id")));
                        tender.setTenderNo(request.getParameter("t_no"));
                        tender.setOrgName(request.getParameter("t_org"));
                        tender.setTenderType(request.getParameter("t_type"));
                        tender.setTenderValue(request.getParameter("t_value"));
                        tender.setTenderFee(request.getParameter("t_fee"));
                        tender.setEmdAmt(request.getParameter("t_emd_amt"));
                        tender.setEmdException(request.getParameter("t_emd_exemption"));
                        tender.setAccMngr(request.getParameter("t_acc_mgr"));
                        tender.setContactNo(request.getParameter("t_contact_no"));
                        tender.setContactEmail(request.getParameter("t_contact_email"));
                        tender.setWebsite(request.getParameter("t_website"));
                        tender.setStatus(request.getParameter("t_status"));
                        tender.setReqType(request.getParameter("t_req_type"));
                        tender.setReqDesc(request.getParameter("t_req_desc"));
                        tender.setRemarks(request.getParameter("t_remarks"));
                        tender.setDueDate(TenderDao.getDateTime(request.getParameter("t_due_date"),request.getParameter("t_due_time")));
                        tender.setPublishDate(TenderDao.getDateTime(request.getParameter("t_pub_date"),request.getParameter("t_pub_time")));
                        tender.setPreBidQueryDate(TenderDao.getDateTime(request.getParameter("t_pbq_date"),request.getParameter("t_pbq_time")));
                        tender.setPreBidMeetingDate(TenderDao.getDateTime(request.getParameter("t_pbm_date"),request.getParameter("t_pbm_time")));
                        tender.setTenderProcessingFee(request.getParameter("t_processing_fee"));
                        tender.setEmdType(request.getParameter("t_emd_type"));
                        tender.setFinancialPQ(request.getParameter("t_fpq"));
                        tender.setTechnicalPQ(request.getParameter("t_tpq"));
                
                    Tender savedTender=TenderDao.getTenderById(strCmpCd, String.valueOf(tender.getTenderId()));
                    if(savedTender.getIsApproved().equalsIgnoreCase("Y")){
                        json.put("Result", "Failed");
                    }else{
                        String updStat=TenderDao.updateTenderInfo(strCmpCd, strLoginId, strOffCd, tender);
                        json.put("Result", updStat);
                    }
                }
                this.pw.print(json);
                break;
                            
            case CHECK_UNIQUE_TENDER_NO:
                String tenderNo=request.getParameter("t_no").trim();
                boolean isUnique=TenderDao.isUniqueTenderNo(strCmpCd, tenderNo);
                if(isUnique){
                    json.put("Result", "Valid");
                }else{
                    json.put("Result", "Invalid");
                }
                this.pw.print(json);
                break;

            case DELETE_DOCUMENT:                
                String orderId=request.getParameter("orderId").trim();
                String filename=request.getParameter("fileName").trim();
                String delStat=DocumentDao.delDocument(strCmpCd, orderId,filename,request.getServletContext());                
                json.put("Result", delStat);                                
                this.pw.print(json);
                break;

            case TENDER_COUNT:                                                            
                json.put("Result", TenderDao.getTenderCounts(strCmpCd,strOffCd));                                
                this.pw.print(json);
                break;

            case TENDER_MOVE_TO_ARCHIVE:      
                String tenderId=(String)request.getParameter("t_id"); 
                json.put("Result", TenderDao.moveToArchieved(strCmpCd,tenderId));                                
                this.pw.print(json);
                break;

            case TENDER_REMOVE_FROM_ARCHIVE:                              
                String tenderId2=(String)request.getParameter("t_id");                              
                json.put("Result", TenderDao.removeFromArchieved(strCmpCd,tenderId2));                                
                this.pw.print(json);
                break;

            case TENDER_APPROVE:                                    
                String tenderId3=request.getParameter("t_id");    
                String isApproved=request.getParameter("t_approval");     
                json.put("Result", TenderDao.approveTender(strCmpCd,tenderId3,strLoginId,isApproved));                                
                this.pw.print(json);
                break;

            case TENDER_UPDATE_STATUS:
                String tenderId4=request.getParameter("t_id");    
                String status=request.getParameter("t_status");     
                json.put("Result", TenderDao.updateTenderStatus(strCmpCd,tenderId4,status));                                
                this.pw.print(json);
                break;

            case TENDER_ADD_NEW_STATUS:
                String fullName=request.getParameter("status_full");    
                String shortName=request.getParameter("status_short");    
                String statusCat=request.getParameter("status_cat");
                json.put("Result", TenderDao.addNewStatus(strCmpCd,shortName,fullName,statusCat));                                
                this.pw.print(json);
                break;

            case TENDER_EXTEND_DATES:
                String date=request.getParameter("t_due_date");    
                String time=request.getParameter("t_due_time");                
                String dueDate = TenderDao.getDateTime(date, time);
                String tId=request.getParameter("t_id");                
                String extReason=request.getParameter("t_extend_reason");
                json.put("Result", TenderDao.extendTenderDates(strCmpCd,dueDate,tId,extReason,strLoginId));                                
                this.pw.print(json);
                break;

            case TENDER_DETAILS_FOR_EMD:
                String tId1=TenderDao.getTenderId(strCmpCd,request.getParameter("t_no"));                 
                json.put("Result", EMDDao.getEMDTenderDetails(strCmpCd,tId1));                                
                this.pw.print(json);
                break;

            case INSERT_TENDER_EMD:
                {
                    EMD emd=new EMD();
                    emd.setTenderId(request.getParameter("t_id"));
                    emd.setEmdNo(request.getParameter("emd_no"));
                    emd.setEmdType(request.getParameter("emd_type"));
                    emd.setEmdAmt(request.getParameter("emd_amt"));
                    emd.setEmdDate(request.getParameter("emd_date"));
                    emd.setEmdDate2(request.getParameter("emd_date2"));
                    emd.setEmdStatus(request.getParameter("emd_status"));                                    
                    json.put("Result", EMDDao.insertEMD(strCmpCd,strOffCd, strLoginId,emd));  
                }                              
                this.pw.print(json);
                break;

            case UPDATE_TENDER_EMD:
                {
                    EMD emd=new EMD();
                    emd.setEmdId(request.getParameter("emd_id"));
                    emd.setTenderId(request.getParameter("t_id"));
                    emd.setEmdNo(request.getParameter("emd_no"));
                    emd.setEmdType(request.getParameter("emd_type"));
                    emd.setEmdAmt(request.getParameter("emd_amt"));
                    emd.setEmdDate(request.getParameter("emd_date"));
                    emd.setEmdDate2(request.getParameter("emd_date2"));
                    emd.setEmdStatus(request.getParameter("emd_status"));

                    EMD savedEmd=EMDDao.getEMD(strCmpCd, emd.getEmdId());
                    if(savedEmd.getEmdStatus().equalsIgnoreCase("Returned")){
                        json.put("Result", "Failed");  
                    }else{
                        json.put("Result", EMDDao.updateEMD(strCmpCd,emd));  
                    }
                }                              
                this.pw.print(json);
                break;

            case UPDATE_TENDER_EMD_STATUS:
                {
                    String emdId=request.getParameter("emd_id");
                    String emdStatus=request.getParameter("emd_status");
                    String returnDate=request.getParameter("emd_return_date");
                    String updStat=EMDDao.updStatus(strCmpCd,emdId,emdStatus,returnDate);
                json.put("Result", updStat);                             
                }this.pw.print(json);
                break;
            // Added few cases for JSON file configuration on 23-04-2023
               
            case GET_COURIER_JSON_DATA:
                String String_contPP = request.getServletPath();
                String String_realPP = context.getRealPath(String_contPP);
                String String_rootPP = String_realPP.substring(0, String_realPP.lastIndexOf("\\"));
                obj = parser.parse(new FileReader(String_rootPP + "\\docs\\" + strCmpCd + "Couriers.json"));
                json.put("Result", (JSONArray) obj);
//                json.put("Result", (JSONObject) obj);
                this.pw.print(json);
                break;
            case CREATE_UPDATE_COURIER_JSON:
                HashMap upmap = new HashMap();
                String servletPath = request.getServletPath();
                upmap.put("CourierID", (String) request.getParameter("courierId"));
                upmap.put("CourierURL", (String) request.getParameter("courierURL"));
                upmap.put("CourierName", (String) request.getParameter("courierName"));
                upmap.put("TranspID", (String) request.getParameter("transpId"));
                logger.info(upmap.toString());
                String data = JSONConfig.createAndUpdateCourierJson(upmap, context,servletPath, strCmpCd);
                json.put("Result", data);
                this.pw.print(json);
                break;
            case DELETE_REQUEST_COURIER_ITEM:
                HashMap dltmap = new HashMap();
                String dltPath = request.getServletPath();
                dltmap.put("CourierID", (String) request.getParameter("courierId"));
                dltmap.put("TranspID", (String) request.getParameter("transpId"));
                logger.info(dltmap.toString());
                String dltResult = JSONConfig.deleteItemByIds(dltmap, context,dltPath, strCmpCd);
                json.put("Result", dltResult);
                this.pw.print(json);
                break;
            case GET_PRODUCT_CATEGORY:
                String servPath = request.getServletPath();
                obj = JSONConfig.getProdCateList(context, servPath, strCmpCd);
                
                logger.info(obj);
                json.put("Result",(JSONArray) obj);
                this.pw.print(json);
                break;
                
            case REQ_FOR_GET_INDIAN_STATES:
                String serverPath = request.getServletPath();
                obj = JSONConfig.getIndianStates(context, serverPath);
                json.put("Result", (JSONArray) obj);
                this.pw.print(json);
                break;
                
            case ADD_UPDATE_INDIAN_STATE_JSON:
                String statePath = request.getServletPath();
                HashMap stateMap = new HashMap();
                stateMap.put("stateCode", (String) request.getParameter("stateCode"));
                stateMap.put("stateName", (String) request.getParameter("stateName"));
                String stateResult = JSONConfig.addUpdateIndianStates(stateMap, context, statePath);
                json.put("Result", stateResult);
                this.pw.print(json);
                break;
                
            case DELETE_INDIAN_STATE_BY_IDS:
                HashMap dltstateMap = new HashMap();
                String dltstatePath = request.getServletPath();
                dltstateMap.put("stateCode", (String) request.getParameter("stateCode"));
                dltstateMap.put("stateName", (String) request.getParameter("stateName"));
                logger.info(dltstateMap.toString());
                String dltstateResult = JSONConfig.deleteIndianStatesByIds(dltstateMap, context,dltstatePath);
                json.put("Result", dltstateResult);
                this.pw.print(json);
                break;
                
            case ADD_UPDATE_PRODUCT_CATEGORY_JSON:
                String prodSPath = request.getServletPath();
                HashMap proMap = new HashMap();
                proMap.put("productId", (String) request.getParameter("productId"));
                proMap.put("productName", (String) request.getParameter("productName"));
                String prodResult = JSONConfig.addUpdateProductCategory(proMap, context, prodSPath, strCmpCd);
                json.put("Result", prodResult);
                this.pw.print(json);
                break;
                
            case DELETE_PRODUCT_ITEMS_BY_IDS:
                HashMap dltprodMap = new HashMap();
                String dltProdPath = request.getServletPath();
                dltprodMap.put("productId", (String) request.getParameter("productId"));
                dltprodMap.put("productName", (String) request.getParameter("productName"));
                logger.info(dltprodMap.toString());
                String dltProdResult = JSONConfig.deleteProdItemByIds(dltprodMap, context,dltProdPath, strCmpCd);
                json.put("Result", dltProdResult);
                this.pw.print(json);
                break;
                
            case UPDATE_INVOICE:
                HashMap hmap = new HashMap();
                hmap.put("curInvNo", (String)  request.getParameter("curInvNo").trim());
                hmap.put("prevInvNo", (String)  request.getParameter("prevInvNo").trim());
                hmap.put("invDate", (String) request.getParameter("invDate"));
                String updateResult = Deal.getUpdateInv(strCmpCd, hmap, strOffCd);
                json.put("Result", updateResult);
                this.pw.print(json);
                break;
            case REMOVE_INVOICE:
                HashMap rmap = new HashMap();
                rmap.put("curInvNo", (String)  request.getParameter("curInvNo").trim());
                String removeResult = Deal.getRemoveInv(strCmpCd, rmap, strOffCd);
                json.put("Result", removeResult);
                this.pw.print(json);
                break;
            case CHK_MATERIAL_ALLOC_EXISTS:
                HashMap chkMap = new HashMap();
                chkMap.put("invNo", (String) request.getParameter("invNo").trim());
//                chkMap.put("product", (String) request.getParameter("product"));
                String chckStatus = Deal.checkMatExists(strCmpCd, chkMap, strOffCd);
                logger.info(chckStatus);
                json.put("Result", chckStatus);
                this.pw.print(json);
                break;
            case IS_EXISTS_MATPACK_AND_MATSHIP:
                HashMap matMap = new HashMap();
                matMap.put("invNo", (String) request.getParameter("invNo").trim());
                matMap.put("orderId", (String) request.getParameter("orderId"));
                matMap.put("orderDtlsId", (String) request.getParameter("orderDtlsId"));
//                matMap.put("productId", (String) request.getParameter("productId"));
                String matStatus = Deal.checkMatAllocAndPack(strCmpCd,matMap,strOffCd);
                logger.info(matStatus);
                json.put("Result", matStatus);
                this.pw.print(json);
                break;
            case DE_ALLOCATE_MATERIAL:
                HashMap dMap = new HashMap();
                dMap.put("invNo", (String) request.getParameter("invNo").trim());
                dMap.put("orderId", (String) request.getParameter("orderId"));
                dMap.put("orderDtlsId", (String) request.getParameter("orderDtlsId"));
                dMap.put("productId", (String) request.getParameter("productId"));
                dMap.put("prodQty", (String) request.getParameter("prodQty"));
                String dStatus = Deal.deAllocateMat(strCmpCd,dMap,strOffCd);
                logger.info(dStatus);
                json.put("Result", dStatus);
                this.pw.print(json);
                break;
            
            case UN_PACK_WITH_INVNO :
                HashMap unMap = new HashMap();
                unMap.put("invNo", (String) request.getParameter("invNo").trim());
                unMap.put("orderId", (String) request.getParameter("orderId"));
                String unPStatus = Deal.unPackMatWithInvno(strCmpCd, unMap);
                logger.info(unPStatus);
                json.put("Result", unPStatus);
                this.pw.print(json);
                break;    
            case UN_PACK_WITH_PLNO :
                HashMap unpMap = new HashMap();
                unpMap.put("invNo", (String) request.getParameter("invNo").trim());
                unpMap.put("orderId", (String) request.getParameter("orderId"));
                unpMap.put("plNo", (String) request.getParameter("plNo"));
                logger.info(unpMap);
                String unPlStatus = Deal.unPackedMatWithPlNo(strCmpCd, unpMap);
                logger.info(unPlStatus);
                json.put("Result", unPlStatus);
                this.pw.print(json);
                break;    
            case UN_PACK_WITH_PROD_GRP_ID :
                HashMap ungMap = new HashMap();
                ungMap.put("invNo", (String) request.getParameter("invNo").trim());
                ungMap.put("orderId", (String) request.getParameter("orderId"));
                ungMap.put("prodGrpId", (String) request.getParameter("prodGrpId"));
                logger.info(ungMap);
                String unglStatus = Deal.unPackedMatWithProdGrpId(strCmpCd, ungMap);
                logger.info(unglStatus);
                json.put("Result", unglStatus);
                this.pw.print(json);
                break;
            case CHK_SHP_DELV_DATE :
                HashMap ckMap = new HashMap();
                ckMap.put("invNo", (String) request.getParameter("invNo").trim());
                ckMap.put("orderId", (String) request.getParameter("orderId"));
                logger.info(ckMap);
                int ckStatus = Deal.checkDelvDateExists(strCmpCd, ckMap);
                logger.info(ckStatus);
                json.put("Result", ckStatus);
                this.pw.print(json);
                break;
            case REVERSE_SHP_DTLS :
                HashMap shpMap = new HashMap();
                shpMap.put("invNo", (String) request.getParameter("invNo").trim());
                shpMap.put("orderId", (String) request.getParameter("orderId"));
                shpMap.put("shpDtype", (String) request.getParameter("shpDtype"));
                String shpStatus = Deal.reverseShipmDtls(strCmpCd, shpMap,request.getServletContext());
                logger.info(shpStatus);
                json.put("Result", shpStatus);
                this.pw.print(json);
                break;
            case CHK_INST_DATE_ISCOMPLT :
                HashMap isMap = new HashMap();
                isMap.put("invNo", (String) request.getParameter("invNo").trim());
                isMap.put("orderId", (String) request.getParameter("orderId"));
                int isStatus = Deal.checkIsInstComplete(strCmpCd, isMap);
                logger.info(isStatus);
                json.put("Result", isStatus);
                this.pw.print(json);
                break;
            case REVERSE_DELV_DATE :
                HashMap rvMap = new HashMap();
                rvMap.put("invNo", (String) request.getParameter("invNo").trim());
                rvMap.put("orderId", (String) request.getParameter("orderId"));
                String rvStatus = Deal.reverseDelvDate(strCmpCd, strLoginId,rvMap);
                logger.info(rvStatus);
                json.put("Result", rvStatus);
                this.pw.print(json);
                break;
            case REVERSE_INST_REPORTS :
                HashMap instMap = new HashMap();
                instMap.put("invNo", (String) request.getParameter("invNo").trim());
                instMap.put("orderId", (String) request.getParameter("orderId"));
//                instMap.put("shpDtype", (String) request.getParameter("shpDtype"));
                String instStatus = Deal.removeInstReports(strCmpCd, instMap,request.getServletContext());
                logger.info(instStatus);
                json.put("Result", instStatus);
                this.pw.print(json);
                break;
            case IS_PROD_IN_STOCK :
                HashMap isTkMap = new HashMap();
                isTkMap.put("dealId", (String) request.getParameter("dealId"));
                isTkMap.put("dealRowId", (String) request.getParameter("dealRowId"));
                isTkMap.put("prodName", (String) request.getParameter("prodName"));
                String stockStat = Deal.isProdInStock(strCmpCd, isTkMap);
                json.put("Result", stockStat);
                this.pw.print(json);
                break;
            case REVERSE_STOCK_STATUS :
                HashMap ssMap = new HashMap();
                ssMap.put("dealId", (String) request.getParameter("dealId").trim());
                ssMap.put("dealRowId", (String) request.getParameter("dealRowId"));
//                instMap.put("shpDtype", (String) request.getParameter("shpDtype"));
                String ssStatus = Deal.reverseStockStatus(strCmpCd, ssMap,strLoginId);
                logger.info(ssStatus);
                json.put("Result", ssStatus);
                this.pw.print(json);
                break;
            case CHK_STOCK_STATUS :
                HashMap chMap = new HashMap();
                chMap.put("dealId", (String) request.getParameter("dealId").trim());
                chMap.put("PrBillTo", (String) request.getParameter("bill_to_addr"));
                chMap.put("PrShipTo", (String) request.getParameter("ship_to_addr"));
                logger.info(chMap);
                String stStatus = Deal.checkStockStatus(strCmpCd,strLoginId,chMap);
                logger.info(stStatus);
                json.put("Result", stStatus);
                this.pw.print(json);
                break;
                
              case MODIFY_PSWD:
                HashMap HmData = new HashMap();
                HmData.put("currPswd", request.getParameter("cr_pswd"));
                HmData.put("newPswd", request.getParameter("n_pswd"));
                HmData.put("cnfPswd", request.getParameter("cn_pswd"));                               
                String result_cp = CrmAsyncDbManager.changePassword(strCmpCd,strLoginId,HmData);
                json.put("Result", result_cp);
                this.pw.print(json);
                
                break;    
              
                case GET_DEAL_LOCATIONS: //Added on 05.07.2022
                    dealId = request.getParameter("dealId");
                    logger.info("DealId:" + dealId);
                    String strStat2 = request.getParameter("status");
                    strStat2 = strStat2 == null ? "P" : strStat2;
                    alData = Deal.getDealLocations(strCmpCd, dealId, strStat2);
                    json.put("Deal", alData);
                    pw.println(json);
                    break;    
                
             /*Following case added on 02 June 2023*/
           case DC_ENTRY:
                logger.info("reached DC entry segment");
                 int rowsCount=0;
                HashMap dcData = new HashMap();
                dcData.put("dcNo",request.getParameter("dcNo"));
                dcData.put("dcDate",request.getParameter("dcDate"));
                dcData.put("dcDealId",(String)request.getParameter("dcDealId"));
                dcData.put("dcBillAddr",request.getParameter("bill_add"));
                dcData.put("dcClientName",request.getParameter("client_name"));
                dcData.put("dcType",request.getParameter("dcType")); 
                
                logger.info("dcClinename: "+request.getParameter("client_name"));
              
                   sb = new StringBuilder();
                    sb.append("L1:").append((String) request.getParameter("s_add1")).append("; ")
                            .append("L2:").append((String) request.getParameter("s_add2")).append("; ")
                            .append("CI:").append((String) request.getParameter("s_city")).append("; ")
                            .append("ST:").append((String) request.getParameter("s_state")).append("; ")
                            .append("PI:").append((String) request.getParameter("s_pin")).append("; ")
                            .append("CN:").append((String) request.getParameter("sc_per")).append("; ")
                            .append("EM:").append((String) request.getParameter("s_cno")).append("; ")
                            .append("GSTN:").append((String) request.getParameter("s_emailId")).append("; ")
                            .append("CP:").append((String) request.getParameter("s_gst"));
                
                int dcCount = Integer.parseInt(request.getParameter("index"));
                dcData.put("shipAddr",sb.toString());
                ArrayList prodDtls = new ArrayList();
                for(int i=0;i<dcCount;i++){
                    HashMap dtls = new HashMap();
                    logger.info("Row : "+i);
                    dtls.put("productName",request.getParameter("i_prodName"+i));
                    dtls.put("prodId",request.getParameter("i_prodId"+i));
                    dtls.put("prodSpecs",request.getParameter("i_prodSpecs"+i));
                    dtls.put("prodQty",request.getParameter("i_qty"+i).trim());
                    if(request.getParameter("i_prodShipReq"+i).equals("true"))
                        dtls.put("prodShipReq","Y");
                    else
                        dtls.put("prodShipReq","N");
                    
                    if(request.getParameter("i_prodInstReq"+i).equals("true"))
                        dtls.put("prodInstReq","Y");
                    else
                        dtls.put("prodInstReq","N");
                    if(request.getParameter("i_prodRet"+i).equals("true"))
                        dtls.put("prodRet","Y");
                    else
                        dtls.put("prodRet","N");
                    dtls.put("unitPrice",request.getParameter("i_unitPrice"+i));
                    dtls.put("gst",request.getParameter("i_gst"+i));
                    dtls.put("totalAmt",request.getParameter("i_unitPrice"+i)); 
                  prodDtls.add(dtls);
                }
                    
                dcData.put("items",prodDtls);
               // String strMsg = DeliveryChallan.insertDC(strCmpCd, strLoginId, dcData,prodDtls);
                //Above line commented and below line added on 15 july 2023
                logger.info("dcData: "+dcData);
                String strMsg = DeliveryChallan.insDC(strCmpCd,strLoginId,dcData);
               
                logger.info("result: "+strMsg);
                json.put("Result", strMsg);
                pw.println(json);
               break;
          
            /*Following Code of Segment added on 13 June 2023 */
           case GET_DC_DTLS:
                logger.info("test - reached get_dc_dtls code");
                String dc_No = request.getParameter("dcNo");
                logger.info("dcNo: "+dc_No);
                ArrayList dcDtls = DeliveryChallan.getDcDetails(strCmpCd,dc_No);
                logger.info("dcDtls: "+dcDtls);
                json.put("Result", dcDtls);
                pw.println(json);
                break;
            /* Following code of segment added on 30.10.2023 by Rabindra Sharma */
           case GET_STOCK_TR_DTLS:
               logger.info("test - reached getStockTdetails code");
               String st_No = request.getParameter("stNo");
               logger.info("stNo: "+st_No);
               ArrayList stDtls = StockTransfer.getStcckTDetails(strCmpCd, st_No);
               logger.info("stDtls: "+stDtls);
               json.put("Result", stDtls);
               pw.println(json);
               break;
            /* Following code of segment added on 14.11.2023 by Rabindra Sharma */
           case GET_STOCK_TR_STATUS_DTLS:
               logger.info("test - reached getStockTdetails code");
               String stS_No = request.getParameter("stNo");
               logger.info("stNo: "+stS_No);
               ArrayList stSDtls = StockTransfer.getStSDetails(strCmpCd, stS_No);
               logger.info("stDtls: "+stSDtls);
               json.put("Result", stSDtls);
               pw.println(json);
               break;
           case ALLOCATE_DC_PRODS:
                logger.info("reached code segment Allocate DC Products");
                logger.info("test --");
                    int invItems1 = Integer.parseInt((String) request.getParameter("s_invItems"));
                    logger.info(invItems1);
                    alData = new ArrayList();
                    for (int i = 0; i < invItems1; i++) {
                        //Added below lines on 25.07.2019
                        String toProcess = (String) request.getParameter("chkProcess" + i);
                        toProcess = toProcess == null ? "N" : toProcess;
                        if (toProcess.equals("Y")) {
                            //Added above check on 25.07.2019
                            HashMap hmDealDtls = new HashMap();
                            /*
                             hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                             */
                            //Commented above and modified as below on 22.09.2020
                          
                             //   hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             // above line commented and below added for testing
                                hmDealDtls.put("OrdId","20230512002");
                                hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                                hmDealDtls.put("ProdId", (String) request.getParameter("i_prId" + i)); //Added on 30.11.2020
                                // Following line added on 16 th June 2023
                                hmDealDtls.put("dcId",(String)request.getParameter("i_dcId" + i));
                                // Following line added on 20 July 2023 
                                hmDealDtls.put("dcNo",(String)request.getParameter("dc_no"));
                                
                                // Following line , dcno added on 15 June 2023
                                if((String)request.getParameter("dcNo")!=null){
                                 dcNo = request.getParameter("dcNo");
                                //hmDealDtls.put("dcNo", (String)request.getParameter("dcNo"));
                                }
                               
                               logger.info("hmDealDtls: "+hmDealDtls);
                            
                            int qty1 = Integer.parseInt((String) request.getParameter("i_qty" + i));
                            hmDealDtls.put("ProdQty", qty1);
                            String snoEx1 = (String) request.getParameter("sNo_EX" + i);
                            snoEx1 = snoEx1 == null ? "N" : snoEx1;
                            hmDealDtls.put("SNOs", snoEx1);
                            logger.info(hmDealDtls);
                            ArrayList alSNOs1 = new ArrayList();
                            if (snoEx1.equals("Y")) {
                                /*
                                 for (int i2 = 0; i2 < qty; i2++) {
                                 String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                 alSNOs.add(sno);
                                 }
                                 */
                                //Commented above and modified as below on 25.07.2019
                                //sNo_InSer
                                String snoInSer = (String) request.getParameter("sNo_InSer" + i);
                                snoInSer = snoInSer == null ? "N" : snoInSer;
                                if (snoInSer.equals("Y")) {
                                    //sNo_Rows
                                    int iRows = Integer.parseInt((String) request.getParameter("sNo_Rows" + i));
                                    for (int i2 = 0; i2 < iRows; i2++) {
                                        String snoAlpha = "";
                                        String snoFr = (String) request.getParameter("SNoFr" + i + "" + i2);
                                        String snoTo = (String) request.getParameter("SNoTo" + i + "" + i2);
                                        alSNOs1.add(snoFr);
                                        int iSNoFr;
                                        int iSNoTo;
                                        try {
                                            iSNoFr = Integer.parseInt(snoFr);
                                            iSNoTo = Integer.parseInt(snoTo);
                                        } catch (NumberFormatException numberFormatException) {
                                            /*
                                             iSNoFr = Integer.parseInt(snoFr.replaceAll("\\D+", ""));
                                             iSNoTo = Integer.parseInt(snoTo.replaceAll("\\D+", ""));
                                             snoAlpha = snoFr.replace(String.valueOf(iSNoFr), "");
                                             */
                                            //Commented above and modified as below on 20.08.2019
                                            try {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - (String.valueOf(qty1).length() + 1)));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - (String.valueOf(qty1).length() + 1)));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - (String.valueOf(qty1).length() + 1));
                                            } catch (NumberFormatException numberFormatException1) {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - String.valueOf(qty1).length()));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - String.valueOf(qty1).length()));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - String.valueOf(qty1).length());
                                            }
                                        }
                                        while (iSNoFr != iSNoTo) {
                                            iSNoFr++;
                                            if (snoAlpha.isEmpty()) {
                                                alSNOs1.add(String.valueOf(iSNoFr));
                                            } else {
                                                int orLen = snoFr.length();
                                                int exLen = String.valueOf(iSNoFr).length();
                                                while (snoAlpha.length() + exLen != orLen) {
                                                    snoAlpha = snoAlpha.concat("0");
                                                }
                                                alSNOs1.add(snoAlpha.concat(String.valueOf(iSNoFr)));
                                            }
                                        }
                                    }

                                } else {
                                    for (int i2 = 0; i2 < qty1; i2++) {
                                        String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                        //alSNOs.add(sno);
                                        //Commented above and added below lines on 26.12.2020
                                        ArrayList alT = new ArrayList();
                                        alT.add(sno);
                                        alT.add((String) request.getParameter("pkg_box" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgLNo" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgGrpNo" + i + "_" + i2));
                                        alSNOs1.add(alT);
                                    }

                                }

                            }
                            hmDealDtls.put("SNOsData", alSNOs1);
                            alData.add(hmDealDtls);
                         }
                        
                    }
                    logger.info(alData);
                   // strResp = Deal.insProdSNOs(strCmpCd, strLoginId, alData,dcNo);
                    //strResp = DeliveryChallan.allDcProds(strCmpCd, strLoginId, alData,dcNo);
                    // Above line commented on 19 july and below one line added for Integration
                    strResp = DeliveryChallan.insProdSNOs(strCmpCd, strLoginId, alData);
                    json.put("Result", strResp);
                    pw.print(json);
               break;  
           case ALLOCATE_ST_PRODS:
                
                logger.info("reached code segment Allocate Stock Transfer Products");
                logger.info("test --");
                    int invItems2 = Integer.parseInt((String) request.getParameter("s_invItems"));
                    String shipR = (String) request.getParameter("shipR");
                    logger.info(invItems2);
                    alData = new ArrayList();
                    for (int i = 0; i < invItems2; i++) {
                        //Added below lines on 25.07.2019
                        String toProcess = (String) request.getParameter("chkProcess" + i);
                        toProcess = toProcess == null ? "N" : toProcess;
                        if (toProcess.equals("Y")) {
                            //Added above check on 25.07.2019
                            HashMap hmDealDtls = new HashMap();
                            /*
                             hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                             */
                            //Commented above and modified as below on 22.09.2020
                          
                             //   hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             // above line commented and below added for testing
                                hmDealDtls.put("OrdId",(String) request.getParameter("stDealId"));
                                hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                                hmDealDtls.put("ProdId", (String) request.getParameter("i_prId" + i)); //Added on 30.11.2020
                                // Following line added on 16 th June 2023
                                hmDealDtls.put("stId",(String)request.getParameter("i_stId" + i));
                                // Following line added on 20 July 2023 
                                hmDealDtls.put("stNo",(String)request.getParameter("st_no"));
                                
                                // Following line , dcno added on 15 June 2023
                                if((String)request.getParameter("stNo")!=null){
                                 stNo = request.getParameter("stNo");
                                //hmDealDtls.put("dcNo", (String)request.getParameter("dcNo"));
                                }
                               
                               logger.info("hmDealDtls: "+hmDealDtls);
                            
                            int qty1 = Integer.parseInt((String) request.getParameter("i_qty" + i));
                            hmDealDtls.put("ProdQty", qty1);
                            String snoEx1 = (String) request.getParameter("sNo_EX" + i);
                            snoEx1 = snoEx1 == null ? "N" : snoEx1;
                            hmDealDtls.put("SNOs", snoEx1);
                            logger.info(hmDealDtls);
                            ArrayList alSNOs1 = new ArrayList();
                            if (snoEx1.equals("Y")) {
                                /*
                                 for (int i2 = 0; i2 < qty; i2++) {
                                 String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                 alSNOs.add(sno);
                                 }
                                 */
                                //Commented above and modified as below on 25.07.2019
                                //sNo_InSer
                                String snoInSer = (String) request.getParameter("sNo_InSer" + i);
                                snoInSer = snoInSer == null ? "N" : snoInSer;
                                if (snoInSer.equals("Y")) {
                                    //sNo_Rows
                                    int iRows = Integer.parseInt((String) request.getParameter("sNo_Rows" + i));
                                    for (int i2 = 0; i2 < iRows; i2++) {
                                        String snoAlpha = "";
                                        String snoFr = (String) request.getParameter("SNoFr" + i + "" + i2);
                                        String snoTo = (String) request.getParameter("SNoTo" + i + "" + i2);
                                        alSNOs1.add(snoFr);
                                        int iSNoFr;
                                        int iSNoTo;
                                        try {
                                            iSNoFr = Integer.parseInt(snoFr);
                                            iSNoTo = Integer.parseInt(snoTo);
                                        } catch (NumberFormatException numberFormatException) {
                                            /*
                                             iSNoFr = Integer.parseInt(snoFr.replaceAll("\\D+", ""));
                                             iSNoTo = Integer.parseInt(snoTo.replaceAll("\\D+", ""));
                                             snoAlpha = snoFr.replace(String.valueOf(iSNoFr), "");
                                             */
                                            //Commented above and modified as below on 20.08.2019
                                            try {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - (String.valueOf(qty1).length() + 1)));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - (String.valueOf(qty1).length() + 1)));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - (String.valueOf(qty1).length() + 1));
                                            } catch (NumberFormatException numberFormatException1) {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - String.valueOf(qty1).length()));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - String.valueOf(qty1).length()));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - String.valueOf(qty1).length());
                                            }
                                        }
                                        while (iSNoFr != iSNoTo) {
                                            iSNoFr++;
                                            if (snoAlpha.isEmpty()) {
                                                alSNOs1.add(String.valueOf(iSNoFr));
                                            } else {
                                                int orLen = snoFr.length();
                                                int exLen = String.valueOf(iSNoFr).length();
                                                while (snoAlpha.length() + exLen != orLen) {
                                                    snoAlpha = snoAlpha.concat("0");
                                                }
                                                alSNOs1.add(snoAlpha.concat(String.valueOf(iSNoFr)));
                                            }
                                        }
                                    }

                                } else {
                                    for (int i2 = 0; i2 < qty1; i2++) {
                                        String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                        //alSNOs.add(sno);
                                        //Commented above and added below lines on 26.12.2020
                                        ArrayList alT = new ArrayList();
                                        alT.add(sno);
                                        alT.add((String) request.getParameter("pkg_box" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgLNo" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgGrpNo" + i + "_" + i2));
                                        alSNOs1.add(alT);
                                        logger.info("Inside creating Pkg List: "+alT);
                                    }
                                }
                            }
                            hmDealDtls.put("SNOsData", alSNOs1);
                            alData.add(hmDealDtls);
                        }
                    }
                    logger.info("ALL Data :"+alData);
                    strResp = StockTransfer.insProdSNOs(strCmpCd, strLoginId, alData,shipR);
                    json.put("Result", strResp);
                    pw.print(json);
               break;
            // Added below line of case for Update and insert stock transfer status in destination godown on 15.11.2023 by Rabindra Sharma
            case INS_AND_UPD_STOCK_STATUS:
                logger.info("we reached to update and insert for stock transfer for dest godown");
                    int stInvItems = Integer.parseInt((String) request.getParameter("st_invItems"));
                    String stInDate = (String) request.getParameter("stS_InDate");
                    String stFrom = (String) request.getParameter("st_from");
                    String stTo = (String) request.getParameter("st_to");
                    alData = new ArrayList();
                    for (int i = 0; i < stInvItems; i++) {
                        //Added below lines on 25.07.2019
                        String toProcess = (String) request.getParameter("chkProcess" + i);
                        toProcess = toProcess == null ? "N" : toProcess;
                        if (toProcess.equals("Y")) {
                            //Added above check on 25.07.2019
                            HashMap hmDealDtls = new HashMap();
                            /*
                             hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                             */
                            //Commented above and modified as below on 22.09.2020
                          
                             //   hmDealDtls.put("OrdId", (String) request.getParameter("i_dealId" + i));
                             // above line commented and below added for testing
                                hmDealDtls.put("OrdId",(String) request.getParameter("stSDealId"));
                                hmDealDtls.put("OrdRowId", (String) request.getParameter("i_dealRowId" + i));
                                hmDealDtls.put("product", (String) request.getParameter("i_product" + i));
                                hmDealDtls.put("ProdId", (String) request.getParameter("i_prId" + i)); //Added on 30.11.2020
                                // Following line added on 16 th June 2023
                                hmDealDtls.put("stId",(String)request.getParameter("i_stId" + i));
                                // Following line added on 20 July 2023 
                                hmDealDtls.put("stNo",(String)request.getParameter("stS_no"));
                                
                                // Following line , dcno added on 15 June 2023
                                if((String)request.getParameter("stNo")!=null){
                                 stNo = request.getParameter("stNo");
                                //hmDealDtls.put("dcNo", (String)request.getParameter("dcNo"));
                                }
                               
                               logger.info("hmDealDtls: "+hmDealDtls);
                            
                            int qty1 = Integer.parseInt((String) request.getParameter("i_qty" + i));
                            hmDealDtls.put("ProdQty", qty1);
                            String snoEx1 = (String) request.getParameter("sNo_EX" + i);
                            snoEx1 = snoEx1 == null ? "N" : snoEx1;
                            hmDealDtls.put("SNOs", snoEx1);
                            logger.info(hmDealDtls);
                            ArrayList alSNOs1 = new ArrayList();
                            if (snoEx1.equals("Y")) {
                                String snoInSer = (String) request.getParameter("sNo_InSer" + i);
                                snoInSer = snoInSer == null ? "N" : snoInSer;
                                if (snoInSer.equals("Y")) {
                                    //sNo_Rows
                                    int iRows = Integer.parseInt((String) request.getParameter("sNo_Rows" + i));
                                    for (int i2 = 0; i2 < iRows; i2++) {
                                        String snoAlpha = "";
                                        String snoFr = (String) request.getParameter("SNoFr" + i + "" + i2);
                                        String snoTo = (String) request.getParameter("SNoTo" + i + "" + i2);
                                        alSNOs1.add(snoFr);
                                        int iSNoFr;
                                        int iSNoTo;
                                        try {
                                            iSNoFr = Integer.parseInt(snoFr);
                                            iSNoTo = Integer.parseInt(snoTo);
                                        } catch (NumberFormatException numberFormatException) {
                                            //Commented above and modified as below on 20.08.2019
                                            try {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - (String.valueOf(qty1).length() + 1)));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - (String.valueOf(qty1).length() + 1)));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - (String.valueOf(qty1).length() + 1));
                                            } catch (NumberFormatException numberFormatException1) {
                                                iSNoFr = Integer.parseInt(snoFr.substring(snoFr.length() - String.valueOf(qty1).length()));
                                                iSNoTo = Integer.parseInt(snoTo.substring(snoTo.length() - String.valueOf(qty1).length()));
                                                snoAlpha = snoFr.substring(0, snoFr.length() - String.valueOf(qty1).length());
                                            }
                                        }
                                        while (iSNoFr != iSNoTo) {
                                            iSNoFr++;
                                            if (snoAlpha.isEmpty()) {
                                                alSNOs1.add(String.valueOf(iSNoFr));
                                            } else {
                                                int orLen = snoFr.length();
                                                int exLen = String.valueOf(iSNoFr).length();
                                                while (snoAlpha.length() + exLen != orLen) {
                                                    snoAlpha = snoAlpha.concat("0");
                                                }
                                                alSNOs1.add(snoAlpha.concat(String.valueOf(iSNoFr)));
                                            }
                                        }
                                    }

                                } else {
                                    for (int i2 = 0; i2 < qty1; i2++) {
                                        String sno = (String) request.getParameter("SNo" + i + "" + i2);
                                        //alSNOs.add(sno);
                                        //Commented above and added below lines on 26.12.2020
                                        ArrayList alT = new ArrayList();
                                        alT.add(sno);
                                        alT.add((String) request.getParameter("pkg_box" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgLNo" + i + "_" + i2));
                                        alT.add((String) request.getParameter("pkgGrpNo" + i + "_" + i2));
                                        alSNOs1.add(alT);
                                    }
                                }
                            }
                            hmDealDtls.put("SNOsData", alSNOs1);
                            hmDealDtls.put("InDate", stInDate);
                            hmDealDtls.put("sGodown", stFrom);
                            hmDealDtls.put("dGodown", stTo);
                            alData.add(hmDealDtls);
                            
                         }
                        
                    }
//                    logger.info("alData : "+alData);
                    strResp = StockTransfer.insAndUpdateInSt(strCmpCd, strLoginId,strOffCd ,alData);
                    json.put("Result", strResp);
                    pw.println(json);
                break;
            case GET_DC_DTLS_FOR_PKG:
                logger.info("test :");
                /*
                dealId = request.getParameter("dealId");
                invNo = request.getParameter("invNo");
                alData = Deal.getDealInvDtlsPack(strCmpCd, dealId, invNo);
                logger.info(alData);
                dcNo = request.getParameter("pkgDcNo");
                alData = DeliveryChallan.
                json.put("InvDtls", alData);
                pw.println(json);*/
                String delvChallanNo = request.getParameter("dealId");
                logger.info("delvChallanNo: "+delvChallanNo);
                alData = DeliveryChallan.getDealInvDtlsPack(strCmpCd,delvChallanNo);
                json.put("InvDtls",alData);
                pw.println(json);
                break;
                //Added below code for stock pakaging dtls on 01.11.2023 by Rabindra Sharma
           case GET_STOCK_TR_DTLS_PKG:
               HashMap stMap = new HashMap();
               stMap.put("dealId", request.getParameter("dealId"));
               stMap.put("stNo", request.getParameter("stNo"));
               logger.info("StdealNo :"+stMap);
               alData = StockTransfer.getDealStDtlsPack(strCmpCd, stMap);
               json.put("stDtls", alData);
               pw.println(json);
               break;
            // Added case below for fetching the office detals for stock trabsfer on 08.11.2023 by Rabindra Sharma
           case GET_OFF_ADDRESS:
               logger.info("we reached to getting office dtls for stock transfer provision");
               String offCd = request.getParameter("off_cd");
               ArrayList offData = StockTransfer.getOffAddress(strCmpCd, offCd);
               json.put("offDtls", offData);
               pw.println(json);
               break;
           case INS_RFQ:
               logger.info("we reached to inserting RFQ ");
               HashMap map = new HashMap();
               ArrayList rfqList = new ArrayList();
               map.put("rfqDesc", (String) request.getParameter("rfq_date"));
               map.put("rfqAccMgr", (String) request.getParameter("accMgr"));
               map.put("payTerms", (String) request.getParameter("rfq_payTerm"));
               map.put("delvTerms", (String) request.getParameter("rfq_delvTerm"));
               map.put("shipToAddr", (String) request.getParameter("s_addr"));
               int rfqItems = Integer.parseInt((String) request.getParameter("items"));
               for(int rfqIndx = 0; rfqIndx < rfqItems; rfqIndx++){
                    HashMap rfqDtls = new HashMap();
                    rfqDtls.put("prodName", (String) request.getParameter("p_name"+rfqIndx));
                    rfqDtls.put("prodQty", (String) request.getParameter("pqyt"+rfqIndx));
                    rfqDtls.put("prodSpecs", (String) request.getParameter("specs"+rfqIndx));
                    rfqDtls.put("prodId", (String) request.getParameter("prId"+rfqIndx));
                    rfqDtls.put("unitPrice", (String) request.getParameter("unitPr"+rfqIndx));
                    rfqDtls.put("totPrice", (String) request.getParameter("totPr"+rfqIndx));
                    rfqDtls.put("prodWar", (String) request.getParameter("prodWar"+rfqIndx));
                    rfqList.add(rfqDtls);
               }               
               map.put("ProdDtls", rfqList); 
               int vendItems = Integer.parseInt((String) request.getParameter("vendorItems"));
               ArrayList vendorList = new ArrayList();
               for(int vndIndx = 0; vndIndx < vendItems; vndIndx++){
                   HashMap vendDtls = new HashMap();
                   vendDtls.put("vendorName", (String) request.getParameter("v_name"+vndIndx));                                     
                   vendDtls.put("vendAddr", (String) request.getParameter("v_add"+vndIndx));
                    // Following lines added on 12-03-24
                    custAddrId = (String) request.getParameter("v_id"+vndIndx);                    
                    if (custAddrId.equalsIgnoreCase("NEW")) {
                        hmData = new HashMap();
                        hmData.put("CustId", (String) request.getParameter("vcust_Id"+vndIndx));
                        hmData.put("CustName", request.getParameter("v_name"+vndIndx));                        
                        hmData.put("L1", (String) request.getParameter("b_add1"+vndIndx));
                        hmData.put("L2", (String) request.getParameter("b_add2"+vndIndx));
                        hmData.put("CI", (String) request.getParameter("b_city"+vndIndx));
                        hmData.put("ST", (String) request.getParameter("b_state"+vndIndx));
                        hmData.put("PI", (String) request.getParameter("b_pin"+vndIndx));
                        hmData.put("GSTN", (String) request.getParameter("b_gst"+vndIndx));
                        hmData.put("CP", (String) request.getParameter("bc_per"+vndIndx));
                        hmData.put("CN", (String) request.getParameter("b_cno"+vndIndx));
                        hmData.put("EM", (String) request.getParameter("b_emailId"+vndIndx));  
                        logger.info("cust Address"+hmData);
                        custAddrId = Customer.insCustAddress(strCmpCd, strLoginId, hmData);
                        custAddrId = custAddrId.split(" ")[2];
                    }
                   if(custAddrId.equalsIgnoreCase("NEW")){ 
                        vendDtls.put("vendId", custAddrId);                         
                   }else{
                       vendDtls.put("vendId", (String) request.getParameter("v_id"+vndIndx)); 
                   }
                   vendorList.add(vendDtls);
                   
               }
               map.put("VendorDtls", vendorList);
               logger.info("RFQ Details: "+map);               
               String rfqResult = RequestForQuotation.insQuote(strCmpCd, login_dtls, map);                   
               json.put("Result", rfqResult);              
               pw.print(json);               
               break;
           case "getVendDtls":
                logger.info("get_vend_dtls");
                logger.info("get quote_id"+request.getParameter("quoteId"));
                alData = RequestForQuotation.getVendDtls(strCmpCd, strLoginId, request.getParameter("quoteId"));
                logger.info("alData "+alData);
                json.put("Result",alData);
                pw.println(json);
               break;
           case "updVendDtls":
               logger.info("we reached to to update vendor response ");               
                map = new HashMap();
                ArrayList updVendData = new ArrayList();
                map.put("cmpCd", (String) request.getParameter("cmpCd"));                
                map.put("vendId", (String) request.getParameter("vendId"));
                map.put("quoteNo", (String) request.getParameter("qtNo"));
                map.put("quoteDate", (String) request.getParameter("qtDate"));
                map.put("vendName", (String) request.getParameter("vendName"));
                map.put("vendAddr", (String) request.getParameter("vendAddr"));
                if(request.getParameter("rfq_payTerm").equalsIgnoreCase("OT")){
                     map.put("payTerms", (String) request.getParameter("rfq_specTerms"));
                }else{
                     map.put("payTerms", (String) request.getParameter("rfq_payTerm"));
                }               
                map.put("delvTerms", (String) request.getParameter("rfq_delvTerm"));
               int prodItems = Integer.parseInt((String) request.getParameter("prodItems"));
               for(int i = 0; i < prodItems; i++){
                   HashMap prMap = new HashMap();
                   prMap.put("prodName", (String) request.getParameter("prodName"+i));
                   prMap.put("prodSpecs", (String) request.getParameter("prodSpecs"+i));
                   prMap.put("qty", (String) request.getParameter("qt"+i));
                   prMap.put("prodId", (String) request.getParameter("pr_id"+i));                   
                   prMap.put("unitPrice", (String) request.getParameter("unitPrice"+i));
                   prMap.put("gstRate", (String) request.getParameter("gst"+i));
                   prMap.put("totAmount", (String) request.getParameter("tot_amt"+i));
                   prMap.put("prodWar", (String) request.getParameter("warranty"+i));
                   prMap.put("remarks", (String) request.getParameter("remarks"+i));
                   updVendData.add(prMap);
               }
               map.put("prodDtls", updVendData);                        
               String updVendStatus = RequestForQuotation.updVendRspDtls(map);
               json.put("Result", updVendStatus);
               pw.print(json);               
               break;
               
           case FETCH_VEND_RESPONSE_DTLS:
                String quoteNo = request.getParameter("quote_no");
                 alData = RequestForQuotation.fetchVendDtlsResp(strCmpCd,quoteNo);
//                JSONArray jsonArray = RequestForQuotation.fetchVendDtls(strCmpCd,quoteNo);                
                json.put("Result", alData);
                pw.print(json);                
              break;
              
            // Added fllowing code below for reverse GRN with invoice and POs no on 21.01.2025 by Rabindra Sharma 
            // Suggestted by Akanksha
            
           case REQ_FOR_REVERSE_GRN:
               logger.info("we reached to reverse GRN no functionality");
               map = new HashMap();
               map.put("grnNo", (String) request.getParameter("grn_no"));
               map.put("grnDate", (String) request.getParameter("grn_date"));
               map.put("entryForm", (String) request.getParameter("entry_from"));
               map.put("poNo", (String) request.getParameter("po_no"));
               map.put("invNo", (String) request.getParameter("inv_no"));
//               map.put("rcvdQty", (String) request.getParameter("recd_qty"));
               map.put("grnId", (String) request.getParameter("grn_id"));               
               String reverseStatus = PurchaseOrder.reverseGRN(strCmpCd, strOffCd, strLoginId, map);
               json.put("Result", reverseStatus);
               pw.print(json);               
               break;       
            case INS_REMINDER:
                logger.info("we reach to insert/update reminder");
                    String isUpdate = (String) request.getParameter("isUpdate");
                    isUpdate = (isUpdate == null) ? "" : isUpdate;
                    hmData = new HashMap();                                        
                    int itemCount = 0;
                    ArrayList dtlsList = new ArrayList();  
                    // for reminder updation 
                    if(isUpdate.equalsIgnoreCase("Y")){                        
                        hmData.put("curDuesDate", (String) request.getParameter("cDuesDate"));
                        hmData.put("nextDuesDate", (String) request.getParameter("nextDuesDate"));
//                        hmData.put("deptId", (String) request.getParameter("deptId"));
                        hmData.put("notifyTitle", (String) request.getParameter("notifyTitle"));
                        hmData.put("notifyId", (String) request.getParameter("notifyId"));
                        hmData.put("ticketUpdate", (String) request.getParameter("tktUpdCls"));
                        hmData.put("updRemaks", (String) request.getParameter("updRemaks"));
                    }else{
                        hmData.put("remTitle", (String) request.getParameter("remForName"));
                        hmData.put("remDesc", (String) request.getParameter("remForDesc"));                   
//                        hmData.put("remFrom", (String) request.getParameter("remFrom"));
                        hmData.put("remTo", (String) request.getParameter("remTo"));
//                        hmData.put("notifyDept", (String) request.getParameter("notifyDept")); 
                        String count = (String) request.getParameter("remCount");
                        itemCount = (count.isEmpty()) ? 0 : Integer.parseInt(count);
                        
                        for(int iIndex = 0; iIndex <= itemCount; iIndex++){
                            HashMap remDtls = new HashMap();
                            if(iIndex==0){
                                remDtls.put("personName", (String) request.getParameter("personName"));
                                remDtls.put("personEmail", (String) request.getParameter("personEmail"));
                            }else{
                                remDtls.put("personName"+iIndex, (String) request.getParameter("personName"+iIndex));
                                remDtls.put("personEmail"+iIndex, (String) request.getParameter("personEmail"+iIndex));
                            }
    //                        remDtls.put("notifyDept"+iIndex, (String) request.getParameter("notifyDept"+iIndex));  
                            dtlsList.add(remDtls);
                        }
                        hmData.put("remDtls",dtlsList);
                    }
                    
                    String strStatus = Reminder.insReminder(strCmpCd,strOffCd,strLoginId, hmData, isUpdate);                    
                    json.put("Result", strStatus);
                    pw.print(json);
                    break;
            }
          }
        } catch (IOException ex) {
            logger.error(ex);
        }

    }

    /**
     *
     * @param strEMailText
     * @param strSubject
     * @param strRecipient
     *
     * Created on 24.10.2019
     */
    private void sendMail(String strEMailText, String strSubject, String[] strRecipient) {
        try {
            if (strRecipient != null) {
                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication(smtpHost, Integer.parseInt(smtpPort), emAuthUser, emAuthUserPW);
                smtpMailSender.postMail(strRecipient, strSubject, strEMailText, SendMailUsingAuthentication.emailFromAddress);
            }

        } catch (NumberFormatException | MessagingException e) {
            logger.error("Exception is " + e.toString());
        }

    }

    /**
     *
     * @param strEMailText
     * @param strSubject
     * @param strRecipient
     * @param fileName
     *
     * Created on 25.10.2019
     */
    private void sendMail(String strEMailText, String strSubject, String[] strRecipient, String fileName) {       
        try {
            if (strRecipient != null) {
                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication(smtpHost, Integer.parseInt(smtpPort), emAuthUser, emAuthUserPW);
                smtpMailSender.setEmailMsgTxt(strEMailText);                           
                smtpMailSender.postMailWithAttachmentNew(strRecipient, strSubject, fileName, SendMailUsingAuthentication.emailFromAddress);
            }

        } catch (Exception e) {
            logger.error("Exception is " + e.toString());
        }

    }
    
    private void sendMailSingle(String strEMailText, String strSubject, String strRecipient, String fileName){
        try {
            if (strRecipient != null) {
                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication(smtpHost, Integer.parseInt(smtpPort), emAuthUser, emAuthUserPW);
                smtpMailSender.setEmailMsgTxt(strEMailText);                           
                smtpMailSender.postMailWithAttachmentSingleMail(strRecipient, strSubject, fileName, SendMailUsingAuthentication.emailFromAddress);
            }

        } catch (Exception e) {
            logger.error("Exception is " + e.toString());
        }

    }
    

    /**
     *
     * @param strEMailText
     * @param strSubject
     * @param strRecipient
     * @param fileName
     *
     * Created on 25.06.2021
     */
    private void sendMail(String strEMailText, String strSubject, String[] strRecipient, String[] fileName) {
        try {
            if (strRecipient != null) {
                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication(smtpHost, Integer.parseInt(smtpPort), emAuthUser, emAuthUserPW);
                smtpMailSender.setEmailMsgTxt(strEMailText);
                smtpMailSender.postMailWithAttachment(strRecipient, strSubject, fileName, SendMailUsingAuthentication.emailFromAddress);
            }

        } catch (Exception e) {
            logger.error("Exception is " + e.toString());
        }

    }

}
