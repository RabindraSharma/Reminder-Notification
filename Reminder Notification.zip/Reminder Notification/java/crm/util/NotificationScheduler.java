/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crm.util;

import bioas.JDBCAdapter;
import bioas.util.beans.CmpMst;
import bioas.util.beans.OffMst;
import crm.db.Reminder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

/**
 *
 * @author Lenovo
 */

//@WebListener
public class NotificationScheduler implements Runnable{
    private static final Logger logger = Logger.getLogger(NotificationScheduler.class);              
    ArrayList  strCmpCds; 
    String strCmpCd;
    ServletContext context; 
    public NotificationScheduler(ServletContext context) {  
        this.strCmpCd = context.getInitParameter("opxlCmpCd");
        this.context = context;        
        strCmpCds = getCmpCdsByDefaultCmpCd(strCmpCd);
        logger.info("Company Code : "+strCmpCds);               
    }
    @Override
    public void run() {        
        for(Object obj : strCmpCds){
            String cmpCd = (String) obj;
            if(cmpCd!= null && !cmpCd.isEmpty()){ 
                Reminder.startScheduler(cmpCd, context);
            }
        }        
    }   
    
    private static ArrayList getCmpCdsByDefaultCmpCd(String strCmpCd){
        ArrayList cmpCds = new ArrayList();
        String optionQuery = "SELECT cmp_cd FROM options WHERE option_id ='IS_NOTIFY_ALLOW' AND OPTION_VAL = ?";
        try(Connection con = JDBCAdapter.getConnection(strCmpCd)){
            try(PreparedStatement psm = con.prepareStatement(optionQuery)){
                psm.setString(1, "T");
                ResultSet rs = psm.executeQuery();
                while (rs.next()) {                    
                    cmpCds.add(rs.getString("cmp_cd"));
                }
            }
        }catch(SQLException ex){
            logger.info("We caught an exception : "+ex.getMessage());            
        }        
        return cmpCds;
    }
}
