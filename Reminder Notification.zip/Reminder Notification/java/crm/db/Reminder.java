/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crm.db;

import bioas.JDBCAdapter;
import bioas.util.SendMailUsingAuthentication;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import javax.mail.MessagingException;
import javax.servlet.ServletContext;
import org.apache.log4j.Logger;

/**
 *
 * @author Lenovo
 */
public class Reminder {
    private static final Logger logger = Logger.getLogger(Reminder.class);    
    public static String insReminder(String strCmpCd, String strOffCd, String uLoginId, HashMap frmMap, String isUpdate){
        String strStatus = "Failed";
        StringBuilder sb = null;
//        logger.info("frmData : "+frmMap);   
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        String currentDateTimeStr = null;
        String fortmatFutureDateTime = null;        
        Date currentDate = new Date();
        Date futureDate = null;
        try {           
            // for reminder insertion
            if(!isUpdate.equalsIgnoreCase("Y")){
                currentDateTimeStr = sdf.format(currentDate);
                logger.info("Current Date time : "+currentDateTimeStr);

                String toDate = (String) frmMap.get("remTo");
                futureDate = sdf2.parse(toDate);
                fortmatFutureDateTime = sdf.format(futureDate); 
            }
            
            // Added line for reminder updation.
            if(isUpdate.equalsIgnoreCase("Y")){
                String cDuesDt = (String) frmMap.get("curDuesDate");
                Date curDuesDt = sdf2.parse(cDuesDt);
                currentDate = curDuesDt;
                currentDateTimeStr = sdf.format(curDuesDt);                
                
                String nextDuesDt = (String) frmMap.get("nextDuesDate");
                Date nxtDuesDate = sdf2.parse(nextDuesDt);
                futureDate = nxtDuesDate;
                fortmatFutureDateTime = sdf.format(nxtDuesDate);                
            }            
        } catch (ParseException e) {
            logger.info("Invalid date format: " + e.getMessage());
            
        }
        
        
        try(Connection con = JDBCAdapter.getConnection(strCmpCd)){
            con.setAutoCommit(false);            
            sb = new StringBuilder(100);
            sb.append("INSERT INTO REMAINDER_NOTIFY_MST(CMP_CD, ULOGIN_ID, OFF_CD,REM_TITLE,REM_DESC,REM_EXPIRY)")
                    .append("VALUES(?, ?, ?, ?, ?, ?)");
            String insQuery = sb.toString();
            if(!isUpdate.equalsIgnoreCase("Y")){
            try(PreparedStatement psm = con.prepareStatement(insQuery)){
                psm.setString(1, strCmpCd);
                psm.setString(2, uLoginId);
                psm.setString(3, strOffCd);
                psm.setString(4, (String) frmMap.get("remTitle"));
                psm.setString(5, (String) frmMap.get("remDesc"));                     
                psm.setString(6, fortmatFutureDateTime);                                          
                if(psm.executeUpdate() > 0){                                      
                    int remdId = 0;
                    int logInst = 0;
                    String identQuery = "";
                    switch (con.getMetaData().getDatabaseProductName()) {
                        case JDBCAdapter.DATABASE_MSSQL:
                            identQuery = "SELECT IDENT_CURRENT('REMAINDER_NOTIFY_MST') AS REMD_ID";
                            break;
                        case JDBCAdapter.DATABASE_MySQL:
                            identQuery = "SELECT LAST_INSERT_ID() As REMD_ID";
                    }
                    try ( Statement stmt = con.createStatement()) {
                        ResultSet rs = stmt.executeQuery(identQuery);
                        if (rs.next()) {
                            remdId = Integer.parseInt(rs.getString("REMD_ID"));
                            String pareseRemdId = String.valueOf(remdId);
                            logInst = insReminderLogs(strCmpCd, uLoginId, strOffCd, pareseRemdId, currentDateTimeStr, fortmatFutureDateTime, con, frmMap, isUpdate);
                        }
                    }
//                    logger.info("REM Id: " + remdId);

                    if (remdId > 0 && logInst > 0) {
                        int iSaved = 0;
                        int itemCount = 0;
                        String insRemdDtls = "INSERT INTO remd_notify_dtls(cmp_cd,ulogin_id,off_cd,rem_id,notify_person_name,notify_email) VALUES(?, ?, ?, ?, ?, ?)";
                        ArrayList alDtls = (ArrayList) frmMap.get("remDtls");                        
                        try ( PreparedStatement ps2 = con.prepareStatement(insRemdDtls)) {
                            for (Object alDtl : alDtls) {
                                HashMap hmItem = (HashMap) alDtl;
//                                logger.info("hmItem: " + hmItem);
                                if(itemCount == 0){
                                   ps2.setString(1, strCmpCd);
                                   ps2.setString(2, uLoginId);
                                   ps2.setString(3, strOffCd);
                                   ps2.setInt(4, remdId);
                                   ps2.setString(5, (String) hmItem.get("personName"));
                                   ps2.setString(6, (String) hmItem.get("personEmail"));
//                                   ps2.setString(7, (String) frmMap.get("notifyDept"));
                                }else{
                                   ps2.setString(1, strCmpCd);
                                   ps2.setString(2, uLoginId);
                                   ps2.setString(3, strOffCd);
                                   ps2.setInt(4, remdId);
                                   ps2.setString(5, (String) hmItem.get("personName"+itemCount));
                                   ps2.setString(6, (String) hmItem.get("personEmail"+itemCount));
//                                   ps2.setString(7, (String) frmMap.get("notifyDept"));
                                }
                                
                                if (ps2.executeUpdate() > 0) {
                                    iSaved++;
                                    itemCount++;
                                    logger.info("iSaved :" + iSaved);
                                }
                            }
                        }
                     if(iSaved == alDtls.size()){
                         con.commit();
                         strStatus = "Inserted";                         
                     }else{
                         con.rollback();
                     }
                }                
            }            
        }
        }else{
//            String updQuery = "UPDATE remainder_notify_mst SET rem_on = ? , rem_to = ?, updated_on = ?, rem_year = ?, is_status = ? WHERE cmp_cd = ? AND rem_id = ? ";
            String updQuery = "UPDATE remainder_notify_mst SET rem_expiry = ?, updated_on = ?, is_status = ? WHERE cmp_cd = ? AND rem_id = ? ";
            int isUpdated = 0;
            int isInserted = 0;
            try(PreparedStatement psm = con.prepareStatement(updQuery)){
//                psm.setString(1, currentDateTimeStr);
                psm.setString(1, fortmatFutureDateTime);
                psm.setString(2, fortmatFutureDateTime);                
                psm.setString(3, (String) frmMap.get("ticketUpdate"));
                psm.setString(4, strCmpCd);
                psm.setInt(5, Integer.parseInt((String) frmMap.get("notifyId")));                
                if(psm.executeUpdate() > 0){
                    isUpdated++;
                    isInserted = insReminderLogs(strCmpCd,uLoginId,strOffCd,(String) frmMap.get("notifyId"),currentDateTimeStr,fortmatFutureDateTime,con,frmMap,isUpdate);
                }
            }catch(SQLException ex){
                logger.info("Exception in updating ....."+ex.getMessage());
            }
            if(isUpdated == isInserted){
                con.commit();
                strStatus = "Updated";
            }else{
                con.rollback();
            }
        }        
        con.setAutoCommit(true);            
    }catch(SQLException ex){
        if(ex.getMessage().contains("duplicate")){
            strStatus = "Duplicate";
        }
        logger.info("we caught an exception : "+ex.getMessage());        
    }
        return strStatus;
    }
    
    public static ArrayList getReminderDtls(String strCmpCd, String uLoginId, String strOffCd){        
        ArrayList remList = new ArrayList();
//        String remQuery = "SELECT rem_id, rem_name, rem_desc, rem_person, rem_email, rem_dept, rem_on, rem_to, rem_days, rem_year FROM remainder_notify_mst WHERE cmp_cd =? ORDER BY rem_id DESC ";
        StringBuilder sb = new StringBuilder();
                sb.append("SELECT rm.rem_id, rm.ulogin_id, rm.rem_title, rm.rem_desc, nd.notify_person_name, nd.notify_email, rm.sys_date, rm.rem_expiry, rm.updated_on,rm.is_status")
                        .append(" FROM remainder_notify_mst rm, remd_notify_dtls nd")
                        .append(" WHERE rm.cmp_cd = nd.cmp_cd AND rm.rem_id = nd.rem_id AND rm.cmp_cd = ? ORDER BY rm.rem_id");
            String  remQuery = sb.toString();
            logger.info("remDtls Query : "+remQuery);            
        try(Connection con = JDBCAdapter.getConnection(strCmpCd)){            
            try(PreparedStatement psm = con.prepareStatement(remQuery)){
                psm.setString(1, strCmpCd);
                ResultSet rs = psm.executeQuery();
                
               ArrayList<String> remDtls=new ArrayList<>(); 
               HashMap<String,HashMap> tempMap=new HashMap<>();
                
                while (rs.next()) {                                        
                    String remdIds = rs.getString("rem_id");                                        
                    if(tempMap.get(remdIds)==null){
                        HashMap remMap = new HashMap();
                        remMap.put("remId",(String) rs.getString("rem_id"));
                        remMap.put("uLoginId",(String) rs.getString("ulogin_id"));
                        remMap.put("remTitle", rs.getString("rem_title"));                        
                        remMap.put("remDesc", rs.getString("rem_desc"));
                        remMap.put("personName", rs.getString("notify_person_name"));
                        remMap.put("sysDate", rs.getString("sys_date"));
                        remMap.put("remExpiry", rs.getString("rem_expiry"));
                        remMap.put("updatedOn", rs.getString("updated_on"));
                        remMap.put("isStatus", rs.getString("is_status"));
                        remMap.put("emailDtls", new ArrayList());
                        tempMap.put(remdIds, remMap);
                        remDtls.add(remdIds);
                    }
                    HashMap notifyMap=(HashMap)tempMap.get(remdIds);
                    ArrayList emailIds=(ArrayList)notifyMap.get("emailDtls");

                    HashMap<String, String> emailItem = new HashMap<>();
                    emailItem.put("personEmail", rs.getString("notify_email"));                                       
                    emailIds.add(emailItem);                  
                }  
               
               for(String email:remDtls){
                   remList.add(tempMap.get(email));
               }                
            }
        }catch(SQLException ex){
            logger.info("Exception : "+ex.getMessage());            
        }        
        return remList;
    }
    
    public static void startScheduler(String strCmpCd, ServletContext context){           
        try (Connection conn = JDBCAdapter.getConnection(strCmpCd)) {                     
                StringBuilder sb = new StringBuilder();
                sb.append("SELECT DISTINCT t.cmp_cd,t.rem_id, t.rem_title, t.rem_desc, t.rem_expiry, DATEDIFF(DAY,GETDATE(), t.rem_expiry) rem_days, t.is_status ")
                        .append(" FROM remainder_notify_mst t, remd_notify_dtls nd ")                        
                .append(" WHERE t.cmp_cd = nd.cmp_cd AND t.cmp_cd = nd.cmp_cd AND t.rem_id = nd.rem_id AND t.cmp_cd = ? AND (t.is_status !='C') OR (t.IS_STATUS IS NULL) ");
                String query = sb.toString();                          
                logger.info("Schedulre run every day on : ");                
                try (PreparedStatement stmt = conn.prepareStatement(query)){
                     stmt.setString(1, strCmpCd);
                     ResultSet rs = stmt.executeQuery();
                    while (rs.next()) {
                        int remId = rs.getInt("rem_id");                        
                        String NotifyTitle = rs.getString("rem_title");                          
                        String updateOn = (String) rs.getString("updated_on");
                        updateOn = (updateOn == null) ? "" : updateOn;
                                                
                        Date dueDate = rs.getDate("rem_expiry");                         
                        if(!updateOn.isEmpty()){
                            Date nextDueDate = rs.getDate(updateOn);
                            dueDate = nextDueDate;
                        }                                                                         
                        String remDesc = rs.getString("rem_desc");                        
                        int remDays = rs.getInt("rem_days");   
                                           
                        String isStatus = rs.getString("is_status");
                        isStatus = (isStatus == null) ? "" : isStatus;
                        if(dueDate !=null){
                            
                            StringBuilder message; 
                            StringBuilder subject;
                            String[]  emails = Reminder.getEmailsByDeptId(strCmpCd, remId);  
                                    subject = new StringBuilder();
                                    subject.append("Reminder notification for ").append(NotifyTitle).append(" is expiring");                                    
                                    message = new StringBuilder();
                                    message.append("<b>Dear sir,</b><br><br>")
                                            .append("This mail is a reminder regarding to ").append(remDesc).append(" is on due date  ").append(dueDate)
                                            .append("<br><br>")
                                            .append("<b>Note:-</b>").append(" This mail is system genereted please do not reply and if have any question regarding this mail contact to concern person.");                                    
                                    if(remDays == 30 && remDays > 10){                                             
                                        sendMail(message.toString(),subject.toString(), emails, context);                                         
                                        logNotification(conn, remId, strCmpCd, NotifyTitle, remDesc+" on due date "+dueDate);
                                    } else if(remDays == 10 && remDays > 7){                                                          
                                        sendMail(message.toString(),subject.toString(), emails, context);                                         
                                        logNotification(conn, remId, strCmpCd, NotifyTitle, remDesc+" on due date "+dueDate);
                                    } else if(remDays <= 7 && remDays >= 0){                                  
                                        sendMail(message.toString(),subject.toString(), emails, context);                                         
                                        logNotification(conn, remId, strCmpCd, NotifyTitle, remDesc+" on due date "+dueDate);
                                    }else if( remDays < 0 && !isStatus.isEmpty() && !isStatus.equalsIgnoreCase("E")){
                                        subject = new StringBuilder();
                                        subject.append("Reminder notification for ").append(NotifyTitle).append(" is expired");                                    
                                        message = new StringBuilder();
                                        message.append("<b>Dear sir,</b><br><br>")
                                            .append("This mail is a reminder regarding to ").append(remDesc).append(" is expired on ").append(dueDate).append(" please Re-new again otherwise service will effected due to overdue date.")
                                            .append("<br><br>")
                                            .append("<b>Note:-</b>").append(" This mail is system genereted please do not reply and if have any question regarding this mail contact to concern person.");                                    
                                            sendMail(message.toString(),subject.toString(), emails, context);
                                            logNotification(conn, remId, strCmpCd, NotifyTitle, NotifyTitle+" is expired on "+dueDate);
                                            updateReminderExpiry(conn, remId, strCmpCd);
                                    }
                        }
                    }
                }catch(SQLException ex){                
                   logger.info("we caught an exception : "+ex.getMessage());                   
                }
            } catch (SQLException ex) {
                logger.info("we caught an exception : "+ex.getMessage());                 
            }
        }
    
        public static boolean sendMail(String strEMailText, String strSubject, String[] strRecipient, ServletContext context) {                       
            try {                
                String emAuthUser = context.getInitParameter("authuser");                
                String emAuthUserPW = context.getInitParameter("authpass");                
                String smtpHost = context.getInitParameter("smtphost");                
                String smtpPort = context.getInitParameter("port");                
                if (strRecipient != null) {                             
                    SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication(smtpHost, Integer.parseInt(smtpPort), emAuthUser, emAuthUserPW);
                    smtpMailSender.postMail(strRecipient, strSubject, strEMailText, SendMailUsingAuthentication.emailFromAddress);
                    logger.info("Main sent ");                    
                }
                return true;
            } catch (NumberFormatException | MessagingException e) {
                logger.error("Exception is " + e.toString());
                return false;
            }
        }
        
        public static void logNotification(Connection conn, int remId, String strCmpCd, String remTitle, String message) throws SQLException {
            String insertQuery = "INSERT INTO NOTIFICATIONS (cmp_cd,rem_id,rem_title, message) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                stmt.setString(1, strCmpCd);
                stmt.setInt(2, remId);
                stmt.setString(3, remTitle);
                stmt.setString(4, message);
                stmt.executeUpdate();                    
            }catch(SQLException ex){
                logger.info("we caught an exception : "+ex);                
            }
        }

    private static String[] getEmailsByDeptId(String strCmpCd, int remdId) {
        String[] emailList = null;        
        ArrayList<String> mailList = new ArrayList<>();        
        String getEmailQuery = "SELECT notify_email FROM remd_notify_dtls WHERE cmp_cd = ? AND rem_id = ?";
        try(Connection con = JDBCAdapter.getConnection(strCmpCd)){            
            try(PreparedStatement psm = con.prepareStatement(getEmailQuery)){
                psm.setString(1, strCmpCd);
                psm.setInt(2, remdId);                
                ResultSet rs = psm.executeQuery(); 
                
                while (rs.next()) {                               
                    mailList.add(rs.getString("notify_email"));                         
                }                
            }catch(SQLException ex){
                logger.info("Error : "+ex.getMessage());                
            }
        }catch(SQLException ex){
            logger.info("we caught an exception : "+ex.getMessage());            
        }        
        emailList = mailList.toArray(new String[0]);                 
        return emailList;
    }
    
    public static int insReminderLogs(String strCmpCd, String uloginId, String strOffCd, String remdId,          
        String curentDate, String lastDate, Connection con, HashMap frmMap, String isUpdate){
        StringBuilder sb = new StringBuilder();
            sb.append("INSERT INTO remd_logs(cmp_cd,ulogin_id,off_cd,remd_id,notify_title,current_due_date, created_by, next_due_date, updated_by, remarks)")
                    .append(" VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            String insQuery = sb.toString();
            int rowAffected = 0;  
        try(PreparedStatement psm = con.prepareStatement(insQuery)){
            psm.setString(1, strCmpCd);
            psm.setString(2, uloginId);
            psm.setString(3, strOffCd);
            psm.setString(4, remdId);
            
            if(!isUpdate.equalsIgnoreCase("Y")){                
                psm.setString(5, (String) frmMap.get("remTitle"));
//                psm.setString(6, (String) frmMap.get("notifyDept"));
                psm.setString(6, curentDate);
                psm.setString(7, uloginId);
                psm.setString(8, lastDate);
                psm.setString(9, uloginId);
                psm.setNull(10, java.sql.Types.VARCHAR);  
                               
            }else{                
                logger.info("Updating..");                
                psm.setString(5, (String) frmMap.get("notifyTitle"));
//                psm.setString(6, (String) frmMap.get("deptId"));                
                psm.setString(6, curentDate);                 
                psm.setString(7, uloginId);                 
                psm.setString(8, lastDate);                 
                psm.setString(9, uloginId);                
                psm.setString(10, (String) frmMap.get("updRemaks"));                
            }
            if(psm.executeUpdate() > 0){
                rowAffected++;                           
            }
            
        }catch(SQLException ex){
            logger.info("we caught an exception : "+ex.getMessage());            
        }
        return rowAffected;
    }

    private static void updateReminderExpiry(Connection conn, int remId, String strCmpCd) {
        String updQuery = "UPDATE remainder_notify_mst SET is_status = 'E' WHERE cmp_cd = ? AND rem_id = ?";
        try(PreparedStatement psm = conn.prepareStatement(updQuery)){
            psm.setString(1, strCmpCd);
            psm.setInt(2, remId);
            psm.executeUpdate();
        }catch(SQLException ex){
            logger.info("Error In updaing status : "+ex.getMessage());            
        }
    }                
}

        