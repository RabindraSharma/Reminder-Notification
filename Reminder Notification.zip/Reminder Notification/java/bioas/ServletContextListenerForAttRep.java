/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bioas;


import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import org.apache.log4j.Logger;

@WebListener
public class ServletContextListenerForAttRep implements ServletContextListener {

    private static Logger logger = Logger.getLogger(ServletContextListenerForAttRep.class);

    @Override
    public void contextInitialized(ServletContextEvent ctx) {
        ServletContext context = ctx.getServletContext();         
//        SchedulerForAttUpdate schedulerForAttUpdate = new SchedulerForAttUpdate();
//        schedulerForAttUpdate.startAttUpdate(context); 
//        ScheduleTesterForComplain scheduleTesterForComplain = new ScheduleTesterForComplain();
//        scheduleTesterForComplain.doMailForCorrespondingComplain(context);

        // Added below scheduler for notification of task on 29.01.2025 by Rabindra Sharma        
        NotificationSchedulerManager notifyManager = new NotificationSchedulerManager(context);     
        notifyManager.startSchedulerUpdate();
        
        context.setAttribute("isDataBaseUpdatorThreadRunning", "true");        
        logger.info("context  created succes fully");
    }

    @Override
    public void contextDestroyed(ServletContextEvent ctx) {
        ServletContext context = ctx.getServletContext();
        context.removeAttribute("isDataBaseUpdatorThreadRunning");
        logger.info("Servlet Context is Destroyed");
    }
}