/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bioas;

import crm.util.NotificationScheduler;
import java.util.Calendar;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletContext;
import org.apache.log4j.Logger;

/**
 *
 * @author Lenovo
 */
public class NotificationSchedulerManager {
    private static final Logger logger = Logger.getLogger(NotificationSchedulerManager.class);
    private ScheduledExecutorService dailyScheduler;
    private ScheduledExecutorService shortScheduler;
    private ServletContext context;   
       
    
    public NotificationSchedulerManager(ServletContext context) {
        this.context = context;
        logger.info("Scheduler running");
    }
    
    public void startSchedulerUpdate() {
        dailyScheduler = Executors.newSingleThreadScheduledExecutor();
        String notifHours = (String) context.getInitParameter("notifyHours");
        String notifMinutes = (String) context.getInitParameter("notifyMinutes");
        
        int notifyHrs = Integer.parseInt(notifHours);
        int notifyMnts = Integer.parseInt(notifMinutes);
        
        long initialDelay = getInitialDelay(notifyHrs, notifyMnts); // Start at 11:00 AM
        long period = 24 * 60 * 60 ; // Repeat every 24 hours        

        dailyScheduler.scheduleAtFixedRate(() -> {
            logger.info("Notification Scheduler Started at 11 AM");
            
            // Start a short-lived scheduler for 1 seconds
            shortScheduler = Executors.newSingleThreadScheduledExecutor();
            NotificationScheduler task = new NotificationScheduler(context);
            shortScheduler.scheduleAtFixedRate(task, 0, 1, TimeUnit.SECONDS); // Run every second            
            // Stop after 0 seconds            
            shortScheduler.schedule(() -> {
                shortScheduler.shutdown();                
                logger.info("Notification Scheduler Stopped after 0 seconds");
            },0, TimeUnit.SECONDS);

        }, initialDelay, period, TimeUnit.SECONDS);                
    }
    
    public void stopScheduler() {
        if (dailyScheduler != null && !dailyScheduler.isShutdown()) {
            dailyScheduler.shutdown();
            logger.info("Daily Scheduler Stopped");
        }
    }
    private long getInitialDelay(int targetHour, int targetMinute) {
        Calendar now = Calendar.getInstance();
        Calendar targetTime = Calendar.getInstance();
        
        targetTime.set(Calendar.HOUR_OF_DAY, targetHour);
        targetTime.set(Calendar.MINUTE, targetMinute);
        targetTime.set(Calendar.SECOND, 0);
        
        if (now.after(targetTime)) {
            targetTime.add(Calendar.DAY_OF_YEAR, 1); // Schedule for the next day
        }        
        return (targetTime.getTimeInMillis() - now.getTimeInMillis()) / 1000; 
    }    
}
